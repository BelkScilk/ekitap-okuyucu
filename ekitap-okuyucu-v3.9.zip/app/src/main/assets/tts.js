(function () {
  if (window.__tts) return;
  var T = { segs: [], text: '', sentCol: 'rgba(255,200,87,.25)', wordCol: 'rgba(255,200,87,.55)',
            sentEl: [], wordEl: null, lastSent: '' };
  var cache = new Map();

  function info(el) {
    var c = cache.get(el);
    if (c) return c;
    var cs = getComputedStyle(el);
    var d = cs.display;
    var tag = el.nodeName;
    var inlineTag = /^(A|ABBR|B|BDI|BDO|CITE|CODE|DFN|EM|FONT|I|KBD|MARK|Q|S|SAMP|SMALL|SPAN|STRONG|SUB|SUP|TIME|U|VAR|WBR|RUBY|RT|RP)$/.test(tag);
    c = { hidden: d === 'none' || cs.visibility === 'hidden',
          block: !(d === '' || d === 'inline' || d === 'inline-block' || d === 'contents' ||
                   d === 'ruby' || d === 'ruby-text' || d === 'inline-flex' ||
                   (inlineTag && d !== 'block')) };
    cache.set(el, c);
    return c;
  }

  function blockOf(node) {
    var el = node.parentNode;
    while (el && el.nodeType === 1) {
      if (info(el).block) return el;
      el = el.parentNode;
    }
    return document.body;
  }

  T.build = function () {
    cache = new Map();
    var segs = [], text = '', last = null, brk = false;
    var body = document.body;
    if (!body) { T.segs = []; T.text = ''; return { t: '', s: 0 }; }
    var walker = document.createTreeWalker(body, 1 | 4, {
      acceptNode: function (n) {
        if (n.nodeType === 1) {
          var t = n.nodeName;
          if (t === 'SCRIPT' || t === 'STYLE' || t === 'NOSCRIPT' || t === 'TEMPLATE' ||
              t === 'svg' || t === 'SVG') return 2;
          if (t === 'BR') return 1;
          var i = info(n);
          if (i.hidden) return 2;
          return i.block ? 1 : 3;
        }
        return n.nodeValue.length ? 1 : 3;
      }
    });
    var n;
    while ((n = walker.nextNode())) {
      if (n.nodeType === 1) { brk = true; continue; }
      var v = n.nodeValue;
      var ws = !/\S/.test(v);
      if (ws && brk) continue;
      var b = blockOf(n);
      if (brk || b !== last) {
        if (text.length && text.charAt(text.length - 1) !== '\n') text += '\n';
      }
      brk = false;
      last = b;
      segs.push({ n: n, s: text.length });
      text += v;
    }
    T.segs = segs;
    T.text = text;
    return { t: text, s: T.firstVisible() };
  };

  function locate(off) {
    var segs = T.segs, lo = 0, hi = segs.length - 1, ans = 0;
    while (lo <= hi) {
      var m = (lo + hi) >> 1;
      if (segs[m].s <= off) { ans = m; lo = m + 1; } else hi = m - 1;
    }
    return ans;
  }

  function charTop(n, o) {
    var r = document.createRange();
    try { r.setStart(n, o); r.setEnd(n, Math.min(o + 1, n.nodeValue.length)); } catch (e) { return null; }
    var rs = r.getClientRects();
    if (!rs.length) return null;
    return rs[0].top;
  }

  // Ekranda görünen ilk satırın başladığı metin konumu
  T.firstVisible = function () {
    var segs = T.segs, H = window.innerHeight;
    for (var i = 0; i < segs.length; i++) {
      var n = segs[i].n;
      var r = document.createRange();
      r.selectNodeContents(n);
      var b = r.getBoundingClientRect();
      if (b.height <= 0 || b.bottom < 4) continue;
      if (b.top >= -2) return segs[i].s;
      var lo = 0, hi = n.nodeValue.length - 1, ans = hi;
      while (lo <= hi) {
        var m = (lo + hi) >> 1;
        var tp = charTop(n, m);
        if (tp === null) { lo = m + 1; continue; }
        if (tp >= -2) { ans = m; hi = m - 1; } else lo = m + 1;
      }
      var v = n.nodeValue;
      while (ans > 0 && !/\s/.test(v.charAt(ans - 1))) ans--;
      return segs[i].s + ans;
    }
    return 0;
  };

  function rectsFor(a, b) {
    var out = [], segs = T.segs;
    if (!segs.length || a >= b) return out;
    for (var i = locate(a); i < segs.length; i++) {
      var sg = segs[i];
      if (sg.s >= b) break;
      var len = sg.n.nodeValue.length;
      var from = Math.max(a - sg.s, 0), to = Math.min(b - sg.s, len);
      if (to <= from) continue;
      var r = document.createRange();
      try { r.setStart(sg.n, from); r.setEnd(sg.n, to); } catch (e) { continue; }
      var rs = r.getClientRects();
      for (var k = 0; k < rs.length; k++) {
        var q = rs[k];
        if (q.width < 1 || q.height < 1) continue;
        out.push({ l: q.left + window.scrollX, t: q.top + window.scrollY, w: q.width, h: q.height });
      }
    }
    return out;
  }

  function box() {
    var b = document.getElementById('__hlc');
    if (!b) {
      b = document.createElement('div');
      b.id = '__hlc';
      b.style.cssText = 'position:absolute;left:0;top:0;width:0;height:0;pointer-events:none;z-index:2147483647;';
      document.documentElement.appendChild(b);
    }
    return b;
  }

  T.cfg = function (sent, word) { T.sentCol = sent; T.wordCol = word; T.lastSent = ''; T.clear(); };

  T.clear = function () {
    var b = document.getElementById('__hlc');
    if (b) b.innerHTML = '';
    T.sentEl = []; T.wordEl = null; T.lastSent = '';
  };

  // sa..sb: okunan cümle grubu, wa..wb: okunan kelime (wa < 0 ise yalnız cümle)
  T.hl = function (sa, sb, wa, wb) {
    var b = box();
    var key = sa + ':' + sb;
    if (key !== T.lastSent) {
      b.innerHTML = '';
      T.wordEl = null;
      var rs = rectsFor(sa, sb);
      for (var i = 0; i < rs.length; i++) {
        var d = document.createElement('div');
        d.style.cssText = 'position:absolute;border-radius:5px;background:' + T.sentCol + ';' +
          'left:' + (rs[i].l - 2) + 'px;top:' + (rs[i].t - 1) + 'px;width:' + (rs[i].w + 4) +
          'px;height:' + (rs[i].h + 2) + 'px;';
        b.appendChild(d);
      }
      T.lastSent = key;
    }
    var follow = null;
    if (wa >= 0) {
      var wr = rectsFor(wa, wb);
      if (wr.length) {
        var r0 = wr[0];
        if (!T.wordEl) {
          T.wordEl = document.createElement('div');
          T.wordEl.style.cssText = 'position:absolute;border-radius:6px;background:' + T.wordCol +
            ';box-shadow:0 0 0 1px ' + T.wordCol + ';transition:left .09s ease-out,width .09s ease-out;';
          b.appendChild(T.wordEl);
        }
        var st = T.wordEl.style;
        st.left = (r0.l - 3) + 'px';
        st.top = (r0.t - 1) + 'px';
        st.width = (r0.w + 6) + 'px';
        st.height = (r0.h + 2) + 'px';
        follow = r0;
      }
    } else if (T.sentEl) {
      var sr = rectsFor(sa, Math.min(sb, sa + 1));
      if (sr.length) follow = sr[0];
    }
    if (follow) {
      var H = window.innerHeight, top = follow.t - window.scrollY, bot = top + follow.h;
      if (top < H * 0.10 || bot > H * 0.74) {
        window.scrollTo({ top: Math.max(0, follow.t - H * 0.28), behavior: 'smooth' });
      }
    }
    return true;
  };

  window.__tts = T;
})();
