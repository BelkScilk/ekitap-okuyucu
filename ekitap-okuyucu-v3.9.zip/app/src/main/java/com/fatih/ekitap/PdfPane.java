package com.fatih.ekitap;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.pdf.PdfRenderer;
import android.os.ParcelFileDescriptor;
import android.text.Layout;
import android.text.Spannable;
import android.text.style.BackgroundColorSpan;
import android.text.style.ReplacementSpan;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Consumer;

/**
 * PDF okuma yüzeyi. Görüntü kipi: sayfa resmi (kenar boşlukları kırpılır, iki parmakla yakınlaştırılır).
 * Metin kipi: sayfa OCR ile metne çevrilip ekrana sığacak şekilde gösterilir. Her iki kipte de
 * sesli okurken OCR'ın kelime kutuları sayesinde okunan kelime vurgulanır.
 */
final class PdfPane extends Pane {

    /** OCR ile bulunan tek bir kelime ve sayfa üzerindeki kutuları (sayfa oranı cinsinden). */
    static final class Word {
        final int start;
        final int end;
        final List<RectF> rects;

        Word(int start, int end, List<RectF> rects) {
            this.start = start;
            this.end = end;
            this.rects = rects;
        }
    }

    static final class Ocr {
        final String text;
        final List<Word> words;

        Ocr(String text, List<Word> words) {
            this.text = text;
            this.words = words;
        }
    }

    private static final Ocr EMPTY = new Ocr("", new ArrayList<Word>());

    private final PdfRenderer pdf;
    private final ParcelFileDescriptor pfd;
    private final int pageCount;
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final FrameLayout root;

    // görüntü kipi
    private final ScrollView imgV;
    private final HorizontalScrollView imgH;
    private final ImageView img;
    private final HlView overlay;
    // metin kipi
    private final ScrollView txtV;
    private final TextView txt;

    private TextRecognizer recognizer;
    private final Map<Integer, Ocr> ocrCache = new HashMap<>();
    private final Map<Integer, List<Consumer<Ocr>>> ocrWaiters = new HashMap<>();
    private final Map<Integer, float[]> boxCache = new HashMap<>();
    private float[] hCrop;

    private int page;
    private boolean textMode;
    private float zoom = 1f;
    private int renderToken;
    private float[] shownBox = {0f, 0f, 1f, 1f};
    private boolean destroyed;
    private int[] hl; // son vurgu: sa, sb, wa, wb
    private BackgroundColorSpan sentSpan;
    private WordSpan wordSpan;

    private final ScaleGestureDetector scaleDetector;
    private final GestureDetector flingDetector;

    PdfPane(Host host, PdfRenderer pdf, ParcelFileDescriptor pfd, String key) {
        super(host, key);
        this.pdf = pdf;
        this.pfd = pfd;
        this.pageCount = pdf.getPageCount();
        Activity a = host.activity();
        Prefs pr = host.prefs();
        textMode = pr.pdfTextMode();
        zoom = pr.pdfZoom();

        root = new FrameLayout(a);

        imgV = new ScrollView(a);
        imgV.setVerticalScrollBarEnabled(false);
        imgH = new HorizontalScrollView(a);
        imgH.setHorizontalScrollBarEnabled(false);
        FrameLayout box = new FrameLayout(a);
        img = new ImageView(a);
        overlay = new HlView(a);
        box.addView(img, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        box.addView(overlay, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        imgH.addView(box, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        imgV.addView(imgH, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        imgV.setOnScrollChangeListener((v, x, y, ox, oy) -> host.onPosition());
        root.addView(imgV, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        txtV = new ScrollView(a);
        txtV.setVerticalScrollBarEnabled(false);
        txt = new TextView(a);
        txtV.addView(txt, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        txtV.setOnScrollChangeListener((v, x, y, ox, oy) -> host.onPosition());
        root.addView(txtV, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        try {
            recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        } catch (Throwable t) {
            recognizer = null;
        }

        scaleDetector = new ScaleGestureDetector(a,
                new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                    private float factor = 1f;

                    @Override
                    public boolean onScaleBegin(ScaleGestureDetector d) {
                        factor = 1f;
                        return true;
                    }

                    @Override
                    public boolean onScale(ScaleGestureDetector d) {
                        factor *= d.getScaleFactor();
                        return true;
                    }

                    @Override
                    public void onScaleEnd(ScaleGestureDetector d) {
                        if (textMode) {
                            host.prefs().setTextZoom(Math.round(host.prefs().textZoom() * factor));
                            applyStyle();
                        } else {
                            setZoom(zoom * factor);
                        }
                    }
                });
        flingDetector = new GestureDetector(a, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onFling(MotionEvent e1, MotionEvent e2, float vx, float vy) {
                if (e1 == null || e2 == null || (!textMode && zoom > 1.05f)) return false;
                float dx = e2.getX() - e1.getX();
                float dy = e2.getY() - e1.getY();
                if (Math.abs(dx) > Ui.dp(host.activity(), 90) && Math.abs(dx) > Math.abs(dy) * 2) {
                    host.onUserNavigated();
                    if (dx < 0) go(page + 1, 0f);
                    else go(page - 1, 0f);
                }
                return false;
            }
        });
        applyModeVisibility();
    }

    // ------------------------------------------------------------------ Pane

    @Override
    View view() {
        return root;
    }

    @Override
    void open() {
        page = Math.max(0, Math.min(host.prefs().page(key), pageCount - 1));
        applyStyle();
        showPage(true);
    }

    @Override
    int unitCount() {
        return pageCount;
    }

    @Override
    int unit() {
        return page;
    }

    @Override
    float frac() {
        ScrollView sv = textMode ? txtV : imgV;
        View child = sv.getChildAt(0);
        if (child == null) return 0f;
        int max = child.getHeight() - sv.getHeight();
        if (max <= 0) return 0f;
        return Math.max(0f, Math.min(1f, sv.getScrollY() / (float) max));
    }

    @Override
    void go(int u, float f) {
        if (u < 0 || u >= pageCount) return;
        boolean same = u == page;
        page = u;
        host.prefs().savePage(key, u);
        if (!same) showPage(true);
        final float ff = f;
        if (same || ff > 0f) {
            host.ui().postDelayed(() -> {
                ScrollView sv = textMode ? txtV : imgV;
                View child = sv.getChildAt(0);
                if (child != null) {
                    int max = Math.max(0, child.getHeight() - sv.getHeight());
                    sv.scrollTo(0, Math.round(max * Math.max(0f, Math.min(1f, ff))));
                }
            }, 250);
        }
        host.onPosition();
    }

    @Override
    protected View scrollTarget() {
        return textMode ? txtV : imgV;
    }

    @Override
    protected boolean atEdge(View v, boolean forward) {
        ScrollView sv = textMode ? txtV : imgV;
        View child = sv.getChildAt(0);
        if (child == null) return true;
        int max = Math.max(0, child.getHeight() - sv.getHeight());
        int y = sv.getScrollY();
        return forward ? y >= max - 3 : y <= 3;
    }

    @Override
    protected boolean edgeNav(boolean forward) {
        if (forward && page + 1 < pageCount) {
            host.onUserNavigated();
            go(page + 1, 0f);
            return true;
        }
        if (!forward && page > 0) {
            host.onUserNavigated();
            go(page - 1, 1f);
            return true;
        }
        return false;
    }

    @Override
    boolean step(boolean forward) {
        ScrollView sv = textMode ? txtV : imgV;
        int dir = forward ? 1 : -1;
        if (sv.canScrollVertically(dir)) {
            sv.smoothScrollBy(0, dir * Math.round(sv.getHeight() * 0.88f));
            return true;
        }
        if (forward && page + 1 < pageCount) {
            host.onUserNavigated();
            go(page + 1, 0f);
            return true;
        }
        if (!forward && page > 0) {
            host.onUserNavigated();
            go(page - 1, 0f);
            return true;
        }
        return false;
    }

    @Override
    String unitLabel() {
        return "Sayfa " + (page + 1) + " / " + pageCount;
    }

    @Override
    String unitTitle() {
        return "Sayfa " + (page + 1);
    }

    @Override
    String bookmarkLabel() {
        return "Sayfa " + (page + 1) + " / " + pageCount;
    }

    @Override
    void saveProgress() {
        host.prefs().savePage(key, page);
        host.prefs().saveProgress(key, (page + 1f) / Math.max(1, pageCount));
    }

    @Override
    float overall() {
        return Math.max(0f, Math.min(1f, (page + 0.0f) / Math.max(1, pageCount - 1)));
    }

    @Override
    void seekOverall(float f) {
        int p = Math.round(Math.max(0f, Math.min(1f, f)) * Math.max(0, pageCount - 1));
        go(p, 0f);
    }

    // ------------------------------------------------------------------ kipler

    boolean isTextMode() {
        return textMode;
    }

    void setTextMode(boolean on) {
        if (textMode == on) return;
        textMode = on;
        host.prefs().setPdfTextMode(on);
        applyModeVisibility();
        showPage(false);
    }

    void refreshRender() {
        if (!textMode) renderImage();
    }

    private void applyModeVisibility() {
        imgV.setVisibility(textMode ? View.GONE : View.VISIBLE);
        txtV.setVisibility(textMode ? View.VISIBLE : View.GONE);
    }

    @Override
    void applyStyle() {
        Palette p = host.pal();
        Prefs pr = host.prefs();
        root.setBackgroundColor(p.bg);
        imgV.setBackgroundColor(p.bg);
        imgH.setBackgroundColor(p.bg);
        txtV.setBackgroundColor(p.bg);
        img.setColorFilter(filterFor(p.id));
        txt.setTextColor(p.fg);
        txt.setTextSize(17f * pr.textZoom() / 100f);
        txt.setTypeface(pr.fontFamily() == 0 ? Typeface.SERIF : Typeface.SANS_SERIF);
        txt.setLineSpacing(0f, pr.lineSpacing() / 100f);
        Activity a = host.activity();
        int m = Ui.dp(a, pr.margin());
        txt.setPadding(m, Ui.dp(a, 30), m, Ui.dp(a, 120));
        overlay.setPalette(p);
        if (hl != null) applyHighlight();
    }

    private static ColorMatrixColorFilter filterFor(int theme) {
        if (theme == Palette.DARK || theme == Palette.BLACK) {
            return new ColorMatrixColorFilter(new float[]{
                    -0.9f, 0, 0, 0, 235,
                    0, -0.9f, 0, 0, 235,
                    0, 0, -0.9f, 0, 235,
                    0, 0, 0, 1, 0});
        }
        if (theme == Palette.NIGHT) {
            return new ColorMatrixColorFilter(new float[]{
                    -0.24f, -0.47f, -0.09f, 0, 205,
                    0, 0, 0, 0, 0,
                    0, 0, 0, 0, 0,
                    0, 0, 0, 1, 0});
        }
        if (theme == Palette.AMBER) {
            return new ColorMatrixColorFilter(new float[]{
                    -0.24f, -0.47f, -0.09f, 0, 185,
                    -0.19f, -0.37f, -0.07f, 0, 148,
                    -0.06f, -0.12f, -0.02f, 0, 45,
                    0, 0, 0, 1, 0});
        }
        if (theme == Palette.SEPIA) {
            return new ColorMatrixColorFilter(new float[]{
                    0.393f, 0.769f, 0.189f, 0, 0,
                    0.349f, 0.686f, 0.168f, 0, 0,
                    0.272f, 0.534f, 0.131f, 0, 0,
                    0, 0, 0, 1, 0});
        }
        return null;
    }

    private void setZoom(float z) {
        float nz = Math.max(1f, Math.min(5f, z));
        if (Math.abs(nz - zoom) < 0.01f) return;
        zoom = nz;
        host.prefs().setPdfZoom(nz);
        renderImage();
    }

    @Override
    void onTouch(MotionEvent ev) {
        scaleDetector.onTouchEvent(ev);
        if (!scaleDetector.isInProgress()) {
            flingDetector.onTouchEvent(ev);
            edgePull(ev);
        }
    }

    @Override
    void onResized() {
        if (!textMode) host.ui().postDelayed(this::renderImage, 250);
    }

    // ------------------------------------------------------------------ sayfa gösterme

    private void showPage(boolean resetScroll) {
        clearHighlightState();
        if (resetScroll) {
            imgV.scrollTo(0, 0);
            imgH.scrollTo(0, 0);
            txtV.scrollTo(0, 0);
        }
        if (textMode) {
            txt.setText("Sayfa metne çevriliyor…", TextView.BufferType.SPANNABLE);
            final int p = page;
            ocrPage(p, o -> {
                if (destroyed || !textMode || p != page) return;
                if (o.text.trim().isEmpty()) {
                    txt.setText("(Bu sayfada okunabilir metin bulunamadı. Görüntü kipine dönmek "
                            + "için yazı ayarlarından \"Metni ekrana sığdır\" seçeneğini kapat.)",
                            TextView.BufferType.SPANNABLE);
                } else {
                    txt.setText(o.text, TextView.BufferType.SPANNABLE);
                }
                txtV.scrollTo(0, 0);
                host.onUnitLoaded();
            });
            if (p + 1 < pageCount) ocrPage(p + 1, o -> { });
        } else {
            renderImage();
            host.ui().postDelayed(() -> {
                if (!destroyed) host.onUnitLoaded();
            }, 120);
        }
        host.onPosition();
    }

    private static final class Rendered {
        final Bitmap bmp;
        final float[] box;

        Rendered(Bitmap bmp, float[] box) {
            this.bmp = bmp;
            this.box = box;
        }
    }

    private void renderImage() {
        if (destroyed || textMode) return;
        final int p = page;
        final int token = ++renderToken;
        final int vw = Math.max(1, root.getWidth());
        final boolean crop = host.prefs().pdfCrop();
        final int target = Math.round(vw * zoom);
        try {
            io.execute(() -> {
                Rendered r = null;
                try {
                    r = crop ? renderCropped(p, target) : renderFull(p, target);
                } catch (Throwable ignored) {
                }
                final Rendered fr = r;
                host.ui().post(() -> {
                    if (destroyed || fr == null || token != renderToken) return;
                    img.setImageBitmap(fr.bmp);
                    shownBox = fr.box;
                    overlay.setBox(fr.box);
                    if (hl != null) applyHighlight();
                });
            });
        } catch (Exception ignored) {
        }
    }

    // ------------------------------------------------------------------ PDF -> resim (yalnızca io iş parçacığı)

    private Rendered renderFull(int p, int targetW) {
        if (p < 0 || p >= pdf.getPageCount()) return null;
        PdfRenderer.Page pg = pdf.openPage(p);
        try {
            float ratio = (float) pg.getHeight() / (float) pg.getWidth();
            int w = Math.max(200, targetW);
            int h = Math.max(200, Math.round(w * ratio));
            long px = (long) w * (long) h;
            if (px > 12_000_000L) {
                double s = Math.sqrt(12_000_000d / (double) px);
                w = Math.max(200, (int) (w * s));
                h = Math.max(200, (int) (h * s));
            }
            Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            b.eraseColor(Color.WHITE);
            pg.render(b, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
            b.setDensity(Bitmap.DENSITY_NONE);
            if (host.prefs().pdfEnhance() > 0) {
                try {
                    ScanFix.enhance(b, host.prefs().pdfEnhance());
                } catch (Throwable ignored) {
                }
            }
            return new Rendered(b, new float[]{0f, 0f, 1f, 1f});
        } finally {
            pg.close();
        }
    }

    private Rendered renderCropped(int p, int targetW) {
        if (p < 0 || p >= pdf.getPageCount()) return null;
        float[] box = effectiveBox(p);
        PdfRenderer.Page pg = pdf.openPage(p);
        try {
            float pw = pg.getWidth();
            float ph = pg.getHeight();
            float cw = (box[2] - box[0]) * pw;
            float ch = (box[3] - box[1]) * ph;
            int w = Math.max(200, targetW);
            int h = Math.max(200, Math.round(w * ch / cw));
            long px = (long) w * (long) h;
            if (px > 12_000_000L) {
                double s = Math.sqrt(12_000_000d / (double) px);
                w = Math.max(200, (int) (w * s));
                h = Math.max(200, (int) (h * s));
            }
            float sx = w / cw;
            float sy = h / ch;
            Matrix m = new Matrix();
            m.setScale(sx, sy);
            m.postTranslate(-box[0] * pw * sx, -box[1] * ph * sy);
            Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            b.eraseColor(Color.WHITE);
            pg.render(b, null, m, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
            b.setDensity(Bitmap.DENSITY_NONE);
            if (host.prefs().pdfEnhance() > 0) {
                try {
                    ScanFix.enhance(b, host.prefs().pdfEnhance());
                } catch (Throwable ignored) {
                }
            }
            return new Rendered(b, box);
        } finally {
            pg.close();
        }
    }

    /** {sol, üst, sağ, alt} oranları: sol/sağ tüm kitap için ortak, üst/alt sayfaya özel. */
    private float[] effectiveBox(int p) {
        float[] hc = horizontalCrop();
        float[] pb = pageBox(p);
        float t = 0f;
        float b = 1f;
        if (pb != null) {
            t = pb[1];
            b = pb[3];
        }
        float l = hc[0];
        float r = hc[1];
        if (r - l < 0.5f) {
            l = 0f;
            r = 1f;
        }
        if (b - t < 0.15f) {
            t = 0f;
            b = 1f;
        }
        return new float[]{l, t, r, b};
    }

    private float[] horizontalCrop() {
        if (hCrop != null) return hCrop;
        List<Float> ls = new ArrayList<>();
        List<Float> rs = new ArrayList<>();
        int n = Math.min(15, pageCount);
        for (int i = 0; i < n; i++) {
            int p = (int) ((long) i * pageCount / n);
            float[] bx = pageBox(p);
            if (bx != null) {
                ls.add(bx[0]);
                rs.add(bx[2]);
            }
        }
        float l = 0f;
        float r = 1f;
        if (ls.size() >= 3) {
            Collections.sort(ls);
            Collections.sort(rs);
            l = ls.get((int) (ls.size() * 0.1f));
            r = rs.get(Math.max(0, (int) Math.ceil(rs.size() * 0.9f) - 1));
        }
        hCrop = new float[]{l, r};
        return hCrop;
    }

    /** Sayfanın koyu (yazı) piksellerinin sınırlayıcı kutusu; bulunamazsa null. */
    private float[] pageBox(int p) {
        float[] cached = boxCache.get(p);
        if (cached != null) return cached.length == 4 ? cached : null;
        float[] result = new float[0];
        PdfRenderer.Page pg = pdf.openPage(p);
        try {
            int tw = 400;
            int th = Math.max(1, Math.round(tw * (float) pg.getHeight() / (float) pg.getWidth()));
            Bitmap bmp = Bitmap.createBitmap(tw, th, Bitmap.Config.ARGB_8888);
            bmp.eraseColor(Color.WHITE);
            pg.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
            int[] px = new int[tw * th];
            bmp.getPixels(px, 0, tw, 0, 0, tw, th);
            bmp.recycle();
            int[] rows = new int[th];
            int[] cols = new int[tw];
            for (int y = 0; y < th; y++) {
                for (int x = 0; x < tw; x++) {
                    int c = px[y * tw + x];
                    int lum = (Color.red(c) * 30 + Color.green(c) * 59 + Color.blue(c) * 11) / 100;
                    if (lum < 150) {
                        rows[y]++;
                        cols[x]++;
                    }
                }
            }
            int y0 = firstAtLeast(rows, 2, false);
            int y1 = firstAtLeast(rows, 2, true);
            int x0 = firstAtLeast(cols, 2, false);
            int x1 = firstAtLeast(cols, 2, true);
            if (y0 >= 0 && y1 > y0 && x0 >= 0 && x1 > x0) {
                result = new float[]{
                        Math.max(0f, x0 / (float) tw - 0.02f),
                        Math.max(0f, y0 / (float) th - 0.01f),
                        Math.min(1f, (x1 + 1) / (float) tw + 0.02f),
                        Math.min(1f, (y1 + 1) / (float) th + 0.01f)};
            }
        } finally {
            pg.close();
        }
        boxCache.put(p, result);
        return result.length == 4 ? result : null;
    }

    private static int firstAtLeast(int[] a, int min, boolean fromEnd) {
        if (fromEnd) {
            for (int i = a.length - 1; i >= 0; i--) if (a[i] >= min) return i;
        } else {
            for (int i = 0; i < a.length; i++) if (a[i] >= min) return i;
        }
        return -1;
    }

    // ------------------------------------------------------------------ OCR

    private void ocrPage(final int p, final Consumer<Ocr> cb) {
        Ocr cached = ocrCache.get(p);
        if (cached != null) {
            cb.accept(cached);
            return;
        }
        List<Consumer<Ocr>> w = ocrWaiters.get(p);
        if (w != null) {
            w.add(cb);
            return;
        }
        w = new ArrayList<>();
        w.add(cb);
        ocrWaiters.put(p, w);
        ocrRun(p, o -> {
            List<Consumer<Ocr>> ws = ocrWaiters.remove(p);
            if (ws != null) {
                for (Consumer<Ocr> c : ws) c.accept(o);
            }
        });
    }

    private void ocrRun(final int p, final Consumer<Ocr> cb) {
        final TextRecognizer rec = recognizer;
        if (rec == null) {
            cb.accept(EMPTY);
            return;
        }
        try {
            io.execute(() -> {
                Rendered r = null;
                try {
                    r = renderFull(p, 1800);
                } catch (Throwable ignored) {
                }
                final Bitmap bmp = r == null ? null : r.bmp;
                host.ui().post(() -> {
                    if (bmp == null || destroyed) {
                        cb.accept(EMPTY);
                        return;
                    }
                    try {
                        final int bw = Math.max(1, bmp.getWidth());
                        final int bh = Math.max(1, bmp.getHeight());
                        rec.process(InputImage.fromBitmap(bmp, 0))
                                .addOnSuccessListener(result -> {
                                    Ocr o = buildOcr(result, bw, bh);
                                    ocrCache.put(p, o);
                                    bmp.recycle();
                                    cb.accept(o);
                                })
                                .addOnFailureListener(err -> {
                                    bmp.recycle();
                                    cb.accept(EMPTY);
                                });
                    } catch (Throwable t) {
                        cb.accept(EMPTY);
                    }
                });
            });
        } catch (Exception e) {
            cb.accept(EMPTY);
        }
    }

    private static RectF frac(android.graphics.Rect r, int w, int h) {
        if (r == null) return new RectF(0, 0, 0, 0);
        return new RectF(r.left / (float) w, r.top / (float) h, r.right / (float) w, r.bottom / (float) h);
    }

    /** OCR sonucunu paragraf metnine ve kelime kutularına çevirir; satır sonu tirelerini birleştirir. */
    private static Ocr buildOcr(Text result, int w, int h) {
        StringBuilder sb = new StringBuilder();
        List<Word> words = new ArrayList<>();
        List<Text.TextBlock> blocks = result.getTextBlocks();
        if (blocks == null || blocks.isEmpty()) return EMPTY;
        for (Text.TextBlock block : blocks) {
            List<Text.Line> lines = block.getLines();
            if (lines == null || lines.isEmpty()) continue;
            int blockStartLen = sb.length();
            String carryText = null;
            List<RectF> carryRects = null;
            for (int li = 0; li < lines.size(); li++) {
                List<Text.Element> els = lines.get(li).getElements();
                if (els == null) continue;
                for (int ei = 0; ei < els.size(); ei++) {
                    Text.Element el = els.get(ei);
                    String t = el.getText();
                    if (t == null || t.trim().isEmpty()) continue;
                    t = t.trim();
                    List<RectF> rects = new ArrayList<>();
                    if (carryText != null) {
                        t = carryText + t;
                        rects.addAll(carryRects);
                        carryText = null;
                        carryRects = null;
                    }
                    rects.add(frac(el.getBoundingBox(), w, h));
                    boolean lastOnLine = ei == els.size() - 1;
                    if (lastOnLine && t.length() > 1 && (t.endsWith("-") || t.endsWith("­"))
                            && li + 1 < lines.size()) {
                        List<Text.Element> nx = lines.get(li + 1).getElements();
                        if (nx != null && !nx.isEmpty() && nx.get(0).getText() != null
                                && !nx.get(0).getText().isEmpty()
                                && Character.isLowerCase(nx.get(0).getText().charAt(0))) {
                            carryText = t.substring(0, t.length() - 1);
                            carryRects = rects;
                            continue;
                        }
                    }
                    if (sb.length() > blockStartLen) sb.append(' ');
                    else if (sb.length() > 0) sb.append("\n\n");
                    int st = sb.length();
                    sb.append(t);
                    words.add(new Word(st, sb.length(), rects));
                }
            }
            if (carryText != null) {
                if (sb.length() > blockStartLen) sb.append(' ');
                else if (sb.length() > 0) sb.append("\n\n");
                int st = sb.length();
                sb.append(carryText);
                words.add(new Word(st, sb.length(), carryRects));
            }
        }
        if (sb.length() == 0) return EMPTY;
        return new Ocr(sb.toString(), words);
    }

    // ------------------------------------------------------------------ sesli okuma

    @Override
    void requestSpeech(final boolean fromVisible, final SpeechCb cb) {
        final int p = page;
        ocrPage(p, o -> {
            if (destroyed || p != page) return;
            int start = 0;
            if (fromVisible && !o.text.isEmpty()) start = visibleStart(o);
            cb.on(o.text, start);
            if (p + 1 < pageCount) ocrPage(p + 1, x -> { });
        });
    }

    /** Ekranın üstünde görünen ilk kelimenin metindeki konumu. */
    private int visibleStart(Ocr o) {
        if (textMode) {
            Layout l = txt.getLayout();
            if (l == null) return 0;
            int line = l.getLineForVertical(Math.max(0, txtV.getScrollY()));
            int off = l.getLineStart(line);
            return Math.max(0, Math.min(off, o.text.length()));
        }
        int h = overlay.getHeight();
        if (h <= 0) return 0;
        float topFrac = shownBox[1] + (imgV.getScrollY() / (float) h) * (shownBox[3] - shownBox[1]);
        for (Word w : o.words) {
            if (w.rects.isEmpty()) continue;
            RectF r = w.rects.get(0);
            if (r.bottom >= topFrac && r.bottom > 0) return w.start;
        }
        return 0;
    }

    @Override
    void highlight(int sa, int sb, int wa, int wb) {
        hl = new int[]{sa, sb, wa, wb};
        applyHighlight();
        follow();
    }

    @Override
    void clearHighlight() {
        clearHighlightState();
    }

    private void clearHighlightState() {
        hl = null;
        overlay.set(null, null);
        Spannable sp = spannable();
        if (sp != null) {
            if (sentSpan != null) sp.removeSpan(sentSpan);
            if (wordSpan != null) sp.removeSpan(wordSpan);
        }
        sentSpan = null;
        wordSpan = null;
    }

    private Spannable spannable() {
        CharSequence cs = txt.getText();
        return cs instanceof Spannable ? (Spannable) cs : null;
    }

    private void applyHighlight() {
        if (hl == null) return;
        Palette p = host.pal();
        if (textMode) {
            Spannable sp = spannable();
            if (sp == null) return;
            if (sentSpan != null) sp.removeSpan(sentSpan);
            if (wordSpan != null) sp.removeSpan(wordSpan);
            sentSpan = null;
            wordSpan = null;
            int len = sp.length();
            int sa = Math.max(0, Math.min(hl[0], len));
            int sb = Math.max(sa, Math.min(hl[1], len));
            if (sb > sa) {
                sentSpan = new BackgroundColorSpan(p.hlSentence);
                sp.setSpan(sentSpan, sa, sb, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
            if (hl[2] >= 0 && hl[3] > hl[2] && hl[3] <= len) {
                Activity a = host.activity();
                wordSpan = new WordSpan(p.hlWord, p.fg, Ui.dp(a, 4), Ui.dp(a, 3));
                sp.setSpan(wordSpan, hl[2], hl[3], Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
        } else {
            Ocr o = ocrCache.get(page);
            if (o == null) {
                overlay.set(null, null);
                return;
            }
            List<RectF> sentRects = new ArrayList<>();
            List<RectF> wordRects = new ArrayList<>();
            for (Word w : o.words) {
                if (w.end <= hl[0] || w.start >= hl[1]) continue;
                sentRects.addAll(w.rects);
            }
            if (hl[2] >= 0) {
                for (Word w : o.words) {
                    if (w.end <= hl[2] || w.start >= hl[3]) continue;
                    wordRects.addAll(w.rects);
                }
            }
            overlay.set(mergeLines(sentRects), wordRects);
        }
    }

    /** Aynı satırdaki kutuları tek kutuda birleştirir (cümle zemini boşluksuz görünsün). */
    private static List<RectF> mergeLines(List<RectF> in) {
        List<RectF> out = new ArrayList<>();
        for (RectF r : in) {
            if (r.width() <= 0 || r.height() <= 0) continue;
            RectF last = out.isEmpty() ? null : out.get(out.size() - 1);
            if (last != null) {
                float cy = (r.top + r.bottom) / 2f;
                if (cy > last.top && cy < last.bottom && r.left >= last.left - 0.01f) {
                    last.left = Math.min(last.left, r.left);
                    last.right = Math.max(last.right, r.right);
                    last.top = Math.min(last.top, r.top);
                    last.bottom = Math.max(last.bottom, r.bottom);
                    continue;
                }
            }
            out.add(new RectF(r));
        }
        return out;
    }

    /** Okunan kelime ekrandan çıkmasın diye sayfayı kaydırır. */
    private void follow() {
        if (hl == null) return;
        if (textMode) {
            Layout l = txt.getLayout();
            if (l == null) return;
            int off = Math.max(0, Math.min(hl[2] >= 0 ? hl[2] : hl[0], txt.getText().length()));
            int y = l.getLineTop(l.getLineForOffset(off)) + txt.getTotalPaddingTop();
            int h = txtV.getHeight();
            int sy = txtV.getScrollY();
            if (h > 0 && (y < sy + h * 0.12f || y > sy + h * 0.70f)) {
                txtV.smoothScrollTo(0, Math.max(0, Math.round(y - h * 0.28f)));
            }
            return;
        }
        RectF r = overlay.wordBoundsPx();
        if (r == null) r = overlay.sentenceBoundsPx();
        if (r == null) return;
        int h = imgV.getHeight();
        int sy = imgV.getScrollY();
        if (h > 0 && (r.top < sy + h * 0.10f || r.bottom > sy + h * 0.74f)) {
            imgV.smoothScrollTo(0, Math.max(0, Math.round(r.top - h * 0.28f)));
        }
        int w = imgH.getWidth();
        int sx = imgH.getScrollX();
        if (w > 0 && overlay.getWidth() > w && (r.left < sx || r.right > sx + w)) {
            imgH.smoothScrollTo(Math.max(0, Math.round(r.left - w * 0.12f)), 0);
        }
    }

    @Override
    void destroy() {
        destroyed = true;
        try {
            if (recognizer != null) recognizer.close();
        } catch (Exception ignored) {
        }
        recognizer = null;
        io.execute(() -> {
            try {
                pdf.close();
            } catch (Exception ignored) {
            }
            try {
                pfd.close();
            } catch (Exception ignored) {
            }
        });
        io.shutdown();
    }

    // ------------------------------------------------------------------ vurgu çizimi

    /** Metin kipinde okunan kelimenin arkasına yuvarlak köşeli zemin çizer; düzeni değiştirmez. */
    private static final class WordSpan extends ReplacementSpan {
        private final int bg;
        private final int fg;
        private final float radius;
        private final float pad;

        WordSpan(int bg, int fg, int radiusPx, int padPx) {
            this.bg = bg;
            this.fg = fg;
            this.radius = radiusPx;
            this.pad = padPx;
        }

        @Override
        public int getSize(Paint paint, CharSequence text, int start, int end,
                           Paint.FontMetricsInt fm) {
            return Math.round(paint.measureText(text, start, end));
        }

        @Override
        public void draw(Canvas canvas, CharSequence text, int start, int end, float x,
                         int top, int y, int bottom, Paint paint) {
            float w = paint.measureText(text, start, end);
            Paint.FontMetrics m = paint.getFontMetrics();
            RectF r = new RectF(x - pad, y + m.ascent - pad * 0.5f, x + w + pad,
                    y + m.descent + pad * 0.5f);
            Paint p = new Paint(paint);
            p.setStyle(Paint.Style.FILL);
            p.setColor(bg);
            canvas.drawRoundRect(r, radius, radius, p);
            p.setColor(fg);
            canvas.drawText(text, start, end, x, y, p);
        }
    }

    /** Görüntü kipinde sayfa resminin üstüne cümle ve kelime kutularını çizer. */
    private static final class HlView extends View {
        private List<RectF> sent;
        private List<RectF> word;
        private float[] box = {0f, 0f, 1f, 1f};
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private Palette pal;

        HlView(Context c) {
            super(c);
        }

        void setPalette(Palette p) {
            pal = p;
            invalidate();
        }

        void setBox(float[] b) {
            box = b;
            invalidate();
        }

        void set(List<RectF> sentence, List<RectF> words) {
            sent = sentence;
            word = words;
            invalidate();
        }

        private RectF px(RectF f) {
            float bw = Math.max(0.001f, box[2] - box[0]);
            float bh = Math.max(0.001f, box[3] - box[1]);
            float w = getWidth();
            float h = getHeight();
            return new RectF((f.left - box[0]) / bw * w, (f.top - box[1]) / bh * h,
                    (f.right - box[0]) / bw * w, (f.bottom - box[1]) / bh * h);
        }

        RectF wordBoundsPx() {
            return bounds(word);
        }

        RectF sentenceBoundsPx() {
            return bounds(sent);
        }

        private RectF bounds(List<RectF> l) {
            if (l == null || l.isEmpty()) return null;
            RectF u = null;
            for (RectF r : l) {
                RectF p = px(r);
                if (u == null) u = p;
                else u.union(p);
            }
            return u;
        }

        @Override
        protected void onDraw(Canvas c) {
            if (pal == null) return;
            float pad = Ui.dp(getContext(), 2);
            if (sent != null) {
                paint.setColor(pal.hlSentence);
                for (RectF f : sent) {
                    RectF r = px(f);
                    r.inset(-pad, -pad);
                    c.drawRoundRect(r, pad * 2, pad * 2, paint);
                }
            }
            if (word != null) {
                paint.setColor(pal.hlWord);
                for (RectF f : word) {
                    RectF r = px(f);
                    r.inset(-pad * 1.5f, -pad);
                    c.drawRoundRect(r, pad * 2.5f, pad * 2.5f, paint);
                }
            }
        }
    }
}
