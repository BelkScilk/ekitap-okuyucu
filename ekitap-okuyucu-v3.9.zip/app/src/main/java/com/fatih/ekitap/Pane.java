package com.fatih.ekitap;

import android.app.Activity;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;

/** Okuma yüzeyi (EPUB veya PDF) için ortak sözleşme. */
abstract class Pane {

    interface Host {
        Activity activity();

        Prefs prefs();

        Palette pal();

        Handler ui();

        /** Okuma konumu değişti (kaydırma, bölüm/sayfa geçişi). */
        void onPosition();

        /** Yeni bölüm/sayfa içeriği hazır. */
        void onUnitLoaded();

        /** Kullanıcı bağlantı ile başka yere gitti (okuma durmalı). */
        void onUserNavigated();

        void onMessage(String msg);
    }

    interface SpeechCb {
        /** text: okunacak tüm metin, start: okumaya başlanacak konum. */
        void on(String text, int start);
    }

    protected final Host host;
    protected final String key;

    Pane(Host host, String key) {
        this.host = host;
        this.key = key;
    }

    abstract View view();

    /** Kayıtlı konumdan açar. */
    abstract void open();

    abstract int unitCount();

    abstract int unit();

    /** Bölüm/sayfa içindeki konum (0..1). */
    abstract float frac();

    abstract void go(int unit, float frac);

    /** Dokunarak sayfa çevirme; çevrilecek yer yoksa false. */
    abstract boolean step(boolean forward);

    abstract void applyStyle();

    abstract String unitLabel();

    abstract String unitTitle();

    /** Konuşulacak metni hazırlar. fromVisible: ekranda görünen yerden başla. */
    abstract void requestSpeech(boolean fromVisible, SpeechCb cb);

    /** Okunan cümle [sa,sb) ve kelime [wa,wb) aralığını gösterir; wa<0 ise yalnız cümle. */
    abstract void highlight(int sa, int sb, int wa, int wb);

    abstract void clearHighlight();

    /** Yer imi için etiket (bölüm adı, sayfa no). */
    abstract String bookmarkLabel();

    abstract void saveProgress();

    abstract void destroy();

    /** Etkinliğin dokunma olayları (yakınlaştırma / kaydırma hareketleri için). */
    void onTouch(MotionEvent ev) {
        edgePull(ev);
    }

    // ---- sürekli kaydırma: bölümün/sayfanın ucundayken kaydırmaya devam edince sonrakine/öncekine geç

    private float pullLastY;
    private float pullStartX;
    private float pullAcc;
    private boolean pullFired;
    private boolean pullFwd;

    /** Şu an kaydırılan görünüm (yoksa null). */
    protected View scrollTarget() {
        return null;
    }

    /** Görünüm kaydırma ucunda mı (1-2 piksellik yuvarlama farkına toleranslı). */
    protected boolean atEdge(View v, boolean forward) {
        return !v.canScrollVertically(forward ? 1 : -1);
    }

    /** Sonraki (forward) veya önceki bölüme/sayfaya geçer; geçildiyse true. */
    protected boolean edgeNav(boolean forward) {
        return false;
    }

    protected final void edgePull(MotionEvent ev) {
        if (!host.prefs().scrollFlow()) return;
        View v = scrollTarget();
        if (v == null) return;
        switch (ev.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                pullLastY = ev.getY();
                pullStartX = ev.getX();
                pullAcc = 0f;
                pullFired = false;
                break;
            case MotionEvent.ACTION_MOVE:
                if (pullFired || ev.getPointerCount() != 1) return;
                float dy = ev.getY() - pullLastY;
                pullLastY = ev.getY();
                if (dy == 0f) return;
                // parmak yukarı = aşağı kaydırma (sonraki), parmak aşağı = yukarı kaydırma (önceki)
                boolean forward = dy < 0;
                if (!atEdge(v, forward)) {
                    pullAcc = 0f;
                    return;
                }
                if (forward != pullFwd) {
                    pullFwd = forward;
                    pullAcc = 0f;
                }
                pullAcc += Math.abs(dy);
                float limit = 56f * host.activity().getResources().getDisplayMetrics().density;
                boolean horiz = Math.abs(ev.getX() - pullStartX) > pullAcc;
                if (!horiz && pullAcc >= limit) {
                    pullFired = true;
                    pullAcc = 0f;
                    edgeNav(forward);
                }
                break;
            default:
                break;
        }
    }

    /** Ekranda görünür bir değişiklik olunca (ör. çubuklar) yeniden yerleşim gerekir mi. */
    void onResized() {
    }

    /** Tüm kitap üzerindeki konum (0..1). */
    float overall() {
        int n = Math.max(1, unitCount());
        return Math.max(0f, Math.min(1f, (unit() + frac()) / n));
    }

    void seekOverall(float f) {
        int n = Math.max(1, unitCount());
        float x = Math.max(0f, Math.min(0.9999f, f)) * n;
        int u = (int) x;
        go(u, x - u);
    }
}
