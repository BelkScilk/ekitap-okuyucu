package com.fatih.ekitap;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Konuşma metnini cümle gruplarına böler ve ses motorunun bildirdiği kelime aralığını tam kelimeye
 * oturtur. Android'e bağımlı değildir (ayrı test edilebilir).
 */
final class Seg {
    private Seg() {
    }

    static boolean isWs(char c) {
        return c <= ' ' || c == ' ' || c == ' ' || c == ' ';
    }

    private static boolean isCloser(char c) {
        return c == '"' || c == '\'' || c == '”' || c == '’' || c == ')' || c == ']'
                || c == '»';
    }

    private static final String[] ABBREV = {"dr", "prof", "doç", "doc", "sn", "av", "bkz", "no",
            "st", "mr", "mrs", "ms", "vs", "vb", "örn", "yy", "mö", "ms", "tel", "sy", "cad",
            "sok", "mah", "bk", "böl", "yrd", "uzm", "op", "dz", "alb", "gen", "kur", "müh"};

    /** '.' karakterinin cümle sonu olup olmadığını (kısaltma / sıra numarası değil mi) kestirir. */
    private static boolean dotEndsSentence(String t, int dot) {
        int a = dot;
        while (a > 0 && !isWs(t.charAt(a - 1)) && t.charAt(a - 1) != '(') a--;
        String tok = t.substring(a, dot);
        if (tok.isEmpty()) return true;
        boolean allDigits = true;
        for (int i = 0; i < tok.length(); i++) {
            if (!Character.isDigit(tok.charAt(i))) {
                allDigits = false;
                break;
            }
        }
        if (allDigits && tok.length() <= 3) {
            // "3. BÖLÜM" gibi sıra numarası: sonraki sözcük büyük harfle başlıyorsa bölme
            int j = dot + 1;
            while (j < t.length() && isWs(t.charAt(j))) j++;
            return !(j < t.length() && Character.isUpperCase(t.charAt(j)));
        }
        if (tok.length() == 1 && Character.isLetter(tok.charAt(0))) return false; // "A. Yılmaz"
        String low = tok.toLowerCase(new Locale("tr", "TR"));
        for (String ab : ABBREV) {
            if (low.equals(ab)) return false;
        }
        return true;
    }

    /**
     * Metni konuşulacak parçalara böler. Her parça text içinde {başlangıç, bitiş} (bitiş hariç)
     * aralığıdır; boşluklar dışarıda kalır. maxLen aşılmaz.
     */
    static List<int[]> split(String text, int maxLen) {
        List<int[]> raw = new ArrayList<>();
        int n = text.length();
        int segStart = -1;
        for (int i = 0; i < n; i++) {
            char c = text.charAt(i);
            if (segStart < 0) {
                if (isWs(c)) continue;
                segStart = i;
            }
            int end = -1;
            if (c == '\n') {
                end = i;
            } else if (c == '.' || c == '!' || c == '?' || c == '…') {
                int j = i + 1;
                while (j < n && (isCloser(text.charAt(j)) || text.charAt(j) == '.'
                        || text.charAt(j) == '!' || text.charAt(j) == '?')) {
                    j++;
                }
                if (j >= n || isWs(text.charAt(j))) {
                    if (c != '.' || j > i + 1 || dotEndsSentence(text, i)) {
                        end = j;
                        i = j - 1;
                    }
                }
            } else if (i - segStart + 1 >= maxLen) {
                int cut = -1;
                for (int k = i; k > segStart + maxLen / 2; k--) {
                    char d = text.charAt(k);
                    if (isWs(d)) {
                        cut = k;
                        break;
                    }
                }
                if (cut < 0) {
                    for (int k = i; k > segStart + maxLen / 2; k--) {
                        char d = text.charAt(k);
                        if (d == ',' || d == ';' || d == ':' || d == '-') {
                            cut = k + 1;
                            break;
                        }
                    }
                }
                end = cut < 0 ? i + 1 : cut;
                i = end - 1;
            }
            if (end >= 0) {
                int e = end;
                while (e > segStart && isWs(text.charAt(e - 1))) e--;
                if (e > segStart) raw.add(new int[]{segStart, e});
                segStart = -1;
            }
        }
        if (segStart >= 0) {
            int e = n;
            while (e > segStart && isWs(text.charAt(e - 1))) e--;
            if (e > segStart) raw.add(new int[]{segStart, e});
        }

        // Çok kısa cümleleri aynı paragraf içinde komşusuyla birleştir
        List<int[]> out = new ArrayList<>();
        for (int[] s : raw) {
            if (!out.isEmpty()) {
                int[] last = out.get(out.size() - 1);
                int len = last[1] - last[0];
                boolean newline = text.substring(last[1], s[0]).indexOf('\n') >= 0;
                if (len < 50 && !newline && s[1] - last[0] <= maxLen) {
                    last[1] = s[1];
                    continue;
                }
            }
            out.add(new int[]{s[0], s[1]});
        }
        return out;
    }

    static boolean isWordChar(String s, int i) {
        if (i < 0 || i >= s.length()) return false;
        char c = s.charAt(i);
        if (Character.isLetterOrDigit(c)) return true;
        if (c == '\'' || c == '’') {
            return i > 0 && i + 1 < s.length()
                    && Character.isLetterOrDigit(s.charAt(i - 1))
                    && Character.isLetterOrDigit(s.charAt(i + 1));
        }
        return false;
    }

    /**
     * Ses motorunun verdiği [start,end) aralığını, o parçadaki tam kelimeye oturtur.
     * Motor birkaç karakter şaşırsa bile ortadaki harfin ait olduğu kelime bulunur. Bulunamazsa null.
     */
    static int[] snapWord(String c, int start, int end) {
        int n = c.length();
        if (n == 0) return null;
        int s = Math.max(0, Math.min(start, n - 1));
        int e = Math.max(s + 1, Math.min(end, n));
        int p = Math.min((s + e) / 2, n - 1);
        if (!isWordChar(c, p)) {
            int found = -1;
            for (int d = 1; d <= 4 && found < 0; d++) {
                if (isWordChar(c, p + d)) found = p + d;
                else if (isWordChar(c, p - d)) found = p - d;
            }
            if (found < 0) return null;
            p = found;
        }
        int a = p;
        while (a > 0 && isWordChar(c, a - 1)) a--;
        int b = p + 1;
        while (b < n && isWordChar(c, b)) b++;
        return new int[]{a, b};
    }

    /** from konumundan sonraki ilk kelimenin aralığı; yoksa null. */
    static int[] nextWord(String c, int from) {
        int n = c.length();
        int i = Math.max(0, from);
        while (i < n && !isWordChar(c, i)) i++;
        if (i >= n) return null;
        int b = i + 1;
        while (b < n && isWordChar(c, b)) b++;
        return new int[]{i, b};
    }
}
