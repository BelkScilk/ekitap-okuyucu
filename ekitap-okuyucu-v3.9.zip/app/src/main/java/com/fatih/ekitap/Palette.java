package com.fatih.ekitap;

import android.graphics.Color;

/** Uygulamanın dört teması: renkler hem arayüzde hem okuma sayfasında kullanılır. */
final class Palette {
    static final int LIGHT = 0;
    static final int DARK = 1;
    static final int SEPIA = 2;
    static final int BLACK = 3;
    static final int NIGHT = 4;
    static final int AMBER = 5;
    static final int COUNT = 6;

    final int id;
    final String name;
    final boolean lightUi;   // arka plan açık renkli mi (durum çubuğu simgeleri için)
    final int bg;            // sayfa / ekran arka planı
    final int surface;       // kart, panel
    final int surfaceAlt;    // ikincil zemin (çip, giriş kutusu)
    final int fg;            // ana yazı
    final int muted;         // ikincil yazı
    final int accent;        // vurgu rengi
    final int accentOn;      // vurgu üzerindeki yazı
    final int line;          // ince çizgiler
    final int link;          // bağlantı rengi
    final int hlWord;        // okunan kelime zemini (ARGB)
    final int hlSentence;    // okunan cümle zemini (ARGB)

    private Palette(int id, String name, boolean lightUi, int bg, int surface, int surfaceAlt,
                    int fg, int muted, int accent, int accentOn, int line, int link,
                    int hlWord, int hlSentence) {
        this.id = id;
        this.name = name;
        this.lightUi = lightUi;
        this.bg = bg;
        this.surface = surface;
        this.surfaceAlt = surfaceAlt;
        this.fg = fg;
        this.muted = muted;
        this.accent = accent;
        this.accentOn = accentOn;
        this.line = line;
        this.link = link;
        this.hlWord = hlWord;
        this.hlSentence = hlSentence;
    }

    private static final Palette[] ALL = {
            new Palette(LIGHT, "Açık", true,
                    0xFFFAF8F4, 0xFFFFFFFF, 0xFFEFEAE0, 0xFF1F1D1A, 0xFF7A746A,
                    0xFFB5532B, 0xFFFFFFFF, 0xFFE4DED3, 0xFF8A3F1E,
                    0x99FFC857, 0x40FFC857),
            new Palette(DARK, "Koyu", false,
                    0xFF15171A, 0xFF1F2226, 0xFF2A2E33, 0xFFE6E1D6, 0xFF9A958A,
                    0xFFE0A458, 0xFF1A1A1A, 0xFF2F3338, 0xFF8AB4F8,
                    0x80FFC857, 0x30FFC857),
            new Palette(SEPIA, "Sepya", true,
                    0xFFF3E8D0, 0xFFFAF1DD, 0xFFE8DAB8, 0xFF4A3A2A, 0xFF8D7A62,
                    0xFFA8552B, 0xFFFFFFFF, 0xFFDCCBA5, 0xFF8B4513,
                    0x99E8A54B, 0x40E8A54B),
            new Palette(BLACK, "Siyah", false,
                    0xFF000000, 0xFF0E0F10, 0xFF1A1B1D, 0xFFD8D3C8, 0xFF8A857B,
                    0xFFE0A458, 0xFF1A1A1A, 0xFF222426, 0xFF8AB4F8,
                    0x80FFC857, 0x30FFC857),
            new Palette(NIGHT, "Gece", false,
                    0xFF070000, 0xFF140505, 0xFF220B0A, 0xFFD2432D, 0xFF8C2A22,
                    0xFFE0523A, 0xFF1A0000, 0xFF2C0F0C, 0xFFE8694D,
                    0x70FF5A3C, 0x28FF5A3C),
            new Palette(AMBER, "Kehribar", false,
                    0xFF0C0A05, 0xFF16130A, 0xFF231E10, 0xFFB38F2E, 0xFF7A6424,
                    0xFFC9A227, 0xFF140F00, 0xFF2A2412, 0xFFD4AE3C,
                    0x66D9B13A, 0x26D9B13A),
    };

    static Palette of(int id) {
        if (id < 0 || id >= ALL.length) return ALL[DARK];
        return ALL[id];
    }

    /** Rengin CSS karşılığı: #RRGGBB */
    static String css(int c) {
        return String.format("#%06X", c & 0xFFFFFF);
    }

    /** Alfa kanalı olan rengin CSS karşılığı: rgba(r,g,b,a) */
    static String cssA(int argb) {
        return "rgba(" + Color.red(argb) + "," + Color.green(argb) + "," + Color.blue(argb) + ","
                + String.format(java.util.Locale.US, "%.2f", Color.alpha(argb) / 255f) + ")";
    }

    /** İki rengi karıştırır (t=0 ilk, t=1 ikinci). */
    static int mix(int a, int b, float t) {
        float u = 1f - t;
        return Color.argb(
                Math.round(Color.alpha(a) * u + Color.alpha(b) * t),
                Math.round(Color.red(a) * u + Color.red(b) * t),
                Math.round(Color.green(a) * u + Color.green(b) * t),
                Math.round(Color.blue(a) * u + Color.blue(b) * t));
    }

    static int withAlpha(int c, int alpha) {
        return Color.argb(alpha, Color.red(c), Color.green(c), Color.blue(c));
    }
}
