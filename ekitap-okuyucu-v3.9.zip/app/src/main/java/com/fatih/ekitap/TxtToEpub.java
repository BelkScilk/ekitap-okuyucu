package com.fatih.ekitap;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.Charset;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;
import java.util.zip.CRC32;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/** Düz metin (.txt) dosyasını okuyucunun anladığı basit bir EPUB'a çevirir. */
final class TxtToEpub {
    private TxtToEpub() {
    }

    private static final int MAX_CHAPTER = 30000;
    private static final Pattern HEADING = Pattern.compile(
            "^\\s*((?iu:bölüm|bolum|kısım|kisim|chapter|part|kitap|book)\\s+[\\p{L}\\p{N}.\\-]{1,12}.{0,60}"
                    + "|[IVXLC]{1,7}\\.?|\\d{1,3}\\.?)\\s*$");

    /** İlk 8 KB'ta NUL baytı yoksa metin sayılır. */
    static boolean looksLikeText(File f) {
        try (FileInputStream in = new FileInputStream(f)) {
            byte[] b = new byte[8192];
            int n = in.read(b);
            if (n <= 0) return false;
            for (int i = 0; i < n; i++) {
                if (b[i] == 0) return false;
            }
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    static String decode(byte[] data) {
        int off = 0;
        if (data.length >= 3 && (data[0] & 255) == 0xEF && (data[1] & 255) == 0xBB
                && (data[2] & 255) == 0xBF) {
            off = 3;
        } else if (data.length >= 2 && (data[0] & 255) == 0xFF && (data[1] & 255) == 0xFE) {
            return new String(data, 2, data.length - 2, StandardCharsets.UTF_16LE);
        } else if (data.length >= 2 && (data[0] & 255) == 0xFE && (data[1] & 255) == 0xFF) {
            return new String(data, 2, data.length - 2, StandardCharsets.UTF_16BE);
        }
        try {
            return StandardCharsets.UTF_8.newDecoder()
                    .onMalformedInput(CodingErrorAction.REPORT)
                    .onUnmappableCharacter(CodingErrorAction.REPORT)
                    .decode(ByteBuffer.wrap(data, off, data.length - off)).toString();
        } catch (CharacterCodingException e) {
            try {
                return new String(data, off, data.length - off, Charset.forName("windows-1254"));
            } catch (Exception ex) {
                return new String(data, off, data.length - off, StandardCharsets.ISO_8859_1);
            }
        }
    }

    static String esc(String s) {
        StringBuilder b = new StringBuilder(s.length() + 16);
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '&') b.append("&amp;");
            else if (c == '<') b.append("&lt;");
            else if (c == '>') b.append("&gt;");
            else if (c >= 0x20 || c == '\t') b.append(c);
        }
        return b.toString();
    }

    static final class Chapter {
        final String title;
        final StringBuilder html = new StringBuilder();
        int chars;

        Chapter(String title) {
            this.title = title;
        }
    }

    /** Metni paragraflara ve bölümlere ayırır. */
    static List<Chapter> split(String text, String bookTitle) {
        text = text.replace("\r\n", "\n").replace('\r', '\n').replace(' ', ' ');
        String[] lines = text.split("\n", -1);
        int blank = 0;
        int nonBlank = 0;
        for (String l : lines) {
            if (l.trim().isEmpty()) blank++;
            else nonBlank++;
        }
        // Boş satır neredeyse yoksa her satır bir paragraftır; varsa boş satırlar ayırır.
        boolean linePerPara = nonBlank > 0 && blank < nonBlank * 0.04;

        List<String> paras = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        for (String l : lines) {
            String t = l.trim();
            if (t.isEmpty()) {
                if (cur.length() > 0) {
                    paras.add(cur.toString());
                    cur.setLength(0);
                }
            } else if (linePerPara) {
                paras.add(t);
            } else {
                if (cur.length() > 0) {
                    // satır sonu tireli bölünmüş kelimeyi birleştir
                    if (cur.charAt(cur.length() - 1) == '-' && cur.length() > 1
                            && Character.isLetter(cur.charAt(cur.length() - 2))
                            && Character.isLowerCase(t.charAt(0))) {
                        cur.setLength(cur.length() - 1);
                    } else {
                        cur.append(' ');
                    }
                }
                cur.append(t);
            }
        }
        if (cur.length() > 0) paras.add(cur.toString());

        List<Chapter> out = new ArrayList<>();
        Chapter ch = new Chapter(bookTitle);
        for (String p : paras) {
            boolean heading = p.length() <= 70 && HEADING.matcher(p).matches();
            if (heading && ch.chars > 800) {
                out.add(ch);
                ch = new Chapter(p);
            } else if (ch.chars >= MAX_CHAPTER && p.length() < 2000) {
                // başlık yoksa uzun bölümü paragraf sınırında böl
                out.add(ch);
                ch = new Chapter(bookTitle + " (" + (out.size() + 1) + ")");
            }
            if (heading) ch.html.append("<h2>").append(esc(p)).append("</h2>\n");
            else ch.html.append("<p>").append(esc(p)).append("</p>\n");
            ch.chars += p.length();
        }
        if (ch.chars > 0 || out.isEmpty()) out.add(ch);
        // ilk başlıksız bölüme kitap adı yerine "Başlangıç" mantığı gerekmez; kitap adı kalır.
        return out;
    }

    private static void put(ZipOutputStream z, String name, byte[] data, boolean stored)
            throws IOException {
        ZipEntry e = new ZipEntry(name);
        if (stored) {
            e.setMethod(ZipEntry.STORED);
            e.setSize(data.length);
            CRC32 crc = new CRC32();
            crc.update(data);
            e.setCrc(crc.getValue());
        }
        z.putNextEntry(e);
        z.write(data);
        z.closeEntry();
    }

    private static byte[] b(String s) {
        return s.getBytes(StandardCharsets.UTF_8);
    }

    /** src (.txt) dosyasından dest (.epub) üretir. */
    static void convert(File src, File dest, String title) throws IOException {
        byte[] data = new byte[(int) src.length()];
        try (FileInputStream in = new FileInputStream(src)) {
            int off = 0;
            while (off < data.length) {
                int n = in.read(data, off, data.length - off);
                if (n < 0) break;
                off += n;
            }
        }
        String text = decode(data);
        if (text.trim().isEmpty()) throw new IOException("Metin dosyası boş");
        String t = title == null || title.trim().isEmpty() ? "Metin" : title.trim();
        List<Chapter> chs = split(text, t);
        try (ZipOutputStream z = new ZipOutputStream(new FileOutputStream(dest))) {
            put(z, "mimetype", b("application/epub+zip"), true);
            put(z, "META-INF/container.xml", b("<?xml version=\"1.0\"?><container version=\"1.0\" "
                    + "xmlns=\"urn:oasis:names:tc:opendocument:xmlns:container\"><rootfiles>"
                    + "<rootfile full-path=\"OEBPS/content.opf\" "
                    + "media-type=\"application/oebps-package+xml\"/></rootfiles></container>"), false);
            StringBuilder manifest = new StringBuilder();
            StringBuilder spine = new StringBuilder();
            StringBuilder nav = new StringBuilder();
            for (int i = 0; i < chs.size(); i++) {
                String id = "c" + i;
                String file = "c" + i + ".xhtml";
                manifest.append("<item id=\"").append(id).append("\" href=\"").append(file)
                        .append("\" media-type=\"application/xhtml+xml\"/>");
                spine.append("<itemref idref=\"").append(id).append("\"/>");
                nav.append("<li><a href=\"").append(file).append("\">")
                        .append(esc(chs.get(i).title)).append("</a></li>");
                String page = "<?xml version=\"1.0\" encoding=\"utf-8\"?><html xmlns=\"http://www.w3.org/1999/xhtml\">"
                        + "<head><meta charset=\"utf-8\"/><title>" + esc(chs.get(i).title) + "</title></head><body>"
                        + chs.get(i).html + "</body></html>";
                put(z, "OEBPS/" + file, b(page), false);
            }
            put(z, "OEBPS/nav.xhtml", b("<?xml version=\"1.0\" encoding=\"utf-8\"?>"
                    + "<html xmlns=\"http://www.w3.org/1999/xhtml\" xmlns:epub=\"http://www.idpf.org/2007/ops\">"
                    + "<head><meta charset=\"utf-8\"/><title>İçindekiler</title></head><body>"
                    + "<nav epub:type=\"toc\"><ol>" + nav + "</ol></nav></body></html>"), false);
            put(z, "OEBPS/content.opf", b("<?xml version=\"1.0\" encoding=\"utf-8\"?>"
                    + "<package xmlns=\"http://www.idpf.org/2007/opf\" version=\"3.0\" unique-identifier=\"id\">"
                    + "<metadata xmlns:dc=\"http://purl.org/dc/elements/1.1/\">"
                    + "<dc:identifier id=\"id\">txt-" + Integer.toHexString(text.hashCode()) + "</dc:identifier>"
                    + "<dc:title>" + esc(t) + "</dc:title><dc:language>tr</dc:language></metadata>"
                    + "<manifest><item id=\"nav\" href=\"nav.xhtml\" media-type=\"application/xhtml+xml\" "
                    + "properties=\"nav\"/>" + manifest + "</manifest><spine>" + spine + "</spine></package>"), false);
        }
    }
}
