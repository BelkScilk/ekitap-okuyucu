package com.fatih.ekitap;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

/** Arayüz kurma yardımcıları: ölçüler, yuvarlak zeminler, yazılar, düğmeler, alt panel. */
final class Ui {
    private Ui() {
    }

    static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    // ------------------------------------------------------------------ zeminler

    static GradientDrawable rect(Context c, int color, float radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(c, radiusDp));
        return d;
    }

    static GradientDrawable rectTop(Context c, int color, float radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        float r = dp(c, radiusDp);
        d.setCornerRadii(new float[]{r, r, r, r, 0, 0, 0, 0});
        return d;
    }

    static GradientDrawable outline(Context c, int fill, int stroke, float strokeDp, float radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setStroke(Math.max(1, dp(c, strokeDp)), stroke);
        d.setCornerRadius(dp(c, radiusDp));
        return d;
    }

    static GradientDrawable circle(int color) {
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.OVAL);
        d.setColor(color);
        return d;
    }

    /** Dokununca dalga efekti veren zemin. content null olabilir. */
    static Drawable ripple(Context c, Drawable content, int rippleColor, float radiusDp) {
        GradientDrawable mask = new GradientDrawable();
        mask.setColor(Color.BLACK);
        mask.setCornerRadius(dp(c, radiusDp));
        return new RippleDrawable(ColorStateList.valueOf(rippleColor), content, mask);
    }

    static void press(View v, Palette p, int fill, float radiusDp) {
        Drawable base = fill == 0 ? null : rect(v.getContext(), fill, radiusDp);
        v.setBackground(ripple(v.getContext(), base, Palette.withAlpha(p.fg, 40), radiusDp));
        v.setClickable(true);
    }

    // ------------------------------------------------------------------ yazılar

    static TextView text(Context c, CharSequence s, float sp, int color) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setIncludeFontPadding(false);
        return t;
    }

    static TextView bold(Context c, CharSequence s, float sp, int color) {
        TextView t = text(c, s, sp, color);
        t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        return t;
    }

    static TextView serif(Context c, CharSequence s, float sp, int color) {
        TextView t = text(c, s, sp, color);
        t.setTypeface(Typeface.create(Typeface.SERIF, Typeface.BOLD));
        return t;
    }

    static TextView oneLine(TextView t) {
        t.setSingleLine(true);
        t.setEllipsize(TextUtils.TruncateAt.END);
        return t;
    }

    // ------------------------------------------------------------------ düğmeler

    static ImageView icon(Context c, int type, int color, int sizeDp, int padDp) {
        ImageView v = new ImageView(c);
        v.setImageDrawable(Icons.get(type, color));
        int s = dp(c, sizeDp);
        v.setLayoutParams(new LinearLayout.LayoutParams(s, s));
        v.setPadding(dp(c, padDp), dp(c, padDp), dp(c, padDp), dp(c, padDp));
        v.setScaleType(ImageView.ScaleType.FIT_CENTER);
        return v;
    }

    /** Yuvarlak, dalga efektli ikon düğmesi. */
    static ImageView iconButton(Context c, Palette p, int type, int color, int sizeDp, int padDp) {
        ImageView v = icon(c, type, color, sizeDp, padDp);
        v.setBackground(ripple(c, null, Palette.withAlpha(p.fg, 45), sizeDp / 2f));
        v.setClickable(true);
        v.setFocusable(true);
        return v;
    }

    /** Hap biçimli yazı düğmesi. filled=true ise vurgu renginde dolu. */
    static TextView pill(Context c, Palette p, CharSequence label, boolean filled) {
        TextView t = bold(c, label, 14f, filled ? p.accentOn : p.fg);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(c, 18), dp(c, 10), dp(c, 18), dp(c, 10));
        press(t, p, filled ? p.accent : p.surfaceAlt, 22);
        return t;
    }

    /** Seçili / seçili değil durumlu küçük çip. */
    static TextView chip(Context c, Palette p, CharSequence label, boolean selected) {
        TextView t = bold(c, label, 13.5f, selected ? p.accentOn : p.fg);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(c, 14), dp(c, 8), dp(c, 14), dp(c, 8));
        press(t, p, selected ? p.accent : p.surfaceAlt, 18);
        return t;
    }

    static SeekBar seek(Context c, Palette p, int max, int progress) {
        SeekBar s = new SeekBar(c);
        s.setMax(max);
        s.setProgress(progress);
        s.setProgressTintList(ColorStateList.valueOf(p.accent));
        s.setThumbTintList(ColorStateList.valueOf(p.accent));
        s.setProgressBackgroundTintList(ColorStateList.valueOf(Palette.withAlpha(p.fg, 50)));
        s.setPadding(dp(c, 12), dp(c, 10), dp(c, 12), dp(c, 10));
        return s;
    }

    static Switch toggle(Context c, Palette p, boolean on) {
        Switch s = new Switch(c);
        s.setChecked(on);
        int[][] states = {{android.R.attr.state_checked}, {}};
        s.setThumbTintList(new ColorStateList(states, new int[]{p.accent, p.muted}));
        s.setTrackTintList(new ColorStateList(states,
                new int[]{Palette.withAlpha(p.accent, 110), Palette.withAlpha(p.fg, 50)}));
        return s;
    }

    // ------------------------------------------------------------------ yerleşim

    static LinearLayout.LayoutParams lp(int w, int h) {
        return new LinearLayout.LayoutParams(w, h);
    }

    static LinearLayout.LayoutParams lpWeight(int w, int h, float weight) {
        return new LinearLayout.LayoutParams(w, h, weight);
    }

    static LinearLayout.LayoutParams lpMargin(int w, int h, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(l, t, r, b);
        return p;
    }

    static View divider(Context c, Palette p) {
        View v = new View(c);
        v.setBackgroundColor(p.line);
        v.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Math.max(1, dp(c, 0.7f))));
        return v;
    }

    static View space(Context c, int heightDp) {
        View v = new View(c);
        v.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(c, heightDp)));
        return v;
    }

    // ------------------------------------------------------------------ hazır satırlar (paneller için)

    interface IntListener {
        void on(int value);
    }

    interface BoolListener {
        void on(boolean value);
    }

    static TextView sectionTitle(Context c, Palette p, String s) {
        TextView t = bold(c, s.toUpperCase(new java.util.Locale("tr", "TR")), 11.5f, p.muted);
        t.setLetterSpacing(0.08f);
        t.setPadding(dp(c, 20), dp(c, 18), dp(c, 20), dp(c, 6));
        return t;
    }

    /** Başlık + değer + kaydırıcı satırı. */
    static View sliderRow(Context c, Palette p, String label, int min, int max, int value,
                          java.util.function.IntFunction<String> fmt, IntListener l) {
        LinearLayout box = new LinearLayout(c);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(c, 20), dp(c, 8), dp(c, 20), dp(c, 4));
        LinearLayout head = new LinearLayout(c);
        head.setOrientation(LinearLayout.HORIZONTAL);
        TextView name = text(c, label, 15f, p.fg);
        final TextView val = bold(c, fmt.apply(value), 14f, p.accent);
        head.addView(name, lpWeight(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        head.addView(val, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        box.addView(head, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        SeekBar s = seek(c, p, max - min, value - min);
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar sb, int progress, boolean fromUser) {
                val.setText(fmt.apply(progress + min));
            }

            @Override
            public void onStartTrackingTouch(SeekBar sb) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar sb) {
                l.on(sb.getProgress() + min);
            }
        });
        box.addView(s, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return box;
    }

    /** Başlık + açma/kapama anahtarı. */
    static View switchRow(Context c, Palette p, String label, String hint, boolean on, BoolListener l) {
        LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(c, 20), dp(c, 10), dp(c, 20), dp(c, 10));
        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        col.addView(text(c, label, 15f, p.fg));
        if (hint != null) {
            TextView h = text(c, hint, 12.5f, p.muted);
            h.setPadding(0, dp(c, 2), 0, 0);
            col.addView(h);
        }
        final Switch sw = toggle(c, p, on);
        row.addView(col, lpWeight(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(sw, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        sw.setOnCheckedChangeListener((b, checked) -> l.on(checked));
        row.setOnClickListener(v -> sw.toggle());
        return row;
    }

    /** Tek seçimli yatay çip dizisi. */
    static View chipRow(Context c, Palette p, String[] labels, int selected, IntListener l) {
        android.widget.HorizontalScrollView hs = new android.widget.HorizontalScrollView(c);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(dp(c, 16), dp(c, 4), dp(c, 16), dp(c, 4));
        final TextView[] chips = new TextView[labels.length];
        for (int i = 0; i < labels.length; i++) {
            final int idx = i;
            chips[i] = chip(c, p, labels[i], i == selected);
            chips[i].setOnClickListener(v -> {
                for (int k = 0; k < chips.length; k++) {
                    boolean sel = k == idx;
                    chips[k].setTextColor(sel ? p.accentOn : p.fg);
                    press(chips[k], p, sel ? p.accent : p.surfaceAlt, 18);
                }
                l.on(idx);
            });
            row.addView(chips[i], lpMargin(ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT, dp(c, 4), 0, dp(c, 4), 0));
        }
        hs.addView(row);
        return hs;
    }

    /** Dokunulabilir tek satır (simge yok): başlık + alt yazı. */
    static View actionRow(Context c, Palette p, int iconType, String label, String hint) {
        LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(c, 20), dp(c, 13), dp(c, 20), dp(c, 13));
        press(row, p, 0, 0);
        if (iconType >= 0) {
            ImageView ic = icon(c, iconType, p.accent, 24, 1);
            row.addView(ic, lpMargin(dp(c, 24), dp(c, 24), 0, 0, dp(c, 16), 0));
        }
        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        col.addView(text(c, label, 15.5f, p.fg));
        if (hint != null && !hint.isEmpty()) {
            TextView h = text(c, hint, 12.5f, p.muted);
            h.setPadding(0, dp(c, 3), 0, 0);
            col.addView(h);
        }
        row.addView(col, lpWeight(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        return row;
    }

    static android.widget.EditText input(Context c, Palette p, String hint, String initial) {
        android.widget.EditText e = new android.widget.EditText(c);
        e.setHint(hint);
        e.setText(initial);
        e.setTextColor(p.fg);
        e.setHintTextColor(p.muted);
        e.setTextSize(16f);
        e.setSingleLine(true);
        e.setPadding(dp(c, 16), dp(c, 12), dp(c, 16), dp(c, 12));
        e.setBackground(rect(c, p.surfaceAlt, 14));
        return e;
    }

    // ------------------------------------------------------------------ alt panel

    /** En fazla maxHeight kadar yükselen kaydırma alanı. */
    static final class MaxHeightScroll extends ScrollView {
        private int maxHeight = Integer.MAX_VALUE;

        MaxHeightScroll(Context c) {
            super(c);
        }

        void setMaxHeight(int h) {
            maxHeight = h;
        }

        @Override
        protected void onMeasure(int w, int h) {
            int spec = MeasureSpec.makeMeasureSpec(maxHeight, MeasureSpec.AT_MOST);
            super.onMeasure(w, spec);
        }
    }

    /** Ekranın altından yukarı kayan yuvarlak köşeli panel. */
    static final class Sheet {
        private final Activity act;
        private final Dialog dlg;
        private final LinearLayout panel;
        private final LinearLayout body;
        private boolean closing;

        Sheet(Activity a, Palette p, String title) {
            act = a;
            dlg = new Dialog(a, android.R.style.Theme_DeviceDefault_Dialog_NoActionBar);
            Window w = dlg.getWindow();
            if (w != null) {
                w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
                w.setGravity(Gravity.BOTTOM);
                w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
                w.setDimAmount(0.5f);
                w.setWindowAnimations(0);
                w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
            }
            FrameLayout root = new FrameLayout(a);
            root.setOnClickListener(v -> dismiss());

            panel = new LinearLayout(a);
            panel.setOrientation(LinearLayout.VERTICAL);
            panel.setBackground(rectTop(a, p.surface, 24));
            panel.setClickable(true); // panele dokunmak kapatmasın
            panel.setElevation(dp(a, 12));

            View handle = new View(a);
            handle.setBackground(rect(a, Palette.withAlpha(p.fg, 60), 3));
            LinearLayout.LayoutParams hp = lp(dp(a, 40), dp(a, 4));
            hp.gravity = Gravity.CENTER_HORIZONTAL;
            hp.topMargin = dp(a, 10);
            panel.addView(handle, hp);

            if (title != null) {
                LinearLayout head = new LinearLayout(a);
                head.setOrientation(LinearLayout.HORIZONTAL);
                head.setGravity(Gravity.CENTER_VERTICAL);
                head.setPadding(dp(a, 20), dp(a, 10), dp(a, 8), dp(a, 4));
                TextView t = serif(a, title, 20f, p.fg);
                head.addView(t, lpWeight(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
                ImageView close = iconButton(a, p, Icons.CLOSE, p.muted, 40, 10);
                close.setOnClickListener(v -> dismiss());
                head.addView(close);
                panel.addView(head, lp(ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT));
            }

            MaxHeightScroll sv = new MaxHeightScroll(a);
            int screenH = a.getResources().getDisplayMetrics().heightPixels;
            sv.setMaxHeight((int) (screenH * 0.72f));
            sv.setVerticalScrollBarEnabled(false);
            body = new LinearLayout(a);
            body.setOrientation(LinearLayout.VERTICAL);
            body.setPadding(0, 0, 0, dp(a, 18));
            sv.addView(body, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            panel.addView(sv, lp(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT));

            FrameLayout.LayoutParams pp = new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.BOTTOM);
            root.addView(panel, pp);
            dlg.setContentView(root);
            fit();
        }

        private void fit() {
            Window w = dlg.getWindow();
            if (w == null) return;
            w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
            w.setGravity(Gravity.BOTTOM);
            w.getDecorView().setPadding(0, 0, 0, 0);
        }

        LinearLayout body() {
            return body;
        }

        void setDim(float d) {
            Window w = dlg.getWindow();
            if (w != null) w.setDimAmount(d);
        }

        void onDismiss(Runnable r) {
            dlg.setOnDismissListener(d -> r.run());
        }

        void show() {
            if (act.isFinishing() || act.isDestroyed()) return;
            dlg.show();
            fit();
            panel.setTranslationY(dp(act, 600));
            panel.animate().translationY(0).setDuration(240)
                    .setInterpolator(new DecelerateInterpolator(1.6f)).start();
        }

        void dismiss() {
            if (closing) return;
            closing = true;
            panel.animate().translationY(panel.getHeight() + dp(act, 40)).setDuration(180)
                    .setListener(new AnimatorListenerAdapter() {
                        @Override
                        public void onAnimationEnd(Animator a) {
                            try {
                                dlg.dismiss();
                            } catch (Exception ignored) {
                            }
                        }
                    }).start();
        }

        boolean isShowing() {
            return dlg.isShowing();
        }
    }
}
