package com.fatih.ekitap;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.Outline;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewOutlineProvider;

/** Kitap kapağı: gerçek kapak varsa onu, yoksa başlıktan üretilen şık bir kapağı çizer. */
final class CoverView extends View {
    private static final int[][] SCHEMES = {
            {0xFF3E5C76, 0xFF1D2D44}, {0xFF8E4A49, 0xFF4A1F2E}, {0xFF4F6D58, 0xFF22382B},
            {0xFFB5813A, 0xFF6B4720}, {0xFF5B4B8A, 0xFF2D2450}, {0xFF2F6F73, 0xFF123B3F},
            {0xFFA3524A, 0xFF5E2420}, {0xFF55606E, 0xFF262C35}, {0xFF7A6A3A, 0xFF3D3419},
            {0xFF8A4B6D, 0xFF45223A}};

    private String title = "";
    private String author = "";
    private Bitmap cover;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final TextPaint titlePaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private final TextPaint authorPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private final Rect src = new Rect();
    private final RectF dst = new RectF();
    private StaticLayout titleLayout;
    private StaticLayout authorLayout;
    private int layoutWidth = -1;
    private final float radius;

    CoverView(Context c) {
        super(c);
        radius = Ui.dp(c, 8);
        titlePaint.setColor(0xFFFFFFFF);
        titlePaint.setTypeface(Typeface.create(Typeface.SERIF, Typeface.BOLD));
        authorPaint.setColor(0xCCFFFFFF);
        authorPaint.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        setClipToOutline(true);
        setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View v, Outline o) {
                o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), radius);
            }
        });
        setElevation(Ui.dp(c, 3));
    }

    void set(String title, String author, Bitmap cover) {
        this.title = title == null ? "" : title;
        this.author = author == null ? "" : author;
        this.cover = cover;
        layoutWidth = -1;
        invalidate();
    }

    boolean hasImage() {
        return cover != null;
    }

    @Override
    protected void onMeasure(int w, int h) {
        int width = MeasureSpec.getSize(w);
        if (MeasureSpec.getMode(w) == MeasureSpec.UNSPECIFIED) width = Ui.dp(getContext(), 100);
        setMeasuredDimension(width, Math.round(width * 1.5f));
    }

    @Override
    protected void onDraw(Canvas canvas) {
        int w = getWidth();
        int h = getHeight();
        if (w <= 0 || h <= 0) return;
        if (cover != null && !cover.isRecycled()) {
            float cr = (float) cover.getWidth() / cover.getHeight();
            float vr = (float) w / h;
            if (cr > vr) {
                int sw = Math.round(cover.getHeight() * vr);
                int sx = (cover.getWidth() - sw) / 2;
                src.set(sx, 0, sx + sw, cover.getHeight());
            } else {
                int sh = Math.round(cover.getWidth() / vr);
                src.set(0, 0, cover.getWidth(), sh);
            }
            dst.set(0, 0, w, h);
            canvas.drawBitmap(cover, src, dst, paint);
        } else {
            drawGenerated(canvas, w, h);
        }
        // ciltteki gölge ve ince parlak çizgi
        Paint p = new Paint();
        p.setShader(new LinearGradient(0, 0, w * 0.10f, 0, 0x55000000, 0x00000000,
                Shader.TileMode.CLAMP));
        canvas.drawRect(0, 0, w * 0.10f, h, p);
        p.setShader(null);
        p.setColor(0x33FFFFFF);
        canvas.drawRect(w * 0.035f, 0, w * 0.035f + Math.max(1f, w * 0.006f), h, p);
    }

    private void drawGenerated(Canvas canvas, int w, int h) {
        int idx = (title.hashCode() & 0x7fffffff) % SCHEMES.length;
        int[] sc = SCHEMES[idx];
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new LinearGradient(0, 0, w, h, sc[0], sc[1], Shader.TileMode.CLAMP));
        canvas.drawRect(0, 0, w, h, p);
        p.setShader(null);

        // süs çizgileri
        p.setColor(0x33FFFFFF);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(Math.max(1f, w * 0.008f));
        float m = w * 0.12f;
        canvas.drawRect(m, m, w - m * 0.8f, h - m, p);
        p.setStyle(Paint.Style.FILL);
        float cy = h * 0.60f;
        canvas.drawRect(w * 0.38f, cy, w * 0.66f, cy + Math.max(1.5f, w * 0.01f), p);

        if (layoutWidth != w) {
            layoutWidth = w;
            int tw = Math.round(w * 0.64f);
            titlePaint.setTextSize(w * 0.115f);
            authorPaint.setTextSize(w * 0.075f);
            titleLayout = StaticLayout.Builder.obtain(title, 0, title.length(), titlePaint, tw)
                    .setAlignment(Layout.Alignment.ALIGN_CENTER)
                    .setMaxLines(6).setEllipsize(TextUtils.TruncateAt.END)
                    .setLineSpacing(0f, 1.05f).build();
            authorLayout = StaticLayout.Builder.obtain(author, 0, author.length(), authorPaint, tw)
                    .setAlignment(Layout.Alignment.ALIGN_CENTER)
                    .setMaxLines(2).setEllipsize(TextUtils.TruncateAt.END).build();
        }
        canvas.save();
        float ty = Math.max(m * 1.6f, (h * 0.56f - titleLayout.getHeight()) / 2f + m * 0.6f);
        canvas.translate(w * 0.18f + w * 0.02f, ty);
        titleLayout.draw(canvas);
        canvas.restore();
        if (!author.isEmpty()) {
            canvas.save();
            canvas.translate(w * 0.20f, h * 0.67f);
            authorLayout.draw(canvas);
            canvas.restore();
        }
    }
}
