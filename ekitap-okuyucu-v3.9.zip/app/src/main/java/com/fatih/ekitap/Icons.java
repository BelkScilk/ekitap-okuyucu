package com.fatih.ekitap;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;

/** Kod ile çizilen, renkli ve keskin ikonlar (24x24 birimlik çizim alanı). */
final class Icons {
    static final int BACK = 0;
    static final int CLOSE = 1;
    static final int PLAY = 2;
    static final int PAUSE = 3;
    static final int NEXT = 4;
    static final int PREV = 5;
    static final int DOTS = 6;
    static final int BOOKMARK = 7;
    static final int BOOKMARK_FILLED = 8;
    static final int LIST = 9;
    static final int TEXT = 10;
    static final int TIMER = 11;
    static final int SEARCH = 12;
    static final int GRID = 13;
    static final int ROWS = 14;
    static final int PLUS = 15;
    static final int CHECK = 16;
    static final int SORT = 17;
    static final int SLIDERS = 18;
    static final int HEADPHONES = 19;
    static final int CHEVRON_RIGHT = 20;
    static final int CHEVRON_LEFT = 21;
    static final int BOOK = 22;
    static final int PALETTE = 23;
    static final int STOP = 24;

    private Icons() {
    }

    static Drawable get(int type, int color) {
        return new IconDrawable(type, color);
    }

    private static final class IconDrawable extends Drawable {
        private final int type;
        private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();
        private final RectF rect = new RectF();

        IconDrawable(int type, int color) {
            this.type = type;
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeCap(Paint.Cap.ROUND);
            stroke.setStrokeJoin(Paint.Join.ROUND);
            stroke.setStrokeWidth(2f);
            stroke.setColor(color);
            fill.setStyle(Paint.Style.FILL);
            fill.setColor(color);
        }

        @Override
        public void draw(Canvas c) {
            Rect b = getBounds();
            if (b.isEmpty()) return;
            float s = Math.min(b.width(), b.height()) / 24f;
            c.save();
            c.translate(b.left + (b.width() - 24f * s) / 2f, b.top + (b.height() - 24f * s) / 2f);
            c.scale(s, s);
            switch (type) {
                case BACK:
                    path.reset();
                    path.moveTo(15, 5);
                    path.lineTo(8, 12);
                    path.lineTo(15, 19);
                    c.drawPath(path, stroke);
                    break;
                case CHEVRON_RIGHT:
                    path.reset();
                    path.moveTo(9, 5);
                    path.lineTo(16, 12);
                    path.lineTo(9, 19);
                    c.drawPath(path, stroke);
                    break;
                case CHEVRON_LEFT:
                    path.reset();
                    path.moveTo(15, 5);
                    path.lineTo(8, 12);
                    path.lineTo(15, 19);
                    c.drawPath(path, stroke);
                    break;
                case CLOSE:
                    c.drawLine(6, 6, 18, 18, stroke);
                    c.drawLine(18, 6, 6, 18, stroke);
                    break;
                case PLAY:
                    path.reset();
                    path.moveTo(8, 5);
                    path.lineTo(19, 12);
                    path.lineTo(8, 19);
                    path.close();
                    c.drawPath(path, fill);
                    c.drawPath(path, stroke);
                    break;
                case PAUSE:
                    rect.set(6.5f, 5f, 10.5f, 19f);
                    c.drawRoundRect(rect, 1.2f, 1.2f, fill);
                    rect.set(13.5f, 5f, 17.5f, 19f);
                    c.drawRoundRect(rect, 1.2f, 1.2f, fill);
                    break;
                case STOP:
                    rect.set(6f, 6f, 18f, 18f);
                    c.drawRoundRect(rect, 2f, 2f, fill);
                    break;
                case NEXT:
                    path.reset();
                    path.moveTo(6, 5.5f);
                    path.lineTo(15.5f, 12);
                    path.lineTo(6, 18.5f);
                    path.close();
                    c.drawPath(path, fill);
                    rect.set(17f, 5.5f, 19.5f, 18.5f);
                    c.drawRoundRect(rect, 1f, 1f, fill);
                    break;
                case PREV:
                    path.reset();
                    path.moveTo(18, 5.5f);
                    path.lineTo(8.5f, 12);
                    path.lineTo(18, 18.5f);
                    path.close();
                    c.drawPath(path, fill);
                    rect.set(4.5f, 5.5f, 7f, 18.5f);
                    c.drawRoundRect(rect, 1f, 1f, fill);
                    break;
                case DOTS:
                    c.drawCircle(12, 5.5f, 1.9f, fill);
                    c.drawCircle(12, 12, 1.9f, fill);
                    c.drawCircle(12, 18.5f, 1.9f, fill);
                    break;
                case BOOKMARK:
                case BOOKMARK_FILLED:
                    path.reset();
                    path.moveTo(7, 4);
                    path.lineTo(17, 4);
                    path.lineTo(17, 20);
                    path.lineTo(12, 16);
                    path.lineTo(7, 20);
                    path.close();
                    if (type == BOOKMARK_FILLED) c.drawPath(path, fill);
                    c.drawPath(path, stroke);
                    break;
                case LIST:
                    c.drawCircle(5, 7, 1.2f, fill);
                    c.drawCircle(5, 12, 1.2f, fill);
                    c.drawCircle(5, 17, 1.2f, fill);
                    c.drawLine(9, 7, 20, 7, stroke);
                    c.drawLine(9, 12, 20, 12, stroke);
                    c.drawLine(9, 17, 20, 17, stroke);
                    break;
                case TEXT: {
                    Paint t = new Paint(Paint.ANTI_ALIAS_FLAG);
                    t.setColor(fill.getColor());
                    t.setTypeface(Typeface.create(Typeface.SERIF, Typeface.BOLD));
                    t.setTextSize(15f);
                    c.drawText("A", 2.2f, 17.5f, t);
                    t.setTextSize(11f);
                    c.drawText("a", 13.2f, 17.5f, t);
                    break;
                }
                case TIMER:
                    c.drawCircle(12, 13.5f, 7.2f, stroke);
                    c.drawLine(12, 13.5f, 12, 9.5f, stroke);
                    c.drawLine(10, 3.5f, 14, 3.5f, stroke);
                    c.drawLine(18.3f, 7.2f, 19.6f, 5.9f, stroke);
                    break;
                case SEARCH:
                    c.drawCircle(10.5f, 10.5f, 6f, stroke);
                    c.drawLine(15f, 15f, 20f, 20f, stroke);
                    break;
                case GRID:
                    rect.set(4, 4, 10.5f, 10.5f);
                    c.drawRoundRect(rect, 1.5f, 1.5f, fill);
                    rect.set(13.5f, 4, 20, 10.5f);
                    c.drawRoundRect(rect, 1.5f, 1.5f, fill);
                    rect.set(4, 13.5f, 10.5f, 20);
                    c.drawRoundRect(rect, 1.5f, 1.5f, fill);
                    rect.set(13.5f, 13.5f, 20, 20);
                    c.drawRoundRect(rect, 1.5f, 1.5f, fill);
                    break;
                case ROWS:
                    rect.set(4, 5, 20, 9);
                    c.drawRoundRect(rect, 1.5f, 1.5f, fill);
                    rect.set(4, 10.5f, 20, 14.5f);
                    c.drawRoundRect(rect, 1.5f, 1.5f, fill);
                    rect.set(4, 16, 20, 20);
                    c.drawRoundRect(rect, 1.5f, 1.5f, fill);
                    break;
                case PLUS:
                    c.drawLine(12, 5, 12, 19, stroke);
                    c.drawLine(5, 12, 19, 12, stroke);
                    break;
                case CHECK:
                    path.reset();
                    path.moveTo(5, 12.5f);
                    path.lineTo(10, 17.5f);
                    path.lineTo(19, 7);
                    c.drawPath(path, stroke);
                    break;
                case SORT:
                    c.drawLine(4, 7, 20, 7, stroke);
                    c.drawLine(4, 12, 15, 12, stroke);
                    c.drawLine(4, 17, 10, 17, stroke);
                    break;
                case SLIDERS:
                    c.drawLine(4, 7, 20, 7, stroke);
                    c.drawLine(4, 12, 20, 12, stroke);
                    c.drawLine(4, 17, 20, 17, stroke);
                    c.drawCircle(9, 7, 2.3f, fill);
                    c.drawCircle(15, 12, 2.3f, fill);
                    c.drawCircle(8, 17, 2.3f, fill);
                    break;
                case HEADPHONES:
                    path.reset();
                    path.moveTo(4.5f, 16f);
                    path.lineTo(4.5f, 12f);
                    rect.set(4.5f, 4f, 19.5f, 20f);
                    path.arcTo(rect, 180f, 180f);
                    path.lineTo(19.5f, 16f);
                    c.drawPath(path, stroke);
                    rect.set(3f, 13f, 7.5f, 20f);
                    c.drawRoundRect(rect, 1.8f, 1.8f, fill);
                    rect.set(16.5f, 13f, 21f, 20f);
                    c.drawRoundRect(rect, 1.8f, 1.8f, fill);
                    break;
                case BOOK:
                    path.reset();
                    path.moveTo(12, 6.5f);
                    path.cubicTo(9.5f, 4.5f, 6.5f, 4.5f, 4, 5.5f);
                    path.lineTo(4, 18.5f);
                    path.cubicTo(6.5f, 17.5f, 9.5f, 17.5f, 12, 19.5f);
                    path.cubicTo(14.5f, 17.5f, 17.5f, 17.5f, 20, 18.5f);
                    path.lineTo(20, 5.5f);
                    path.cubicTo(17.5f, 4.5f, 14.5f, 4.5f, 12, 6.5f);
                    path.close();
                    c.drawPath(path, stroke);
                    c.drawLine(12, 6.5f, 12, 19.5f, stroke);
                    break;
                case PALETTE:
                    c.drawCircle(12, 12, 8f, stroke);
                    path.reset();
                    path.moveTo(12, 4f);
                    rect.set(4f, 4f, 20f, 20f);
                    path.arcTo(rect, -90f, 180f);
                    path.close();
                    c.drawPath(path, fill);
                    break;
                default:
                    break;
            }
            c.restore();
        }

        @Override
        public void setAlpha(int alpha) {
            stroke.setAlpha(alpha);
            fill.setAlpha(alpha);
            invalidateSelf();
        }

        @Override
        public void setColorFilter(ColorFilter cf) {
            stroke.setColorFilter(cf);
            fill.setColorFilter(cf);
            invalidateSelf();
        }

        @Override
        public int getOpacity() {
            return PixelFormat.TRANSLUCENT;
        }
    }
}
