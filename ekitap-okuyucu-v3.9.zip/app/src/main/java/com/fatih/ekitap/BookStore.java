package com.fatih.ekitap;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.ParcelFileDescriptor;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/** Kitapların uygulama içi kopyaları ve kapak resimleri. */
final class BookStore {
    private BookStore() {
    }

    static File booksDir(Context c) {
        File d = new File(c.getFilesDir(), "books");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    static File coversDir(Context c) {
        File d = new File(c.getFilesDir(), "covers");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    static File bookFile(Context c, String key) {
        return new File(booksDir(c), key + ".bin");
    }

    static File coverFile(Context c, String key) {
        return new File(coversDir(c), key + ".jpg");
    }

    private static File noCoverMark(Context c, String key) {
        return new File(coversDir(c), key + ".none");
    }

    /** Kitabın uygulama içi kopyasını (yoksa kaynak adresten kopyalayarak) verir. Arka planda çağır. */
    static File ensure(Context c, String uri, String key) throws IOException {
        File dest = bookFile(c, key);
        if (dest.exists() && dest.length() > 0) return dest;
        File tmp = new File(dest.getPath() + ".part");
        try (InputStream in = c.getContentResolver().openInputStream(Uri.parse(uri));
             OutputStream out = new FileOutputStream(tmp)) {
            if (in == null) throw new IOException("Dosya açılamadı");
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
        } catch (IOException | SecurityException e) {
            tmp.delete();
            if (e instanceof IOException) throw (IOException) e;
            throw new IOException("Dosyaya erişim izni yok");
        }
        // Düz metin dosyası ise okuyucunun anladığı EPUB'a çevir
        if (sniff(tmp) == null && TxtToEpub.looksLikeText(tmp)) {
            File conv = new File(dest.getPath() + ".conv");
            try {
                TxtToEpub.convert(tmp, conv, displayTitle(c, uri));
                tmp.delete();
                if (!conv.renameTo(dest)) {
                    conv.delete();
                    throw new IOException("Kopyalanamadı");
                }
                return dest;
            } catch (IOException e) {
                conv.delete();
                tmp.delete();
                throw e;
            }
        }
        if (!tmp.renameTo(dest)) {
            tmp.delete();
            throw new IOException("Kopyalanamadı");
        }
        return dest;
    }

    private static String displayTitle(Context c, String uri) {
        String name = null;
        try (android.database.Cursor q = c.getContentResolver().query(Uri.parse(uri),
                new String[]{android.provider.OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (q != null && q.moveToFirst()) name = q.getString(0);
        } catch (Exception ignored) {
        }
        if (name == null) {
            String p = Uri.parse(uri).getLastPathSegment();
            name = p == null ? "Metin" : p.substring(p.lastIndexOf('/') + 1);
        }
        return Util.cleanName(name);
    }

    /** "pdf", "epub" veya null (desteklenmiyor). */
    static String sniff(File f) {
        try (FileInputStream in = new FileInputStream(f)) {
            byte[] h = new byte[5];
            int got = in.read(h);
            if (got >= 4 && h[0] == '%' && h[1] == 'P' && h[2] == 'D' && h[3] == 'F') return "pdf";
            if (got >= 2 && h[0] == 'P' && h[1] == 'K') return "epub";
        } catch (IOException ignored) {
        }
        return null;
    }

    static void delete(Context c, String key) {
        bookFile(c, key).delete();
        coverFile(c, key).delete();
        noCoverMark(c, key).delete();
    }

    static boolean hasCover(Context c, String key) {
        return coverFile(c, key).exists();
    }

    /** Kapak dosyasını (varsa) bitmap olarak okur. */
    static Bitmap loadCover(Context c, String key) {
        File f = coverFile(c, key);
        if (!f.exists()) return null;
        try {
            return BitmapFactory.decodeFile(f.getPath());
        } catch (Throwable t) {
            return null;
        }
    }

    /**
     * Kapak ve (EPUB için) başlık/yazar bilgisini hazırlar. Zaten hazırsa bir şey yapmaz.
     * Arka plan iş parçacığında çağrılır. Bir şey değiştiyse true döner.
     */
    static boolean prepare(Context c, Prefs prefs, Prefs.Recent r) {
        String key = r.key();
        if (hasCover(c, key) || noCoverMark(c, key).exists()) return false;
        File file;
        try {
            file = ensure(c, r.uri, key);
        } catch (Throwable t) {
            return false;
        }
        String type = sniff(file);
        Bitmap cover = null;
        try {
            if ("epub".equals(type)) {
                EpubBook b = EpubBook.open(file);
                try {
                    cover = b.readCover(420);
                    prefs.updateMeta(r.uri, b.title, b.author);
                } finally {
                    b.close();
                }
            } else if ("pdf".equals(type)) {
                cover = renderPdfCover(file);
            }
        } catch (Throwable ignored) {
        }
        if (cover == null) {
            try {
                noCoverMark(c, key).createNewFile();
            } catch (IOException ignored) {
            }
            return true;
        }
        try (FileOutputStream out = new FileOutputStream(coverFile(c, key))) {
            Bitmap small = cover;
            if (cover.getWidth() > 420) {
                int h = Math.round(cover.getHeight() * 420f / cover.getWidth());
                small = Bitmap.createScaledBitmap(cover, 420, Math.max(1, h), true);
            }
            small.compress(Bitmap.CompressFormat.JPEG, 86, out);
        } catch (Throwable ignored) {
        }
        return true;
    }

    private static Bitmap renderPdfCover(File f) {
        ParcelFileDescriptor fd = null;
        PdfRenderer r = null;
        try {
            fd = ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY);
            r = new PdfRenderer(fd);
            if (r.getPageCount() <= 0) return null;
            PdfRenderer.Page page = r.openPage(0);
            try {
                int w = 420;
                int h = Math.max(1, Math.round(w * (float) page.getHeight() / page.getWidth()));
                Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
                b.eraseColor(Color.WHITE);
                page.render(b, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                return b;
            } finally {
                page.close();
            }
        } catch (Throwable t) {
            return null;
        } finally {
            try {
                if (r != null) r.close();
            } catch (Throwable ignored) {
            }
            try {
                if (fd != null) fd.close();
            } catch (Throwable ignored) {
            }
        }
    }
}
