# Ekitap Okuyucu (Android)

EPUB ve PDF okuyan, sesli okuyabilen, uyku zamanlayıcılı basit bir Android e-kitap uygulaması.

## Özellikler

- **EPUB ve PDF** okuma (taranmış / tarayıcıdan çıkmış PDF'ler dahil)
- **Yazı boyutu**: `A−` / `A+` düğmeleri (EPUB'da yazı boyutu, PDF'de yakınlaştırma; PDF'de iki parmakla da büyütülür)
- **Temalar**: Açık, Karanlık, Sepya (PDF sayfalarına da uygulanır)
- **Sesli okuma**: `▶ Oku` düğmesi. Hız ve dil (Türkçe / English / telefon dili) menüden seçilir
- **Uyku zamanlayıcısı**: 15 / 30 / 45 / 60 / 90 dk veya özel süre. Süre dolunca okuma durur ve uygulama kapanır
- Kaldığın yeri hatırlar (bölüm/sayfa ve konum)
- İçindekiler (EPUB), sayfaya git (PDF, sayfa yazısına dokun)
- Ekran kapalıyken de sesli okuma ve zamanlayıcı çalışır

## APK'yı alma (bilgisayarda hiçbir şey kurmadan)

1. GitHub'da yeni bir depo (repository) oluştur.
2. Bu klasörün **içindeki her şeyi** depoya yükle (`.github` klasörü dahil! Gizli klasör olduğu için dosya yöneticisinde "gizli dosyaları göster" açık olmalı). Git kullanıyorsan:
   ```
   git init
   git add .
   git commit -m "ilk sürüm"
   git branch -M main
   git remote add origin https://github.com/KULLANICI/DEPO.git
   git push -u origin main
   ```
3. GitHub'da depoda **Actions** sekmesine gir. "APK Derle" otomatik çalışır (2-5 dk). Çalışmazsa "APK Derle" > **Run workflow**.
4. Bitince çalışmanın sayfasının altındaki **Artifacts** bölümünden `ekitap-okuyucu-apk` dosyasını indir, zip'ten çıkan `ekitap-okuyucu.apk` dosyasını telefona at.
5. Telefonda APK'ya dokun, "bilinmeyen kaynaklardan yüklemeye izin ver" de, kur.

İstersen `v1.0` gibi bir etiket (tag) atarsan APK **Releases** bölümüne de otomatik eklenir; telefondan doğrudan oradan indirebilirsin.

## Notlar

- Sesli okuma telefondaki metin okuma (TTS) motorunu kullanır (Google TTS vb.). Türkçe ses yoksa: Ayarlar > Metin okuma > Google > Türkçe sesi indir.
- PDF'lerde sesli okuma, sayfayı cihaz üzerinde OCR ile metne çevirir (internet gerekmez). İlk sayfa birkaç saniye sürebilir; Türkçe harflerde (ş, ğ, ı) bazen hata yapabilir. Taranmış PDF'in kalitesi okumayı doğrudan etkiler.
- DRM korumalı EPUB'lar ve parolalı PDF'ler açılmaz.
- Bu APK "debug" imzalıdır; kişisel kullanım için yeterlidir.
- Yerelde derlemek istersen: Android Studio ile klasörü aç, ya da `./gradlew assembleDebug`.

## Sabit imza anahtarı (önemli)

Uygulama kimliği `com.fatih.ekitap` olarak korunur. Yeni APK'nın mevcut uygulamanın üzerine kurulabilmesi için aynı imza anahtarı kullanılmalıdır. GitHub Actions'ta **Settings → Secrets and variables → Actions** altında şu repository secrets değerlerini bir kez oluştur:

- `ANDROID_KEYSTORE_BASE64`: kişisel release `.jks` dosyasının Base64 içeriği
- `ANDROID_KEYSTORE_PASSWORD`: keystore parolası
- `ANDROID_KEY_ALIAS`: anahtar takma adı
- `ANDROID_KEY_PASSWORD`: anahtar parolası

Bu sırları bir kere belirleyip sonraki sürümlerde değiştirme. Keystore dosyasını ve parolalarını herkese açık depoya koyma. İmzalama sırları ayarlanmadan workflow, yalnızca test amaçlı debug APK'sı üretir; debug APK'sı kalıcı imzalı sürüm yerine kullanılmamalıdır. `versionCode` her yeni sürümde artırılmalıdır.
