package com.fatih.ekitap;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;

/** Ekran kapalıyken sesli okuma ve uyku zamanlayıcısı çalışmaya devam etsin diye. */
public class KeepAliveService extends Service {
    private static final String CHANNEL = "reading";

    private Notification.Action action(String command, String label, int requestCode) {
        Intent i = new Intent(this, ReadingActionReceiver.class).putExtra("command", command);
        PendingIntent pi = PendingIntent.getBroadcast(this, requestCode, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        int icon = command.equals("pause") ? android.R.drawable.ic_media_pause
                : command.equals("stop") ? android.R.drawable.ic_media_pause
                : command.equals("next") ? android.R.drawable.ic_media_next : android.R.drawable.ic_media_previous;
        return new Notification.Action.Builder(icon, label, pi).build();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(
                CHANNEL, "Sesli okuma", NotificationManager.IMPORTANCE_LOW));

        PendingIntent pi = null;
        Intent launch = getPackageManager().getLaunchIntentForPackage(getPackageName());
        if (launch != null) {
            pi = PendingIntent.getActivity(this, 0, launch, PendingIntent.FLAG_IMMUTABLE);
        }

        Notification.Builder b = new Notification.Builder(this, CHANNEL)
                .setContentTitle("Ekitap Okuyucu")
                .setContentText("Sesli okuma sürüyor")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setOngoing(true)
                .addAction(action("previous", "Önceki", 11))
                .addAction(action("pause", "Duraklat", 12))
                .addAction(action("next", "Sonraki", 13))
                .addAction(action("stop", "Durdur", 14));
        if (pi != null) b.setContentIntent(pi);
        Notification n = b.build();

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        } else {
            startForeground(1, n);
        }
        return START_NOT_STICKY;
    }
}
