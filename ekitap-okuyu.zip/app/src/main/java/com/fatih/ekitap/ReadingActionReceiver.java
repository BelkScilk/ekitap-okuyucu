package com.fatih.ekitap;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Bildirimdeki sesli okuma kontrollerini açık okuyucuya iletir. */
public class ReadingActionReceiver extends BroadcastReceiver {
    public static final String ACTION = "com.fatih.ekitap.READING_ACTION";
    @Override public void onReceive(Context context, Intent intent) {
        if (intent == null) return;
        Intent relay = new Intent(ACTION);
        relay.setPackage(context.getPackageName());
        relay.putExtra("command", intent.getStringExtra("command"));
        context.sendBroadcast(relay);
    }
}
