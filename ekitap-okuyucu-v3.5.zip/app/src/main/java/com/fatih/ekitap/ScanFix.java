package com.fatih.ekitap;

import android.graphics.Bitmap;

/**
 * Taranmış / bozuk görüntülü PDF sayfalarını otomatik netleştirir: gri tonlamaya çevirir,
 * gölge ve sararmış zemini düzler, kontrastı açar ve hafifçe keskinleştirir.
 * Düzgün (vektör) metin sayfalarına ve renkli sayfalara dokunmaz.
 */
final class ScanFix {
    private ScanFix() {
    }

    /** Bitmap'i yerinde işler; değişiklik yapıldıysa true. */
    static boolean enhance(Bitmap b) {
        if (b == null || b.isRecycled()) return false;
        int w = b.getWidth();
        int h = b.getHeight();
        if (w < 64 || h < 64) return false;
        int[] px = new int[w * h];
        b.getPixels(px, 0, w, 0, 0, w, h);
        boolean changed = enhance(px, w, h);
        if (changed) b.setPixels(px, 0, w, 0, 0, w, h);
        return changed;
    }

    static boolean needsFix(int[] px, int w, int h) {
        int n = 0;
        int mid = 0;
        int colorful = 0;
        int dark = 0;
        int[] hist = new int[256];
        for (int i = 0; i < px.length; i += 7) {
            int c = px[i];
            int r = (c >> 16) & 255;
            int g = (c >> 8) & 255;
            int bl = c & 255;
            int lum = (r * 30 + g * 59 + bl * 11) / 100;
            hist[lum]++;
            n++;
            if (lum > 45 && lum < 215) mid++;
            if (lum < 140) dark++;
            int mx = Math.max(r, Math.max(g, bl));
            int mn = Math.min(r, Math.min(g, bl));
            if (mx - mn > 85) colorful++;
        }
        if (n == 0) return false;
        if (colorful > n * 0.04f) return false; // renkli sayfa / resim
        // zemin parlaklığı: üst %10 dilimi
        int acc = 0;
        int bg = 255;
        for (int v = 255; v >= 0; v--) {
            acc += hist[v];
            if (acc >= n * 0.10f) {
                bg = v;
                break;
            }
        }
        float midRatio = mid / (float) n;
        // Düzgün dijital metin: zemin saf beyaz, ara tonlar azdır (yalnız yazı kenarları).
        return bg < 238 || midRatio > 0.10f;
    }

    static boolean enhance(int[] px, int w, int h) {
        if (!needsFix(px, w, h)) return false;
        int n = w * h;
        int[] gray = new int[n];
        for (int i = 0; i < n; i++) {
            int c = px[i];
            gray[i] = (((c >> 16) & 255) * 30 + ((c >> 8) & 255) * 59 + (c & 255) * 11) / 100;
        }

        // 1) yerel zemin haritası (blok başına %85'lik dilim) -> ışık / gölge düzleme
        int block = Math.max(16, Math.min(w, h) / 30);
        int bx = (w + block - 1) / block;
        int by = (h + block - 1) / block;
        float[] bgMap = new float[bx * by];
        int[] hist = new int[256];
        for (int j = 0; j < by; j++) {
            for (int i = 0; i < bx; i++) {
                java.util.Arrays.fill(hist, 0);
                int x0 = i * block;
                int y0 = j * block;
                int x1 = Math.min(w, x0 + block);
                int y1 = Math.min(h, y0 + block);
                int cnt = 0;
                for (int y = y0; y < y1; y++) {
                    int row = y * w;
                    for (int x = x0; x < x1; x++) {
                        hist[gray[row + x]]++;
                        cnt++;
                    }
                }
                int acc = 0;
                int v = 255;
                for (; v > 0; v--) {
                    acc += hist[v];
                    if (acc >= cnt * 0.15f) break;
                }
                bgMap[j * bx + i] = Math.max(60, v);
            }
        }
        // komşularla yumuşat (büyük koyu yazı bloklarının zemini bozmaması için en yüksek komşuya yaklaştır)
        float[] sm = new float[bgMap.length];
        for (int j = 0; j < by; j++) {
            for (int i = 0; i < bx; i++) {
                float mx = 0;
                float sum = 0;
                int c = 0;
                for (int dj = -1; dj <= 1; dj++) {
                    for (int di = -1; di <= 1; di++) {
                        int jj = j + dj;
                        int ii = i + di;
                        if (jj < 0 || ii < 0 || jj >= by || ii >= bx) continue;
                        float v = bgMap[jj * bx + ii];
                        mx = Math.max(mx, v);
                        sum += v;
                        c++;
                    }
                }
                sm[j * bx + i] = 0.5f * mx + 0.5f * (sum / c);
            }
        }

        int[] norm = new int[n];
        int[] nh = new int[256];
        for (int y = 0; y < h; y++) {
            float fy = (y + 0.5f) / block - 0.5f;
            int j0 = Math.max(0, Math.min(by - 1, (int) Math.floor(fy)));
            int j1 = Math.min(by - 1, j0 + 1);
            float ty = Math.max(0f, Math.min(1f, fy - j0));
            for (int x = 0; x < w; x++) {
                float fx = (x + 0.5f) / block - 0.5f;
                int i0 = Math.max(0, Math.min(bx - 1, (int) Math.floor(fx)));
                int i1 = Math.min(bx - 1, i0 + 1);
                float tx = Math.max(0f, Math.min(1f, fx - i0));
                float a = sm[j0 * bx + i0] * (1 - tx) + sm[j0 * bx + i1] * tx;
                float c = sm[j1 * bx + i0] * (1 - tx) + sm[j1 * bx + i1] * tx;
                float bg = a * (1 - ty) + c * ty;
                int v = Math.min(255, (int) (gray[y * w + x] * 255f / bg));
                norm[y * w + x] = v;
                nh[v]++;
            }
        }

        // 2) kontrast: koyu uç (%0,7) -> siyah, 232 üstü -> beyaz, S eğrisi
        int lo = 0;
        int acc = 0;
        for (int v = 0; v < 256; v++) {
            acc += nh[v];
            if (acc >= n * 0.007f) {
                lo = v;
                break;
            }
        }
        lo = Math.min(lo, 120);
        float hi = 232f;
        float span = Math.max(40f, hi - lo);
        int[] lut = new int[256];
        for (int v = 0; v < 256; v++) {
            float t = (v - lo) / span;
            t = Math.max(0f, Math.min(1f, t));
            t = t * t * (3f - 2f * t);
            lut[v] = Math.round(t * 255f);
        }
        for (int i = 0; i < n; i++) norm[i] = lut[norm[i]];

        // 3) hafif keskinleştirme (3x3 haç çekirdeği)
        final float amt = 0.45f;
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int i = y * w + x;
                int c = norm[i];
                int up = y > 0 ? norm[i - w] : c;
                int dn = y < h - 1 ? norm[i + w] : c;
                int lf = x > 0 ? norm[i - 1] : c;
                int rt = x < w - 1 ? norm[i + 1] : c;
                int v = Math.round(c * (1f + 4f * amt) - amt * (up + dn + lf + rt));
                v = v < 0 ? 0 : (v > 255 ? 255 : v);
                px[i] = 0xFF000000 | (v << 16) | (v << 8) | v;
            }
        }
        return true;
    }
}
