package com.fatih.ekitap;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** Gelis mis Yer Imi ve Not Yonetimi */
public final class BookmarkManager {

    public static final class Bookmark {
        public final String id;
        public final String bookKey;
        public final String title;
        public final String snippet;
        public final int chapterOrPage;
        public final float fraction;
        public final long timestamp;

        public Bookmark(String id, String bookKey, String title, String snippet, int chapterOrPage, float fraction, long timestamp) {
            this.id = id;
            this.bookKey = bookKey;
            this.title = title;
            this.snippet = snippet;
            this.chapterOrPage = chapterOrPage;
            this.fraction = fraction;
            this.timestamp = timestamp;
        }
    }

    private final SharedPreferences sp;

    public BookmarkManager(Context context) {
        sp = context.getApplicationContext().getSharedPreferences("ekitap_bookmarks", Context.MODE_PRIVATE);
    }

    public List<Bookmark> getBookmarks(String bookKey) {
        List<Bookmark> list = new ArrayList<>();
        String json = sp.getString("bm_" + bookKey, "[]");
        try {
            JSONArray array = new JSONArray(json);
            for (int i = 0; i < array.length(); i++) {
                JSONObject obj = array.getJSONObject(i);
                list.add(new Bookmark(
                        obj.getString("id"),
                        obj.getString("bookKey"),
                        obj.optString("title", "Yer İmi"),
                        obj.optString("snippet", ""),
                        obj.optInt("pos", 0),
                        (float) obj.optDouble("frac", 0.0),
                        obj.optLong("time", System.currentTimeMillis())
                ));
            }
        } catch (Exception ignored) {}
        return list;
    }

    public void addBookmark(String bookKey, String title, String snippet, int pos, float frac) {
        List<Bookmark> list = getBookmarks(bookKey);
        String id = String.valueOf(System.currentTimeMillis());
        list.add(0, new Bookmark(id, bookKey, title, snippet, pos, frac, System.currentTimeMillis()));
        save(bookKey, list);
    }

    public void removeBookmark(String bookKey, String bookmarkId) {
        List<Bookmark> list = getBookmarks(bookKey);
        for (int i = list.size() - 1; i >= 0; i--) {
            if (list.get(i).id.equals(bookmarkId)) {
                list.remove(i);
            }
        }
        save(bookKey, list);
    }

    private void save(String bookKey, List<Bookmark> list) {
        try {
            JSONArray array = new JSONArray();
            for (Bookmark b : list) {
                JSONObject obj = new JSONObject();
                obj.put("id", b.id);
                obj.put("bookKey", b.bookKey);
                obj.put("title", b.title);
                obj.put("snippet", b.snippet);
                obj.put("pos", b.chapterOrPage);
                obj.put("frac", b.fraction);
                obj.put("time", b.timestamp);
                array.put(obj);
            }
            sp.edit().putString("bm_" + bookKey, array.toString()).apply();
        } catch (Exception ignored) {}
    }
}
