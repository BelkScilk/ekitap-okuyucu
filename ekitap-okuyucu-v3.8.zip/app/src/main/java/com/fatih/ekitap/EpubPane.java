package com.fatih.ekitap;

import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.net.Uri;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Locale;
import java.util.zip.ZipEntry;

/** EPUB okuma yüzeyi: bölümler WebView'da, tema/yazı ayarları CSS ile uygulanır. */
final class EpubPane extends Pane {
    private static final String HOST = "epub.local";

    private final EpubBook book;
    private final FrameLayout root;
    private InnerWeb web;
    private int unit;
    private float pendingFrac = -1f;
    private boolean docReady;
    private boolean destroyed;
    private int loadToken;
    private ValueAnimator scroller;
    private String ttsJs = "";

    /** Kaydırma aralığını dışarı açan WebView. */
    private final class InnerWeb extends WebView {
        InnerWeb(Activity a) {
            super(a);
        }

        int range() {
            return computeVerticalScrollRange();
        }

        @Override
        protected void onScrollChanged(int l, int t, int ol, int ot) {
            super.onScrollChanged(l, t, ol, ot);
            if (docReady) host.onPosition();
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    EpubPane(Host host, EpubBook book, String key) {
        super(host, key);
        this.book = book;
        Activity a = host.activity();
        root = new FrameLayout(a);
        try (InputStream in = a.getAssets().open("tts.js")) {
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) != -1) bo.write(buf, 0, n);
            ttsJs = bo.toString("UTF-8");
        } catch (Exception e) {
            ttsJs = "";
        }
        web = new InnerWeb(a);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setTextZoom(host.prefs().textZoom());
        web.setWebViewClient(new Client());
        web.setLongClickable(false);
        web.setOnLongClickListener(v -> true);
        web.setHapticFeedbackEnabled(false);
        web.setVerticalScrollBarEnabled(false);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.setBackgroundColor(host.pal().bg);
        root.addView(web, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    EpubBook book() {
        return book;
    }

    @Override
    View view() {
        return root;
    }

    @Override
    void open() {
        int u = Math.max(0, Math.min(host.prefs().chapter(key), book.spine.size() - 1));
        load(u, host.prefs().frac(key));
    }

    // ------------------------------------------------------------------ yükleme

    private void load(int u, float frac) {
        if (destroyed || web == null) return;
        unit = Math.max(0, Math.min(u, book.spine.size() - 1));
        pendingFrac = Math.max(0f, Math.min(1f, frac));
        docReady = false;
        loadToken++;
        web.setAlpha(0f);
        host.prefs().saveChapter(key, unit);
        web.loadUrl("https://" + HOST + "/" + Uri.encode(book.spine.get(unit), "/"));
        host.onPosition();
    }

    private final class Client extends WebViewClient {
        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
            return serve(req.getUrl());
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
            Uri u = req.getUrl();
            if (HOST.equals(u.getHost()) && u.getPath() != null) {
                String path = u.getPath();
                if (path.startsWith("/")) path = path.substring(1);
                int idx = book.spine.indexOf(path);
                if (idx == unit) return false; // aynı bölümde dipnot / bağlantı
                if (idx >= 0) {
                    host.onUserNavigated();
                    load(idx, 0f);
                }
            }
            return true; // dış bağlantılar açılmaz
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            if (destroyed) return;
            final int token = loadToken;
            injectStyle();
            injectSpeechScript();
            host.ui().postDelayed(() -> settle(token, 0), 160);
        }
    }

    /** Sayfa yerleşince konumu uygular ve görünür yapar; görseller yüklenince bir kez daha düzeltir. */
    private void settle(int token, int attempt) {
        if (destroyed || web == null || token != loadToken) return;
        if (pendingFrac >= 0f) scrollToFrac(pendingFrac);
        if (attempt == 0) {
            docReady = true;
            web.animate().alpha(1f).setDuration(160).start();
            host.onUnitLoaded();
            host.onPosition();
            host.ui().postDelayed(() -> settle(token, 1), 500);
        } else {
            pendingFrac = -1f;
        }
    }

    private WebResourceResponse serve(Uri u) {
        if (!HOST.equals(u.getHost())) return notFound();
        String path = u.getPath();
        if (path == null) return notFound();
        if (path.startsWith("/")) path = path.substring(1);
        try {
            ZipEntry e = book.zip.getEntry(path);
            if (e == null) return notFound();
            String mime = EpubBook.mimeOf(path);
            if (mime.contains("javascript")) return notFound(); // kitap içi betikler çalışmasın
            boolean text = mime.startsWith("text/") || mime.contains("xml");
            return new WebResourceResponse(mime, text ? "UTF-8" : null, book.zip.getInputStream(e));
        } catch (Exception ex) {
            return notFound();
        }
    }

    private static WebResourceResponse notFound() {
        return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found",
                new HashMap<String, String>(), new ByteArrayInputStream(new byte[0]));
    }

    // ------------------------------------------------------------------ görünüm

    private void injectStyle() {
        if (web == null) return;
        Palette p = host.pal();
        Prefs pr = host.prefs();
        String family = pr.fontFamily() == 0
                ? "Georgia,'Noto Serif','Droid Serif',serif"
                : "Roboto,'Noto Sans','Droid Sans',sans-serif";
        String lh = String.format(Locale.US, "%.2f", pr.lineSpacing() / 100f);
        int m = pr.margin();
        String css = "html,body{background:" + Palette.css(p.bg) + " !important;color:"
                + Palette.css(p.fg) + " !important;overscroll-behavior:none;}"
                + "body{margin:0 auto !important;padding:30px " + m + "px 110px " + m
                + "px !important;max-width:42em !important;box-sizing:border-box !important;"
                + "font-family:" + family + " !important;line-height:" + lh + " !important;"
                + "overflow-wrap:break-word;-webkit-hyphens:auto;hyphens:auto;}"
                + "body *{color:" + Palette.css(p.fg) + " !important;"
                + "background-color:transparent !important;font-family:inherit !important;"
                + "line-height:inherit !important;max-width:100%;}"
                + "a,a *{color:" + Palette.css(p.link) + " !important;}"
                + "img,svg,video{max-width:100% !important;height:auto !important;}"
                + "p{margin-top:0;margin-bottom:.8em;}"
                + "h1,h2,h3,h4{line-height:1.3 !important;}";
        String js = "(function(){var s=document.getElementById('__et');if(!s){"
                + "s=document.createElement('style');s.id='__et';"
                + "(document.head||document.documentElement).appendChild(s);}"
                + "s.textContent=" + JSONObject.quote(css) + ";})();";
        web.evaluateJavascript(js, null);
    }

    private void injectSpeechScript() {
        if (web == null || ttsJs.isEmpty()) return;
        Palette p = host.pal();
        web.evaluateJavascript(ttsJs, null);
        web.evaluateJavascript("window.__tts&&window.__tts.cfg("
                + JSONObject.quote(Palette.cssA(p.hlSentence)) + ","
                + JSONObject.quote(Palette.cssA(p.hlWord)) + ")", null);
    }

    @Override
    void applyStyle() {
        if (web == null) return;
        final float f = frac();
        web.setBackgroundColor(host.pal().bg);
        web.getSettings().setTextZoom(host.prefs().textZoom());
        injectStyle();
        injectSpeechScript();
        final int token = loadToken;
        host.ui().postDelayed(() -> {
            if (!destroyed && token == loadToken) scrollToFrac(f);
        }, 200);
    }

    // ------------------------------------------------------------------ konum

    private void scrollToFrac(float f) {
        if (web == null) return;
        int max = Math.max(0, web.range() - web.getHeight());
        web.scrollTo(0, Math.round(max * Math.max(0f, Math.min(1f, f))));
    }

    @Override
    int unitCount() {
        return book.spine.size();
    }

    @Override
    int unit() {
        return unit;
    }

    @Override
    float frac() {
        if (web == null) return 0f;
        int max = web.range() - web.getHeight();
        if (max <= 0) return 0f;
        return Math.max(0f, Math.min(1f, web.getScrollY() / (float) max));
    }

    @Override
    void go(int u, float f) {
        if (u == unit && docReady) {
            scrollToFrac(f);
            host.onPosition();
        } else {
            load(u, f);
        }
    }

    @Override
    protected View scrollTarget() {
        return docReady ? web : null;
    }

    @Override
    protected boolean edgeNav(boolean forward) {
        if (web == null || !docReady) return false;
        if (forward && unit + 1 < book.spine.size()) {
            host.onUserNavigated();
            load(unit + 1, 0f);
            return true;
        }
        if (!forward && unit > 0) {
            host.onUserNavigated();
            load(unit - 1, 1f);
            return true;
        }
        return false;
    }

    @Override
    boolean step(boolean forward) {
        if (web == null || !docReady) return false;
        int max = Math.max(0, web.range() - web.getHeight());
        int y = web.getScrollY();
        int h = web.getHeight();
        if (forward) {
            if (y < max - 4) {
                smoothTo(Math.min(max, y + Math.round(h * 0.88f)));
                return true;
            }
            if (unit + 1 < book.spine.size()) {
                host.onUserNavigated();
                load(unit + 1, 0f);
                return true;
            }
            return false;
        }
        if (y > 4) {
            smoothTo(Math.max(0, y - Math.round(h * 0.88f)));
            return true;
        }
        if (unit > 0) {
            host.onUserNavigated();
            load(unit - 1, 1f);
            return true;
        }
        return false;
    }

    private void smoothTo(int target) {
        if (scroller != null) scroller.cancel();
        scroller = ValueAnimator.ofInt(web.getScrollY(), target);
        scroller.setDuration(260);
        scroller.addUpdateListener(a -> {
            if (web != null) web.scrollTo(0, (Integer) a.getAnimatedValue());
        });
        scroller.start();
    }

    @Override
    String unitLabel() {
        return "Bölüm " + (unit + 1) + " / " + book.spine.size();
    }

    @Override
    String unitTitle() {
        String best = null;
        for (EpubBook.TocItem t : book.toc) {
            if (t.spineIndex == unit) return t.title;
            if (t.spineIndex < unit) best = t.title;
        }
        return best != null ? best : "Bölüm " + (unit + 1);
    }

    @Override
    String bookmarkLabel() {
        return unitTitle() + " · %" + Math.round(frac() * 100);
    }

    @Override
    void saveProgress() {
        if (!docReady) return;
        float f = frac();
        host.prefs().saveChapter(key, unit);
        host.prefs().saveFrac(key, f);
        host.prefs().saveProgress(key, (unit + f) / Math.max(1, book.spine.size()));
    }

    // ------------------------------------------------------------------ sesli okuma

    @Override
    void requestSpeech(final boolean fromVisible, final SpeechCb cb) {
        requestSpeechTry(fromVisible, cb, 0);
    }

    private void requestSpeechTry(final boolean fromVisible, final SpeechCb cb, final int tries) {
        if (web == null || destroyed) return;
        if (!docReady) {
            if (tries < 40) {
                host.ui().postDelayed(() -> requestSpeechTry(fromVisible, cb, tries + 1), 150);
            }
            return;
        }
        final int token = loadToken;
        web.evaluateJavascript("(function(){if(!window.__tts)return '';"
                + "return JSON.stringify(window.__tts.build());})()", value -> {
            if (destroyed || token != loadToken) return;
            try {
                Object o = new JSONTokener(value).nextValue();
                if (!(o instanceof String) || ((String) o).isEmpty()) {
                    cb.on("", 0);
                    return;
                }
                JSONObject j = new JSONObject((String) o);
                String text = j.optString("t", "");
                int start = fromVisible ? j.optInt("s", 0) : 0;
                cb.on(text, Math.max(0, Math.min(start, text.length())));
            } catch (Exception e) {
                cb.on("", 0);
            }
        });
    }

    @Override
    void highlight(int sa, int sb, int wa, int wb) {
        if (web == null || !docReady) return;
        web.evaluateJavascript("window.__tts&&window.__tts.hl(" + sa + "," + sb + "," + wa + ","
                + wb + ")", null);
    }

    @Override
    void clearHighlight() {
        if (web == null) return;
        web.evaluateJavascript("window.__tts&&window.__tts.clear()", null);
    }

    @Override
    void destroy() {
        destroyed = true;
        if (scroller != null) scroller.cancel();
        if (web != null) {
            try {
                root.removeView(web);
                web.destroy();
            } catch (Exception ignored) {
            }
            web = null;
        }
    }
}
