package com.fatih.ekitap;

import android.text.InputType;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;
import java.util.Locale;

/** Okuma ekranının alt panelleri: görünüm, dinleme, içindekiler, yer imleri, arama. */
final class ReaderSheets {
    private final ReaderActivity a;

    ReaderSheets(ReaderActivity a) {
        this.a = a;
    }

    private LinearLayout.LayoutParams wrap() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    // ------------------------------------------------------------------ yer imi

    void toggleBookmark() {
        if (a.pane == null) return;
        int unit = a.pane.unit();
        float frac = a.pane.frac();
        List<Prefs.Bookmark> list = a.prefs.bookmarks(a.key);
        for (int i = 0; i < list.size(); i++) {
            Prefs.Bookmark b = list.get(i);
            if (b.pos == unit && Math.abs(b.frac - frac) < 0.03f) {
                a.prefs.removeBookmark(a.key, i);
                a.updateBookmarkIcon();
                a.toast("Yer imi kaldırıldı");
                return;
            }
        }
        a.prefs.addBookmark(a.key, new Prefs.Bookmark(a.pane.bookmarkLabel(), unit, frac));
        a.updateBookmarkIcon();
        a.toast("Yer imi eklendi");
    }

    void showBookmarks() {
        final Palette p = a.pal;
        final Ui.Sheet sh = new Ui.Sheet(a, p, "Yer imleri");
        final List<Prefs.Bookmark> list = a.prefs.bookmarks(a.key);
        if (list.isEmpty()) {
            TextView t = Ui.text(a, "Henüz yer imi yok. Üstteki yer imi simgesine dokunarak "
                    + "bulunduğun yeri işaretleyebilirsin.", 14.5f, p.muted);
            t.setLineSpacing(0f, 1.25f);
            t.setPadding(Ui.dp(a, 22), Ui.dp(a, 12), Ui.dp(a, 22), Ui.dp(a, 12));
            sh.body().addView(t);
        }
        for (int i = 0; i < list.size(); i++) {
            final int idx = i;
            final Prefs.Bookmark b = list.get(i);
            LinearLayout row = new LinearLayout(a);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(Ui.dp(a, 20), Ui.dp(a, 4), Ui.dp(a, 8), Ui.dp(a, 4));
            Ui.press(row, p, 0, 0);
            ImageView ic = Ui.icon(a, Icons.BOOKMARK_FILLED, p.accent, 22, 0);
            row.addView(ic, new LinearLayout.LayoutParams(Ui.dp(a, 22), Ui.dp(a, 22)));
            TextView t = Ui.text(a, b.label, 15f, p.fg);
            t.setMaxLines(2);
            t.setPadding(Ui.dp(a, 14), Ui.dp(a, 10), Ui.dp(a, 8), Ui.dp(a, 10));
            row.addView(t, Ui.lpWeight(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            ImageView del = Ui.iconButton(a, p, Icons.CLOSE, p.muted, 40, 11);
            del.setOnClickListener(v -> {
                a.prefs.removeBookmark(a.key, idx);
                a.updateBookmarkIcon();
                sh.dismiss();
                a.ui.postDelayed(this::showBookmarks, 220);
            });
            row.addView(del);
            row.setOnClickListener(v -> {
                sh.dismiss();
                if (a.pane == null) return;
                a.stopSpeech();
                a.pane.go(b.pos, b.frac);
            });
            sh.body().addView(row);
        }
        sh.show();
    }

    // ------------------------------------------------------------------ daha fazla

    void showMore() {
        final Palette p = a.pal;
        final Ui.Sheet sh = new Ui.Sheet(a, p, a.bookTitle);
        int n = a.prefs.bookmarks(a.key).size();
        View bm = Ui.actionRow(a, p, Icons.BOOKMARK, "Yer imleri",
                n == 0 ? "Henüz yok" : n + " yer imi");
        bm.setOnClickListener(v -> {
            sh.dismiss();
            a.ui.postDelayed(this::showBookmarks, 200);
        });
        sh.body().addView(bm);
        View find = Ui.actionRow(a, p, Icons.SEARCH,
                a.pane instanceof EpubPane ? "Kitapta ara" : "Sayfaya git", null);
        find.setOnClickListener(v -> {
            sh.dismiss();
            a.ui.postDelayed(this::showSearch, 200);
        });
        sh.body().addView(find);
        View toc = Ui.actionRow(a, p, Icons.LIST,
                a.pane instanceof EpubPane ? "İçindekiler" : "Sayfa seç", null);
        toc.setOnClickListener(v -> {
            sh.dismiss();
            a.ui.postDelayed(this::showContents, 200);
        });
        sh.body().addView(toc);
        View look = Ui.actionRow(a, p, Icons.SLIDERS, "Görünüm ve yazı ayarları", null);
        look.setOnClickListener(v -> {
            sh.dismiss();
            a.ui.postDelayed(this::showAppearance, 200);
        });
        sh.body().addView(look);
        View lib = Ui.actionRow(a, p, Icons.BOOK, "Kitaplığa dön", null);
        lib.setOnClickListener(v -> {
            sh.dismiss();
            a.finish();
        });
        sh.body().addView(lib);
        sh.show();
    }

    // ------------------------------------------------------------------ içindekiler / sayfaya git

    void showContents() {
        if (a.pane == null) return;
        final Palette p = a.pal;
        final Ui.Sheet sh = new Ui.Sheet(a, p,
                a.pane instanceof EpubPane ? "İçindekiler" : "Sayfaya git");
        if (a.pane instanceof EpubPane) {
            EpubBook b = ((EpubPane) a.pane).book();
            int cur = a.pane.unit();
            for (final EpubBook.TocItem t : b.toc) {
                boolean now = t.spineIndex == cur;
                TextView row = Ui.text(a, t.title, 15.5f, now ? p.accent : p.fg);
                if (now) row.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
                row.setPadding(Ui.dp(a, 22), Ui.dp(a, 13), Ui.dp(a, 22), Ui.dp(a, 13));
                row.setMaxLines(2);
                Ui.press(row, p, 0, 0);
                row.setOnClickListener(v -> {
                    sh.dismiss();
                    a.stopSpeech();
                    a.pane.go(t.spineIndex, 0f);
                });
                sh.body().addView(row);
            }
        } else {
            LinearLayout box = new LinearLayout(a);
            box.setOrientation(LinearLayout.VERTICAL);
            box.setPadding(Ui.dp(a, 20), Ui.dp(a, 6), Ui.dp(a, 20), Ui.dp(a, 6));
            final int total = a.pane.unitCount();
            TextView hint = Ui.text(a, "Şu an sayfa " + (a.pane.unit() + 1) + " / " + total,
                    14f, p.muted);
            hint.setPadding(0, 0, 0, Ui.dp(a, 10));
            box.addView(hint);
            final EditText e = Ui.input(a, p, "1 - " + total, "");
            e.setInputType(InputType.TYPE_CLASS_NUMBER);
            box.addView(e, wrap());
            TextView go = Ui.pill(a, p, "Git", true);
            LinearLayout.LayoutParams gp = wrap();
            gp.topMargin = Ui.dp(a, 12);
            box.addView(go, gp);
            go.setOnClickListener(v -> {
                try {
                    int pg = Integer.parseInt(e.getText().toString().trim());
                    sh.dismiss();
                    a.stopSpeech();
                    a.pane.go(Math.max(1, Math.min(total, pg)) - 1, 0f);
                } catch (NumberFormatException ex) {
                    a.toast("Sayfa numarası yaz");
                }
            });
            sh.body().addView(box);
        }
        sh.show();
        if (!(a.pane instanceof EpubPane)) return;
    }

    // ------------------------------------------------------------------ kitapta ara

    void showSearch() {
        if (a.pane == null) return;
        if (!(a.pane instanceof EpubPane)) {
            showContents();
            return;
        }
        final Palette p = a.pal;
        final Ui.Sheet sh = new Ui.Sheet(a, p, "Kitapta ara");
        final EpubBook book = ((EpubPane) a.pane).book();
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(Ui.dp(a, 20), Ui.dp(a, 6), Ui.dp(a, 20), Ui.dp(a, 4));
        final EditText e = Ui.input(a, p, "Aranacak sözcük", "");
        e.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        box.addView(e, wrap());
        final LinearLayout results = new LinearLayout(a);
        results.setOrientation(LinearLayout.VERTICAL);
        sh.body().addView(box);
        sh.body().addView(results, wrap());
        e.setOnEditorActionListener((v, actionId, ev) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH
                    || (ev != null && ev.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                runSearch(book, e.getText().toString(), results, sh);
                return true;
            }
            return false;
        });
        sh.show();
        e.requestFocus();
    }

    private void runSearch(final EpubBook book, final String q, final LinearLayout results,
                           final Ui.Sheet sh) {
        final Palette p = a.pal;
        results.removeAllViews();
        if (q.trim().length() < 2) {
            a.toast("En az 2 harf yaz");
            return;
        }
        TextView wait = Ui.text(a, "Aranıyor…", 14f, p.muted);
        wait.setPadding(Ui.dp(a, 22), Ui.dp(a, 14), Ui.dp(a, 22), Ui.dp(a, 14));
        results.addView(wait);
        new Thread(() -> {
            final List<EpubBook.Hit> hits;
            List<EpubBook.Hit> h;
            try {
                h = book.search(q, 120);
            } catch (Throwable t) {
                h = new java.util.ArrayList<>();
            }
            hits = h;
            a.ui.post(() -> {
                results.removeAllViews();
                if (hits.isEmpty()) {
                    TextView none = Ui.text(a, "Sonuç bulunamadı.", 14.5f, p.muted);
                    none.setPadding(Ui.dp(a, 22), Ui.dp(a, 14), Ui.dp(a, 22), Ui.dp(a, 14));
                    results.addView(none);
                    return;
                }
                TextView cnt = Ui.text(a, hits.size() + " sonuç", 12.5f, p.muted);
                cnt.setPadding(Ui.dp(a, 22), Ui.dp(a, 8), Ui.dp(a, 22), Ui.dp(a, 4));
                results.addView(cnt);
                for (final EpubBook.Hit hit : hits) {
                    TextView r = Ui.text(a, hit.snippet, 14.5f, p.fg);
                    r.setLineSpacing(0f, 1.2f);
                    r.setPadding(Ui.dp(a, 22), Ui.dp(a, 12), Ui.dp(a, 22), Ui.dp(a, 12));
                    Ui.press(r, p, 0, 0);
                    r.setOnClickListener(v -> {
                        sh.dismiss();
                        a.stopSpeech();
                        a.pane.go(hit.unit, hit.frac);
                    });
                    results.addView(r);
                }
            });
        }).start();
    }

    // ------------------------------------------------------------------ görünüm ve yazı

    void showAppearance() {
        if (a.pane == null) return;
        final Palette p = a.pal;
        final Prefs pr = a.prefs;
        final Ui.Sheet sh = new Ui.Sheet(a, p, "Görünüm ve yazı");
        sh.setDim(0.12f);
        LinearLayout body = sh.body();

        // tema
        body.addView(Ui.sectionTitle(a, p, "Tema"));
        LinearLayout themes = new LinearLayout(a);
        themes.setOrientation(LinearLayout.HORIZONTAL);
        themes.setPadding(Ui.dp(a, 16), Ui.dp(a, 4), Ui.dp(a, 16), Ui.dp(a, 4));
        for (int i = 0; i < Palette.COUNT; i++) {
            final int id = i;
            Palette q = Palette.of(i);
            LinearLayout cell = new LinearLayout(a);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER_HORIZONTAL);
            Ui.press(cell, p, 0, 14);
            cell.setPadding(0, Ui.dp(a, 6), 0, Ui.dp(a, 6));
            FrameLayout sw = new FrameLayout(a);
            boolean sel = pr.theme() == i;
            sw.setBackground(Ui.outline(a, q.bg, sel ? p.accent : p.line, sel ? 2.5f : 1f, 26));
            TextView aa = Ui.serif(a, "Aa", 17f, q.fg);
            aa.setGravity(Gravity.CENTER);
            sw.addView(aa, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER));
            cell.addView(sw, new LinearLayout.LayoutParams(Ui.dp(a, 52), Ui.dp(a, 52)));
            TextView nm = Ui.text(a, q.name, 12f, sel ? p.accent : p.muted);
            nm.setPadding(0, Ui.dp(a, 6), 0, 0);
            cell.addView(nm);
            cell.setOnClickListener(v -> {
                pr.setTheme(id);
                sh.dismiss();
                a.applyTheme();
                a.ui.postDelayed(this::showAppearance, 230);
            });
            themes.addView(cell, Ui.lpWeight(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        }
        body.addView(themes);

        // yazı
        body.addView(Ui.sectionTitle(a, p, "Yazı"));
        body.addView(Ui.sliderRow(a, p, "Yazı boyutu", 70, 260, pr.textZoom(),
                v -> "%" + v, v -> {
                    pr.setTextZoom(v);
                    a.pane.applyStyle();
                }));
        body.addView(Ui.chipRow(a, p, new String[]{"Tırnaklı (serif)", "Tırnaksız (sans)"},
                pr.fontFamily(), i -> {
                    pr.setFontFamily(i);
                    a.pane.applyStyle();
                }));
        body.addView(Ui.sliderRow(a, p, "Satır aralığı", 120, 230, pr.lineSpacing(),
                v -> String.format(Locale.US, "%.2f", v / 100f).replace('.', ','), v -> {
                    pr.setLineSpacing(v);
                    a.pane.applyStyle();
                }));
        body.addView(Ui.sliderRow(a, p, "Kenar boşluğu", 4, 56, pr.margin(),
                v -> v + " dp", v -> {
                    pr.setMargin(v);
                    a.pane.applyStyle();
                }));

        // ekran
        body.addView(Ui.sectionTitle(a, p, "Ekran"));
        body.addView(Ui.switchRow(a, p, "Sistem parlaklığını kullan", null, pr.brightness() < 0f,
                on -> {
                    pr.setBrightness(on ? -1f : 0.6f);
                    a.applyBrightness();
                }));
        body.addView(Ui.sliderRow(a, p, "Parlaklık", 5, 100,
                pr.brightness() < 0f ? 60 : Math.round(pr.brightness() * 100),
                v -> "%" + v, v -> {
                    pr.setBrightness(v / 100f);
                    a.applyBrightness();
                }));
        body.addView(Ui.switchRow(a, p, "Okurken ekranı açık tut", null, pr.keepOn(), on -> {
            pr.setKeepOn(on);
            a.applyKeepOn();
        }));
        body.addView(Ui.switchRow(a, p, "Kenarlara dokunarak sayfa çevir",
                "Ekranın sol ve sağ kenarı", pr.tapPaging(), pr::setTapPaging));

        if (a.pane instanceof PdfPane) {
            final PdfPane pdf = (PdfPane) a.pane;
            body.addView(Ui.sectionTitle(a, p, "PDF"));
            body.addView(Ui.switchRow(a, p, "Metni ekrana sığdır",
                    "Sayfa metne çevrilir; yazı büyüse de ekrandan taşmaz",
                    pdf.isTextMode(), on -> {
                        a.stopSpeech();
                        pdf.setTextMode(on);
                    }));
            body.addView(Ui.switchRow(a, p, "Kenar boşluklarını kırp",
                    "Görüntü kipinde sayfa daha büyük görünür", pr.pdfCrop(), on -> {
                        pr.setPdfCrop(on);
                        pdf.refreshRender();
                    }));
        }
        sh.show();
    }

    // ------------------------------------------------------------------ dinleme

    void showListen() {
        if (a.pane == null) return;
        final Palette p = a.pal;
        final Prefs pr = a.prefs;
        final Speaker sp = a.speaker;
        final Ui.Sheet sh = new Ui.Sheet(a, p, "Dinleme");
        LinearLayout body = sh.body();

        // ana düğmeler
        LinearLayout top = new LinearLayout(a);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setPadding(Ui.dp(a, 20), Ui.dp(a, 6), Ui.dp(a, 20), Ui.dp(a, 6));
        String label = sp.isPlaying() ? "Duraklat" : (sp.isPaused() ? "Devam et" : "Okumaya başla");
        TextView main = Ui.pill(a, p, label, true);
        main.setOnClickListener(v -> {
            sh.dismiss();
            if (sp.isPlaying()) sp.pause();
            else if (sp.isPaused()) sp.play();
            else a.startSpeech(true);
        });
        top.addView(main, Ui.lpWeight(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        if (sp.isActive()) {
            TextView stop = Ui.pill(a, p, "Bitir", false);
            stop.setOnClickListener(v -> {
                sh.dismiss();
                a.stopSpeech();
            });
            top.addView(stop, Ui.lpMargin(ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT, Ui.dp(a, 10), 0, 0, 0));
        }
        body.addView(top);

        // hız
        body.addView(Ui.sectionTitle(a, p, "Ses"));
        body.addView(Ui.sliderRow(a, p, "Okuma hızı", 50, 250, Math.round(pr.rate() * 100),
                v -> String.format(Locale.US, "%.2f×", v / 100f).replace('.', ','), v -> {
                    pr.setRate(v / 100f);
                    sp.applyAndRestart();
                    a.updatePlayUi();
                }));
        String[] langs = {"Türkçe", "English", "Telefonun dili"};
        int li = "tr".equals(pr.lang()) ? 0 : ("en".equals(pr.lang()) ? 1 : 2);
        body.addView(Ui.chipRow(a, p, langs, li, i -> {
            pr.setLang(i == 0 ? "tr" : (i == 1 ? "en" : "sys"));
            pr.setVoice("");
            sp.applyAndRestart();
            sh.dismiss();
            a.ui.postDelayed(this::showListen, 230);
        }));

        List<Speaker.VoiceInfo> voices = sp.voices();
        if (!voices.isEmpty()) {
            TextView vt = Ui.text(a, "Ses seçimi", 13f, p.muted);
            vt.setPadding(Ui.dp(a, 22), Ui.dp(a, 14), Ui.dp(a, 22), Ui.dp(a, 2));
            body.addView(vt);
            String cur = pr.voice();
            int shown = 0;
            View auto = Ui.actionRow(a, p, cur.isEmpty() ? Icons.CHECK : -1, "Otomatik", null);
            if (!cur.isEmpty()) auto.setPadding(Ui.dp(a, 60), Ui.dp(a, 13), Ui.dp(a, 20), Ui.dp(a, 13));
            auto.setOnClickListener(v -> {
                pr.setVoice("");
                sp.applyAndRestart();
                sh.dismiss();
                a.ui.postDelayed(this::showListen, 230);
            });
            body.addView(auto);
            for (final Speaker.VoiceInfo vi : voices) {
                if (shown++ >= 10) break;
                boolean on = vi.name.equals(cur);
                View row = Ui.actionRow(a, p, on ? Icons.CHECK : -1, vi.label, null);
                if (!on) row.setPadding(Ui.dp(a, 60), Ui.dp(a, 13), Ui.dp(a, 20), Ui.dp(a, 13));
                row.setOnClickListener(v -> {
                    pr.setVoice(vi.name);
                    sp.applyAndRestart();
                    sh.dismiss();
                    a.ui.postDelayed(this::showListen, 230);
                });
                body.addView(row);
            }
        }

        body.addView(Ui.switchRow(a, p, "Okunan kelimeyi vurgula", "Cümle ve kelime renkli gösterilir",
                pr.highlight(), on -> {
                    pr.setHighlight(on);
                    if (!on && a.pane != null) a.pane.clearHighlight();
                }));

        // uyku zamanlayıcısı
        body.addView(Ui.sectionTitle(a, p, "Uyku zamanlayıcısı"));
        String status = a.timerAtUnitEnd ? "Bölüm / sayfa bitince kapanır"
                : (a.timerRemainingMs() > 0
                ? "Kalan: " + (a.timerRemainingMs() / 60000 + 1) + " dk sonra kapanır"
                : "Kapalı");
        TextView st = Ui.text(a, status, 13.5f, p.muted);
        st.setPadding(Ui.dp(a, 22), 0, Ui.dp(a, 22), Ui.dp(a, 4));
        body.addView(st);
        final int[] mins = {0, 15, 30, 45, 60, 90};
        String[] names = {"Kapalı", "15 dk", "30 dk", "45 dk", "60 dk", "90 dk", "Bölüm sonu"};
        int sel = a.timerAtUnitEnd ? 6 : 0;
        body.addView(Ui.chipRow(a, p, names, sel, i -> {
            if (i == 6) a.setTimerAtUnitEnd(true);
            else a.setTimer(mins[i]);
            a.toast(i == 0 ? "Zamanlayıcı kapatıldı"
                    : (i == 6 ? "Bölüm sonunda kapanacak" : mins[i] + " dk sonra kapanacak"));
        }));
        body.addView(Ui.switchRow(a, p, "Kapanmadan önce sesi yavaşça kıs",
                "Son 30 saniyede ses azalır", pr.fadeOut(), pr::setFadeOut));
        sh.show();
    }
}
