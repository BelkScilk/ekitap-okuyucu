package com.fatih.ekitap;

import android.app.Activity;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;

/** Okuma yüzeyi (EPUB veya PDF) için ortak sözleşme. */
abstract class Pane {

    interface Host {
        Activity activity();

        Prefs prefs();

        Palette pal();

        Handler ui();

        /** Okuma konumu değişti (kaydırma, bölüm/sayfa geçişi). */
        void onPosition();

        /** Yeni bölüm/sayfa içeriği hazır. */
        void onUnitLoaded();

        /** Kullanıcı bağlantı ile başka yere gitti (okuma durmalı). */
        void onUserNavigated();

        void onMessage(String msg);
    }

    interface SpeechCb {
        /** text: okunacak tüm metin, start: okumaya başlanacak konum. */
        void on(String text, int start);
    }

    protected final Host host;
    protected final String key;

    Pane(Host host, String key) {
        this.host = host;
        this.key = key;
    }

    abstract View view();

    /** Kayıtlı konumdan açar. */
    abstract void open();

    abstract int unitCount();

    abstract int unit();

    /** Bölüm/sayfa içindeki konum (0..1). */
    abstract float frac();

    abstract void go(int unit, float frac);

    /** Dokunarak sayfa çevirme; çevrilecek yer yoksa false. */
    abstract boolean step(boolean forward);

    abstract void applyStyle();

    abstract String unitLabel();

    abstract String unitTitle();

    /** Konuşulacak metni hazırlar. fromVisible: ekranda görünen yerden başla. */
    abstract void requestSpeech(boolean fromVisible, SpeechCb cb);

    /** Okunan cümle [sa,sb) ve kelime [wa,wb) aralığını gösterir; wa<0 ise yalnız cümle. */
    abstract void highlight(int sa, int sb, int wa, int wb);

    abstract void clearHighlight();

    /** Yer imi için etiket (bölüm adı, sayfa no). */
    abstract String bookmarkLabel();

    abstract void saveProgress();

    abstract void destroy();

    /** Etkinliğin dokunma olayları (yakınlaştırma / kaydırma hareketleri için). */
    void onTouch(MotionEvent ev) {
    }

    /** Ekranda görünür bir değişiklik olunca (ör. çubuklar) yeniden yerleşim gerekir mi. */
    void onResized() {
    }

    /** Tüm kitap üzerindeki konum (0..1). */
    float overall() {
        int n = Math.max(1, unitCount());
        return Math.max(0f, Math.min(1f, (unit() + frac()) / n));
    }

    void seekOverall(float f) {
        int n = Math.max(1, unitCount());
        float x = Math.max(0f, Math.min(0.9999f, f)) * n;
        int u = (int) x;
        go(u, x - u);
    }
}
