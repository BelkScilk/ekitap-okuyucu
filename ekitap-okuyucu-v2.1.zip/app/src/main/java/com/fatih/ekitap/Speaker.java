package com.fatih.ekitap;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.PowerManager;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Sesli okuma motoru. Metni cümle gruplarına böler, birkaçını sıraya alır, okunan cümleyi ve
 * kelimeyi bildirir; ses odağı, kulaklık çıkarma ve ekran kapalıyken çalışmayı yönetir.
 */
final class Speaker {

    interface Cb {
        /** Yeni bir cümle grubu okunmaya başladı: metindeki [a,b) aralığı. */
        void onSegment(int a, int b);

        /** Okunan kelime: metindeki [a,b) aralığı. */
        void onWord(int a, int b);

        /** Metnin sonuna gelindi. */
        void onFinished();

        /** Baştan/sondan öteye atlama istendi (dir: -1 önceki, +1 sonraki bölüm). */
        void onEdge(int dir);

        /** Çalıyor / duraklatıldı / durdu durumu değişti. */
        void onState();

        void onMessage(String msg);
    }

    private static final int MAX_SEG = 260;
    private static final int WINDOW = 2;

    private final Context ctx;
    private final Prefs prefs;
    private final Handler ui;
    private final Cb cb;

    private TextToSpeech tts;
    private boolean ready;
    private boolean pendingPlay;

    private String text = "";
    private List<int[]> segs = new ArrayList<>();
    private int idx;
    private int queued;
    private int session;
    private boolean playing;
    private boolean paused;
    private boolean pausedByFocus;
    private float volume = 1f;
    private int lastWordSeg = -1;
    private int lastWordStart = -1;
    private int errors;

    private AudioFocusRequest focusRequest;
    private PowerManager.WakeLock wakeLock;
    private boolean noisyRegistered;

    Speaker(Context c, Prefs p, Handler ui, Cb cb) {
        this.ctx = c.getApplicationContext();
        this.prefs = p;
        this.ui = ui;
        this.cb = cb;
        try {
            tts = new TextToSpeech(ctx, status -> {
                if (status == TextToSpeech.SUCCESS && tts != null) {
                    ready = true;
                    tts.setOnUtteranceProgressListener(new Progress());
                    tts.setAudioAttributes(attrs());
                    applyConfig();
                    if (pendingPlay) {
                        pendingPlay = false;
                        play();
                    }
                } else {
                    ready = false;
                    cb.onMessage("Ses motoru başlatılamadı. Telefonda bir metin okuma (TTS) motoru kurulu olmalı.");
                }
            });
        } catch (Exception e) {
            tts = null;
        }
    }

    // ------------------------------------------------------------------ durum

    boolean isReady() {
        return ready;
    }

    boolean isPlaying() {
        return playing;
    }

    boolean isPaused() {
        return paused;
    }

    /** Çalıyor veya duraklatılmış (yani bir okuma oturumu var). */
    boolean isActive() {
        return playing || paused;
    }

    int segmentCount() {
        return segs.size();
    }

    int currentSegment() {
        return idx;
    }

    String currentText() {
        return text;
    }

    // ------------------------------------------------------------------ metin yükleme

    /** Metni yükler; startOffset'ten itibaren ilk cümle grubundan başlayacak şekilde hazırlar. */
    void load(String t, int startOffset) {
        haltSpeech();
        text = t == null ? "" : t;
        segs = Seg.split(text, MAX_SEG);
        idx = 0;
        for (int i = 0; i < segs.size(); i++) {
            if (segs.get(i)[1] > startOffset) {
                idx = i;
                break;
            }
            idx = i;
        }
        queued = idx;
        lastWordSeg = -1;
        lastWordStart = -1;
        errors = 0;
    }

    // ------------------------------------------------------------------ denetim

    void play() {
        if (tts == null) {
            cb.onMessage("Ses motoru yok. Telefonda bir metin okuma (TTS) motoru kurulu olmalı.");
            return;
        }
        if (!ready) {
            pendingPlay = true;
            return;
        }
        if (segs.isEmpty()) {
            cb.onFinished();
            return;
        }
        playing = true;
        paused = false;
        pausedByFocus = false;
        acquire();
        startFrom(Math.max(0, Math.min(idx, segs.size() - 1)));
        cb.onState();
    }

    void pause() {
        if (!playing) return;
        playing = false;
        paused = true;
        session++;
        try {
            if (tts != null) tts.stop();
        } catch (Exception ignored) {
        }
        release(false);
        cb.onState();
    }

    void toggle() {
        if (playing) pause();
        else play();
    }

    /** Okumayı tamamen bitirir. */
    void stop() {
        boolean was = isActive();
        haltSpeech();
        if (was) cb.onState();
    }

    private void haltSpeech() {
        playing = false;
        paused = false;
        pausedByFocus = false;
        pendingPlay = false;
        session++;
        try {
            if (tts != null) tts.stop();
        } catch (Exception ignored) {
        }
        release(true);
    }

    void skip(int dir) {
        if (segs.isEmpty()) {
            cb.onEdge(dir);
            return;
        }
        int ni = idx + dir;
        if (ni < 0 || ni >= segs.size()) {
            cb.onEdge(dir);
            return;
        }
        if (playing) {
            startFrom(ni);
        } else {
            idx = ni;
            queued = ni;
            int[] s = segs.get(ni);
            cb.onSegment(s[0], s[1]);
        }
    }

    void shutdown() {
        haltSpeech();
        try {
            if (tts != null) tts.shutdown();
        } catch (Exception ignored) {
        }
        tts = null;
        ready = false;
    }

    /** Uyku zamanlayıcısının ses azaltması için (0..1). Yeni cümlelere uygulanır. */
    void setVolume(float v) {
        volume = Math.max(0.05f, Math.min(1f, v));
    }

    // ------------------------------------------------------------------ ayarlar

    void applyConfig() {
        if (tts == null || !ready) return;
        String l = prefs.lang();
        Locale loc;
        if ("tr".equals(l)) loc = new Locale("tr", "TR");
        else if ("en".equals(l)) loc = Locale.US;
        else loc = Locale.getDefault();
        int r = tts.setLanguage(loc);
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            cb.onMessage("Bu dil için ses verisi yok. Telefon Ayarları > Metin okuma bölümünden "
                    + "ilgili dili indirin.");
        }
        tts.setSpeechRate(prefs.rate());
        String vn = prefs.voice();
        if (!vn.isEmpty()) {
            try {
                Set<Voice> all = tts.getVoices();
                if (all != null) {
                    for (Voice v : all) {
                        if (v.getName().equals(vn)) {
                            tts.setVoice(v);
                            break;
                        }
                    }
                }
            } catch (Exception ignored) {
            }
        }
    }

    /** Ayar değişince çalıyorsa geçerli cümleyi yeni ayarlarla yeniden başlatır. */
    void applyAndRestart() {
        applyConfig();
        if (playing && !segs.isEmpty()) startFrom(idx);
    }

    static final class VoiceInfo {
        final String name;
        final String label;

        VoiceInfo(String name, String label) {
            this.name = name;
            this.label = label;
        }
    }

    /** Seçili dile uyan sesler. */
    List<VoiceInfo> voices() {
        List<VoiceInfo> out = new ArrayList<>();
        if (tts == null || !ready) return out;
        String l = prefs.lang();
        String want = "tr".equals(l) ? "tr" : ("en".equals(l) ? "en" : Locale.getDefault().getLanguage());
        try {
            Set<Voice> all = tts.getVoices();
            if (all == null) return out;
            List<Voice> list = new ArrayList<>();
            for (Voice v : all) {
                if (v.getLocale() != null && want.equals(v.getLocale().getLanguage())) list.add(v);
            }
            Collections.sort(list, new Comparator<Voice>() {
                @Override
                public int compare(Voice a, Voice b) {
                    return a.getName().compareTo(b.getName());
                }
            });
            int n = 1;
            for (Voice v : list) {
                String label = "Ses " + n + (v.getLocale().getCountry().isEmpty() ? ""
                        : " (" + v.getLocale().getCountry() + ")");
                if (v.isNetworkConnectionRequired()) label += " · çevrimiçi";
                out.add(new VoiceInfo(v.getName(), label));
                n++;
            }
        } catch (Exception ignored) {
        }
        return out;
    }

    // ------------------------------------------------------------------ sıraya alma

    private void startFrom(int i) {
        if (tts == null || !ready || segs.isEmpty()) return;
        session++;
        idx = Math.max(0, Math.min(i, segs.size() - 1));
        queued = idx;
        lastWordSeg = -1;
        lastWordStart = -1;
        try {
            tts.stop();
        } catch (Exception ignored) {
        }
        int[] s = segs.get(idx);
        cb.onSegment(s[0], s[1]);
        fill();
    }

    private void fill() {
        if (tts == null || !ready) return;
        while (queued < segs.size() && queued < idx + 1 + WINDOW) {
            int[] s = segs.get(queued);
            Bundle b = new Bundle();
            b.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, volume);
            int r = tts.speak(text.substring(s[0], s[1]), TextToSpeech.QUEUE_ADD, b,
                    "s" + session + "_" + queued);
            if (r != TextToSpeech.SUCCESS) {
                cb.onMessage("Ses motoru yanıt vermiyor");
                pause();
                return;
            }
            queued++;
        }
    }

    private int parseSeg(String id) {
        try {
            String[] a = id.substring(1).split("_");
            if (Integer.parseInt(a[0]) != session) return -1;
            return Integer.parseInt(a[1]);
        } catch (Exception e) {
            return -1;
        }
    }

    private final class Progress extends UtteranceProgressListener {
        @Override
        public void onStart(final String id) {
            ui.post(() -> {
                int i = parseSeg(id);
                if (i < 0 || !playing || i >= segs.size()) return;
                errors = 0;
                if (i != idx) {
                    idx = i;
                    lastWordSeg = -1;
                    lastWordStart = -1;
                    int[] s = segs.get(i);
                    cb.onSegment(s[0], s[1]);
                }
                fill();
            });
        }

        @Override
        public void onRangeStart(final String id, final int start, final int end, int frame) {
            ui.post(() -> {
                int i = parseSeg(id);
                if (i < 0 || !playing || i >= segs.size()) return;
                int[] s = segs.get(i);
                String seg = text.substring(s[0], s[1]);
                int[] w = Seg.snapWord(seg, start, end);
                if (w == null) return;
                if (i == lastWordSeg && w[0] <= lastWordStart) return; // geriye gitme
                lastWordSeg = i;
                lastWordStart = w[0];
                cb.onWord(s[0] + w[0], s[0] + w[1]);
            });
        }

        @Override
        public void onDone(final String id) {
            ui.post(() -> finishedSegment(id, false));
        }

        @Override
        public void onError(final String id) {
            ui.post(() -> finishedSegment(id, true));
        }
    }

    private void finishedSegment(String id, boolean error) {
        int i = parseSeg(id);
        if (i < 0 || !playing) return;
        if (error && ++errors > 3) {
            cb.onMessage("Ses motoru hata verdi, okuma duraklatıldı");
            pause();
            return;
        }
        if (i >= segs.size() - 1) {
            playing = false;
            paused = false;
            release(true);
            cb.onState();
            cb.onFinished();
        }
    }

    // ------------------------------------------------------------------ ses odağı, kulaklık, uyanık kalma

    private static AudioAttributes attrs() {
        return new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build();
    }

    private final AudioManager.OnAudioFocusChangeListener focusListener = change -> {
        if (change == AudioManager.AUDIOFOCUS_LOSS) {
            if (playing) pause();
            pausedByFocus = false;
        } else if (change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) {
            if (playing) {
                pausedByFocus = true; // odağı bırakma, geri gelince devam edeceğiz
                pause();
            }
        } else if (change == AudioManager.AUDIOFOCUS_GAIN) {
            if (pausedByFocus && paused) {
                pausedByFocus = false;
                play();
            }
        }
    };

    private final BroadcastReceiver noisy = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            if (playing) pause();
        }
    };

    private void acquire() {
        try {
            PowerManager pm = (PowerManager) ctx.getSystemService(Context.POWER_SERVICE);
            if (wakeLock == null && pm != null) {
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ekitap:tts");
            }
            if (wakeLock != null && !wakeLock.isHeld()) wakeLock.acquire(6 * 60 * 60 * 1000L);
        } catch (Exception ignored) {
        }
        try {
            AudioManager am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
            if (am != null) {
                if (focusRequest == null) {
                    focusRequest = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                            .setAudioAttributes(attrs())
                            .setOnAudioFocusChangeListener(focusListener, ui)
                            .build();
                }
                am.requestAudioFocus(focusRequest);
            }
        } catch (Exception ignored) {
        }
        if (!noisyRegistered) {
            try {
                IntentFilter f = new IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY);
                if (Build.VERSION.SDK_INT >= 33) {
                    ctx.registerReceiver(noisy, f, Context.RECEIVER_NOT_EXPORTED);
                } else {
                    ctx.registerReceiver(noisy, f);
                }
                noisyRegistered = true;
            } catch (Exception ignored) {
            }
        }
    }

    /** Duraklatınca / bitirince kaynakları bırakır. full=true ise ses odağı da bırakılır. */
    private void release(boolean full) {
        try {
            if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        } catch (Exception ignored) {
        }
        if (noisyRegistered) {
            try {
                ctx.unregisterReceiver(noisy);
            } catch (Exception ignored) {
            }
            noisyRegistered = false;
        }
        if (full || paused) {
            try {
                AudioManager am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
                if (am != null && focusRequest != null && !pausedByFocus) {
                    am.abandonAudioFocusRequest(focusRequest);
                }
            } catch (Exception ignored) {
            }
        }
    }
}
