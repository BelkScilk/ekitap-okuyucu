package com.fatih.ekitap;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** Ayarlar, okuma konumları, yer imleri ve kitaplık. (Kayıt anahtarları önceki sürümlerle uyumludur.) */
final class Prefs {
    static final int LIGHT = Palette.LIGHT;
    static final int DARK = Palette.DARK;
    static final int SEPIA = Palette.SEPIA;
    static final int BLACK = Palette.BLACK;

    static final int SORT_RECENT = 0;
    static final int SORT_TITLE = 1;
    static final int SORT_PROGRESS = 2;

    static final class Recent {
        final String uri;
        final String name;
        final String type;      // "epub" | "pdf"
        final String category;  // "" = kategorisiz
        final String author;

        Recent(String uri, String name, String type, String category, String author) {
            this.uri = uri;
            this.name = name == null ? "Kitap" : name;
            this.type = type == null ? "" : type;
            this.category = category == null ? "" : category;
            this.author = author == null ? "" : author;
        }

        Recent withCategory(String c) {
            return new Recent(uri, name, type, c, author);
        }

        Recent withMeta(String n, String a) {
            return new Recent(uri, n == null || n.isEmpty() ? name : n, type, category,
                    a == null ? author : a);
        }

        /** Okuma konumunun saklandığı anahtar. */
        String key() {
            return Integer.toHexString(uri.hashCode());
        }
    }

    static final class Bookmark {
        final String label;
        final int pos;     // EPUB: bölüm sırası, PDF: sayfa sırası
        final float frac;  // EPUB: bölüm içindeki konum (0..1)

        Bookmark(String label, int pos, float frac) {
            this.label = label;
            this.pos = pos;
            this.frac = frac;
        }
    }

    private final SharedPreferences sp;

    Prefs(Context c) {
        sp = c.getApplicationContext().getSharedPreferences("ekitap", Context.MODE_PRIVATE);
    }

    // ---------------------------------------------------------------- görünüm
    int theme() { return sp.getInt("theme", DARK); }
    void setTheme(int t) { sp.edit().putInt("theme", t).apply(); }
    Palette palette() { return Palette.of(theme()); }

    /** Yazı boyutu yüzdesi (EPUB ve PDF metin modu). */
    int textZoom() { return sp.getInt("textZoom", 105); }
    void setTextZoom(int z) { sp.edit().putInt("textZoom", Math.max(70, Math.min(260, z))).apply(); }

    /** 0 = tırnaklı (serif), 1 = tırnaksız (sans). */
    int fontFamily() { return sp.getInt("fontFamily", 0); }
    void setFontFamily(int f) { sp.edit().putInt("fontFamily", f).apply(); }

    /** Satır aralığı yüzdesi (130..220). */
    int lineSpacing() { return sp.getInt("lineSpacing", 165); }
    void setLineSpacing(int v) { sp.edit().putInt("lineSpacing", Math.max(120, Math.min(230, v))).apply(); }

    /** Sayfa kenar boşluğu (dp). */
    int margin() { return sp.getInt("margin", 18); }
    void setMargin(int v) { sp.edit().putInt("margin", Math.max(4, Math.min(56, v))).apply(); }

    /** Ekran parlaklığı 0..1; negatif = sistem. */
    float brightness() { return sp.getFloat("brightness", -1f); }
    void setBrightness(float b) { sp.edit().putFloat("brightness", b).apply(); }

    float pdfZoom() { return sp.getFloat("pdfZoom", 1f); }
    void setPdfZoom(float z) { sp.edit().putFloat("pdfZoom", z).apply(); }

    boolean pdfTextMode() { return sp.getBoolean("pdfTextMode", false); }
    void setPdfTextMode(boolean b) { sp.edit().putBoolean("pdfTextMode", b).apply(); }

    boolean pdfCrop() { return sp.getBoolean("pdfCrop", true); }
    void setPdfCrop(boolean b) { sp.edit().putBoolean("pdfCrop", b).apply(); }

    boolean tapPaging() { return sp.getBoolean("tapPaging", true); }
    void setTapPaging(boolean b) { sp.edit().putBoolean("tapPaging", b).apply(); }

    boolean keepOn() { return sp.getBoolean("keepOn", true); }
    void setKeepOn(boolean b) { sp.edit().putBoolean("keepOn", b).apply(); }

    boolean seenHint() { return sp.getBoolean("seenHint", false); }
    void setSeenHint() { sp.edit().putBoolean("seenHint", true).apply(); }

    // ---------------------------------------------------------------- sesli okuma
    float rate() { return sp.getFloat("rate", 1f); }
    void setRate(float r) { sp.edit().putFloat("rate", r).apply(); }

    String lang() { return sp.getString("lang", "tr"); }
    void setLang(String l) { sp.edit().putString("lang", l).apply(); }

    /** Seçilen ses motoru sesinin adı; boş = otomatik. */
    String voice() { return sp.getString("voice", ""); }
    void setVoice(String v) { sp.edit().putString("voice", v == null ? "" : v).apply(); }

    boolean highlight() { return sp.getBoolean("highlight", true); }
    void setHighlight(boolean b) { sp.edit().putBoolean("highlight", b).apply(); }

    boolean fadeOut() { return sp.getBoolean("fadeOut", true); }
    void setFadeOut(boolean b) { sp.edit().putBoolean("fadeOut", b).apply(); }

    int lastTimerMin() { return sp.getInt("lastTimerMin", 30); }
    void setLastTimerMin(int m) { sp.edit().putInt("lastTimerMin", m).apply(); }

    // ---------------------------------------------------------------- okuma konumu
    int chapter(String key) { return sp.getInt("ch_" + key, 0); }
    float frac(String key) { return sp.getFloat("fr_" + key, 0f); }
    int page(String key) { return sp.getInt("pg_" + key, 0); }

    void saveChapter(String key, int ch) { sp.edit().putInt("ch_" + key, ch).apply(); }
    void saveFrac(String key, float f) { sp.edit().putFloat("fr_" + key, f).apply(); }
    void savePage(String key, int p) { sp.edit().putInt("pg_" + key, p).apply(); }

    /** 0..1 genel okuma ilerlemesi (kitaplıkta ilerleme çubuğu için). */
    float progress(String key) { return sp.getFloat("pr_" + key, 0f); }
    void saveProgress(String key, float f) {
        sp.edit().putFloat("pr_" + key, Math.max(0f, Math.min(1f, f))).apply();
    }

    /** Kitabın son açılış zamanı (ms). */
    long lastOpened(String key) { return sp.getLong("lo_" + key, 0L); }
    void touch(String key) { sp.edit().putLong("lo_" + key, System.currentTimeMillis()).apply(); }

    void forgetBook(String key) {
        sp.edit().remove("ch_" + key).remove("fr_" + key).remove("pg_" + key)
                .remove("pr_" + key).remove("bm_" + key).remove("lo_" + key).apply();
    }

    // ---------------------------------------------------------------- yer imleri
    List<Bookmark> bookmarks(String key) {
        List<Bookmark> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(sp.getString("bm_" + key, "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                out.add(new Bookmark(o.optString("l", "Yer imi"), o.optInt("p", 0),
                        (float) o.optDouble("f", 0.0)));
            }
        } catch (Exception ignored) {
        }
        return out;
    }

    private void saveBookmarks(String key, List<Bookmark> list) {
        try {
            JSONArray a = new JSONArray();
            for (Bookmark b : list) {
                JSONObject o = new JSONObject();
                o.put("l", b.label);
                o.put("p", b.pos);
                o.put("f", (double) b.frac);
                a.put(o);
            }
            sp.edit().putString("bm_" + key, a.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    void addBookmark(String key, Bookmark b) {
        List<Bookmark> list = bookmarks(key);
        for (int i = list.size() - 1; i >= 0; i--) {
            Bookmark x = list.get(i);
            if (x.pos == b.pos && Math.abs(x.frac - b.frac) < 0.01f) list.remove(i);
        }
        list.add(0, b);
        while (list.size() > 100) list.remove(list.size() - 1);
        saveBookmarks(key, list);
    }

    void removeBookmark(String key, int index) {
        List<Bookmark> list = bookmarks(key);
        if (index >= 0 && index < list.size()) {
            list.remove(index);
            saveBookmarks(key, list);
        }
    }

    // ---------------------------------------------------------------- kitaplık görünümü
    boolean libGrid() { return sp.getBoolean("libGrid", true); }
    void setLibGrid(boolean b) { sp.edit().putBoolean("libGrid", b).apply(); }

    int sort() { return sp.getInt("sort", SORT_RECENT); }
    void setSort(int s) { sp.edit().putInt("sort", s).apply(); }

    // ---------------------------------------------------------------- kitaplık
    List<Recent> recents() {
        List<Recent> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(sp.getString("recents", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                out.add(new Recent(o.getString("uri"), o.optString("name", "Kitap"),
                        o.optString("type", ""), o.optString("cat", ""),
                        o.optString("author", "")));
            }
        } catch (Exception ignored) {
        }
        return out;
    }

    private void saveRecents(List<Recent> list) {
        try {
            JSONArray a = new JSONArray();
            for (Recent r : list) {
                JSONObject o = new JSONObject();
                o.put("uri", r.uri);
                o.put("name", r.name);
                o.put("type", r.type);
                o.put("cat", r.category);
                o.put("author", r.author);
                a.put(o);
            }
            sp.edit().putString("recents", a.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    Recent findRecent(String uri) {
        for (Recent r : recents()) if (r.uri.equals(uri)) return r;
        return null;
    }

    /** Kitabı listenin başına alır; kategori ve yazar bilgisi korunur. */
    void addRecent(Recent r) {
        List<Recent> list = recents();
        Recent keep = r;
        for (int i = list.size() - 1; i >= 0; i--) {
            Recent x = list.get(i);
            if (x.uri.equals(r.uri)) {
                String cat = r.category.isEmpty() ? x.category : r.category;
                String au = r.author.isEmpty() ? x.author : r.author;
                keep = new Recent(r.uri, x.name.equals("Kitap") ? r.name : x.name, r.type, cat, au);
                list.remove(i);
            }
        }
        list.add(0, keep);
        while (list.size() > 500) list.remove(list.size() - 1);
        saveRecents(list);
    }

    /** Listede olmayan kitabı sona ekler (toplu içe aktarmada sıra bozulmasın). */
    void addIfMissing(Recent r) {
        List<Recent> list = recents();
        for (Recent x : list) if (x.uri.equals(r.uri)) return;
        list.add(0, r);
        saveRecents(list);
    }

    void updateMeta(String uri, String title, String author) {
        List<Recent> list = recents();
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).uri.equals(uri)) {
                list.set(i, list.get(i).withMeta(title, author));
            }
        }
        saveRecents(list);
    }

    void setCategory(String uri, String category) {
        List<Recent> list = recents();
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).uri.equals(uri)) list.set(i, list.get(i).withCategory(category));
        }
        saveRecents(list);
    }

    void renameBook(String uri, String name) {
        List<Recent> list = recents();
        for (int i = 0; i < list.size(); i++) {
            Recent r = list.get(i);
            if (r.uri.equals(uri)) {
                list.set(i, new Recent(r.uri, name, r.type, r.category, r.author));
            }
        }
        saveRecents(list);
    }

    void removeRecent(String uri) {
        List<Recent> list = recents();
        for (int i = list.size() - 1; i >= 0; i--) {
            if (list.get(i).uri.equals(uri)) list.remove(i);
        }
        saveRecents(list);
    }

    // ---------------------------------------------------------------- kategoriler
    /** Boş kategoriler dahil, kullanıcının sıralamasıyla kategori adları. */
    List<String> categories() {
        List<String> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(sp.getString("cats", "[]"));
            for (int i = 0; i < a.length(); i++) {
                String s = a.getString(i);
                if (!s.isEmpty() && !out.contains(s)) out.add(s);
            }
        } catch (Exception ignored) {
        }
        for (Recent r : recents()) {
            if (!r.category.isEmpty() && !out.contains(r.category)) out.add(r.category);
        }
        return out;
    }

    private void saveCategories(List<String> cats) {
        JSONArray a = new JSONArray();
        for (String c : cats) a.put(c);
        sp.edit().putString("cats", a.toString()).apply();
    }

    /** Eklenirse adını döner; boşsa veya zaten varsa null. */
    String addCategory(String name) {
        String n = name == null ? "" : name.trim();
        if (n.isEmpty() || n.length() > 40) return null;
        List<String> cats = categories();
        for (String c : cats) if (c.equalsIgnoreCase(n)) return null;
        cats.add(n);
        saveCategories(cats);
        return n;
    }

    void renameCategory(String oldName, String newName) {
        String n = newName == null ? "" : newName.trim();
        if (n.isEmpty() || n.equals(oldName)) return;
        List<String> cats = categories();
        int i = cats.indexOf(oldName);
        if (i >= 0) cats.set(i, n);
        saveCategories(cats);
        List<Recent> list = recents();
        for (int k = 0; k < list.size(); k++) {
            if (list.get(k).category.equals(oldName)) list.set(k, list.get(k).withCategory(n));
        }
        saveRecents(list);
    }

    void removeCategory(String name) {
        List<String> cats = categories();
        cats.remove(name);
        saveCategories(cats);
        List<Recent> list = recents();
        for (int k = 0; k < list.size(); k++) {
            if (list.get(k).category.equals(name)) list.set(k, list.get(k).withCategory(""));
        }
        saveRecents(list);
    }
}
