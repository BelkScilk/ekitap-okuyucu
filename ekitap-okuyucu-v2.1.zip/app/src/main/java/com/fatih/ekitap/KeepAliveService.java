package com.fatih.ekitap;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.drawable.Icon;
import android.media.MediaMetadata;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Build;
import android.os.IBinder;

/**
 * Sesli okuma sürerken uygulamayı canlı tutar. Bildirimde Önceki / Duraklat-Oynat / Sonraki / Durdur
 * düğmeleri gösterir ve kulaklık-bluetooth medya tuşlarını (MediaSession) dinler.
 * Tuşlar ReaderActivity'e {@link Controller} üzerinden iletilir.
 */
public class KeepAliveService extends Service {

    /** ReaderActivity'nin uyguladığı geri çağırımlar (ana iş parçacığında çağrılır). */
    interface Controller {
        void onMediaPlay();

        void onMediaPause();

        void onMediaStop();

        /** dir > 0: sonraki bölüm/sayfa, dir < 0: önceki. */
        void onMediaSkip(int dir);
    }

    static volatile Controller controller;
    static volatile KeepAliveService instance;

    static final String ACTION_START = "com.fatih.ekitap.START";
    static final String ACTION_PLAY = "com.fatih.ekitap.PLAY";
    static final String ACTION_PAUSE = "com.fatih.ekitap.PAUSE";
    static final String ACTION_STOP = "com.fatih.ekitap.STOP";
    static final String ACTION_NEXT = "com.fatih.ekitap.NEXT";
    static final String ACTION_PREV = "com.fatih.ekitap.PREV";
    static final String EXTRA_TITLE = "title";
    static final String EXTRA_PLAYING = "playing";

    private static final String CHANNEL = "reading";
    private static final int NOTIF_ID = 1;

    private MediaSession session;
    private String title = "Ekitap Okuyucu";
    private boolean playing = true;
    private boolean foregroundStarted;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        session = new MediaSession(this, "EkitapOkuyucu");
        session.setCallback(new MediaSession.Callback() {
            @Override
            public void onPlay() {
                Controller c = controller;
                if (c != null) c.onMediaPlay();
            }

            @Override
            public void onPause() {
                Controller c = controller;
                if (c != null) c.onMediaPause();
            }

            @Override
            public void onStop() {
                Controller c = controller;
                if (c != null) c.onMediaStop();
            }

            @Override
            public void onSkipToNext() {
                Controller c = controller;
                if (c != null) c.onMediaSkip(1);
            }

            @Override
            public void onSkipToPrevious() {
                Controller c = controller;
                if (c != null) c.onMediaSkip(-1);
            }
        });
        session.setActive(true);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();
        if (action == null || ACTION_START.equals(action)) {
            if (intent != null) {
                String t = intent.getStringExtra(EXTRA_TITLE);
                if (t != null && !t.isEmpty()) title = t;
                playing = intent.getBooleanExtra(EXTRA_PLAYING, true);
            }
            goForeground();
            return START_NOT_STICKY;
        }

        // Bildirim düğmelerinden gelen komutlar
        if (!foregroundStarted) {
            stopSelf();
            return START_NOT_STICKY;
        }
        Controller c = controller;
        if (c == null) {
            stopSelf();
            return START_NOT_STICKY;
        }
        switch (action) {
            case ACTION_PLAY:
                c.onMediaPlay();
                break;
            case ACTION_PAUSE:
                c.onMediaPause();
                break;
            case ACTION_STOP:
                c.onMediaStop();
                break;
            case ACTION_NEXT:
                c.onMediaSkip(1);
                break;
            case ACTION_PREV:
                c.onMediaSkip(-1);
                break;
            default:
                break;
        }
        return START_NOT_STICKY;
    }

    /** ReaderActivity durum değiştirince çağırır (oynuyor / duraklatıldı). */
    void setPlaying(boolean isPlaying, String newTitle) {
        playing = isPlaying;
        if (newTitle != null && !newTitle.isEmpty()) title = newTitle;
        if (foregroundStarted) refresh();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (instance == this) instance = null;
        try {
            session.setActive(false);
            session.release();
        } catch (Exception ignored) {
        }
    }

    // ------------------------------------------------------------------ bildirim

    private void goForeground() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(
                CHANNEL, "Sesli okuma", NotificationManager.IMPORTANCE_LOW));
        updateSession();
        Notification n = buildNotification();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        } else {
            startForeground(NOTIF_ID, n);
        }
        foregroundStarted = true;
    }

    private void refresh() {
        updateSession();
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.notify(NOTIF_ID, buildNotification());
    }

    private void updateSession() {
        try {
            long actions = PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE
                    | PlaybackState.ACTION_PLAY_PAUSE | PlaybackState.ACTION_STOP
                    | PlaybackState.ACTION_SKIP_TO_NEXT | PlaybackState.ACTION_SKIP_TO_PREVIOUS;
            session.setPlaybackState(new PlaybackState.Builder()
                    .setActions(actions)
                    .setState(playing ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED,
                            PlaybackState.PLAYBACK_POSITION_UNKNOWN, 1f)
                    .build());
            session.setMetadata(new MediaMetadata.Builder()
                    .putString(MediaMetadata.METADATA_KEY_TITLE, title)
                    .build());
        } catch (Exception ignored) {
        }
    }

    private Notification.Action action(int iconRes, String label, String act) {
        Intent i = new Intent(this, KeepAliveService.class).setAction(act);
        PendingIntent pi = PendingIntent.getService(this, act.hashCode(), i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Action.Builder(Icon.createWithResource(this, iconRes), label, pi)
                .build();
    }

    private Notification buildNotification() {
        PendingIntent open = null;
        Intent launch = getPackageManager().getLaunchIntentForPackage(getPackageName());
        if (launch != null) {
            open = PendingIntent.getActivity(this, 0, launch, PendingIntent.FLAG_IMMUTABLE);
        }
        Notification.Builder b = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle(title)
                .setContentText(playing ? "Sesli okuma sürüyor" : "Duraklatıldı")
                .setOngoing(true)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .addAction(action(android.R.drawable.ic_media_previous, "Önceki", ACTION_PREV))
                .addAction(playing
                        ? action(android.R.drawable.ic_media_pause, "Duraklat", ACTION_PAUSE)
                        : action(android.R.drawable.ic_media_play, "Oynat", ACTION_PLAY))
                .addAction(action(android.R.drawable.ic_media_next, "Sonraki", ACTION_NEXT))
                .addAction(action(android.R.drawable.ic_menu_close_clear_cancel, "Durdur",
                        ACTION_STOP))
                .setStyle(new Notification.MediaStyle()
                        .setMediaSession(session.getSessionToken())
                        .setShowActionsInCompactView(0, 1, 2));
        if (open != null) b.setContentIntent(open);
        return b.build();
    }
}
