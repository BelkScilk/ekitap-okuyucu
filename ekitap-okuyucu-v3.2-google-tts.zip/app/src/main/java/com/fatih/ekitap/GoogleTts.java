package com.fatih.ekitap;

import android.util.Base64;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

/**
 * Google Cloud Text-to-Speech (REST) ile yapay zekâ sesi üretir.
 * API anahtarı gerekir (Google Cloud Console → Credentials → API key).
 */
final class GoogleTts {

    static final class Err extends Exception {
        final boolean fatal;

        Err(String m, boolean fatal) {
            super(m);
            this.fatal = fatal;
        }
    }

    /** Türkçe WaveNet sesler (en doğal ücretsiz katman seçenekleri). */
    static final String[][] VOICES_TR = {
            {"tr-TR-Wavenet-A", "WaveNet A (kadın)"},
            {"tr-TR-Wavenet-B", "WaveNet B (erkek)"},
            {"tr-TR-Wavenet-C", "WaveNet C (kadın)"},
            {"tr-TR-Wavenet-D", "WaveNet D (erkek)"},
            {"tr-TR-Wavenet-E", "WaveNet E (kadın)"},
            {"tr-TR-Standard-A", "Standard A (kadın)"},
            {"tr-TR-Standard-B", "Standard B (erkek)"},
            {"tr-TR-Standard-C", "Standard C (kadın)"},
            {"tr-TR-Standard-D", "Standard D (erkek)"},
            {"tr-TR-Standard-E", "Standard E (kadın)"}
    };

    /** İngilizce Neural2 + WaveNet (en gerçekçi). */
    static final String[][] VOICES_EN = {
            {"en-US-Neural2-A", "Neural2 A (female)"},
            {"en-US-Neural2-C", "Neural2 C (female)"},
            {"en-US-Neural2-D", "Neural2 D (male)"},
            {"en-US-Neural2-E", "Neural2 E (female)"},
            {"en-US-Neural2-F", "Neural2 F (female)"},
            {"en-US-Neural2-G", "Neural2 G (female)"},
            {"en-US-Neural2-H", "Neural2 H (female)"},
            {"en-US-Neural2-I", "Neural2 I (male)"},
            {"en-US-Neural2-J", "Neural2 J (male)"},
            {"en-US-Wavenet-A", "WaveNet A (male)"},
            {"en-US-Wavenet-B", "WaveNet B (male)"},
            {"en-US-Wavenet-C", "WaveNet C (female)"},
            {"en-US-Wavenet-D", "WaveNet D (male)"},
            {"en-US-Wavenet-E", "WaveNet E (female)"},
            {"en-US-Wavenet-F", "WaveNet F (female)"},
            {"en-US-Wavenet-G", "WaveNet G (female)"},
            {"en-US-Wavenet-H", "WaveNet H (female)"},
            {"en-US-Wavenet-I", "WaveNet I (male)"},
            {"en-US-Wavenet-J", "WaveNet J (male)"}
    };

    private GoogleTts() {
    }

    /** MP3 baytlarını döndürür. */
    static byte[] synth(String apiKey, String voice, float rate, String text) throws Err {
        HttpURLConnection c = null;
        try {
            String key = apiKey == null ? "" : apiKey.trim();
            if (key.isEmpty()) throw new Err("Google API anahtarı boş", true);

            String lang = "tr-TR";
            if (voice != null && voice.length() >= 5 && voice.startsWith("en-")) lang = "en-US";

            // speakingRate: 0.25 – 4.0 (1.0 = normal)
            double speakingRate = Math.max(0.25, Math.min(4.0, rate));

            JSONObject input = new JSONObject();
            input.put("text", text);

            JSONObject voiceObj = new JSONObject();
            voiceObj.put("languageCode", lang);
            voiceObj.put("name", voice);

            JSONObject audio = new JSONObject();
            audio.put("audioEncoding", "MP3");
            audio.put("speakingRate", speakingRate);
            // Biraz daha yüksek örnekleme kalitesi
            audio.put("sampleRateHertz", 24000);

            JSONObject body = new JSONObject();
            body.put("input", input);
            body.put("voice", voiceObj);
            body.put("audioConfig", audio);

            URL u = new URL("https://texttospeech.googleapis.com/v1/text:synthesize?key="
                    + java.net.URLEncoder.encode(key, "UTF-8"));
            c = (HttpURLConnection) u.openConnection();
            c.setConnectTimeout(12000);
            c.setReadTimeout(45000);
            c.setRequestMethod("POST");
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            c.setRequestProperty("User-Agent", "EkitapOkuyucu/3");

            byte[] req = body.toString().getBytes(StandardCharsets.UTF_8);
            try (OutputStream o = c.getOutputStream()) {
                o.write(req);
            }

            int code = c.getResponseCode();
            InputStream in = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
            ByteArrayOutputStream out = new ByteArrayOutputStream(65536);
            if (in != null) {
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            }
            String resp = out.toString("UTF-8");

            if (code == 200) {
                JSONObject json = new JSONObject(resp);
                String b64 = json.optString("audioContent", "");
                if (b64.isEmpty()) throw new Err("Boş ses geldi", false);
                byte[] audioBytes = Base64.decode(b64, Base64.DEFAULT);
                if (audioBytes == null || audioBytes.length < 200)
                    throw new Err("Boş ses geldi", false);
                return audioBytes;
            }

            String msg = "Google hatası " + code;
            try {
                JSONObject err = new JSONObject(resp);
                if (err.has("error")) {
                    JSONObject e = err.getJSONObject("error");
                    msg = e.optString("message", msg);
                    int status = e.optInt("code", code);
                    if (status == 401 || status == 403)
                        throw new Err("Google API anahtarı geçersiz veya TTS API etkin değil (" + status + ")", true);
                    if (status == 429)
                        throw new Err("Google kota veya hız sınırı aşıldı (429)", true);
                    if (status == 400)
                        throw new Err("Google isteği reddetti: " + msg, true);
                }
            } catch (Err e) {
                throw e;
            } catch (Exception ignored) {
            }
            if (code == 401 || code == 403)
                throw new Err("Google API anahtarı geçersiz veya TTS API etkin değil", true);
            if (code == 429)
                throw new Err("Google kota veya hız sınırı aşıldı (429)", true);
            throw new Err(msg, false);
        } catch (Err e) {
            throw e;
        } catch (IOException e) {
            throw new Err("İnternet bağlantısı yok veya yavaş", false);
        } catch (Exception e) {
            throw new Err("Ses üretilemedi: " + e.getMessage(), false);
        } finally {
            if (c != null) c.disconnect();
        }
    }
}
