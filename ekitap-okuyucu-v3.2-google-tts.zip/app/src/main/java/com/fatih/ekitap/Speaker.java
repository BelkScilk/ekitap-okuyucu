package com.fatih.ekitap;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.PowerManager;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Sesli okuma motoru. Metni cümle gruplarına böler, birkaçını sıraya alır, okunan cümleyi ve
 * kelimeyi bildirir; ses odağı, kulaklık çıkarma ve ekran kapalıyken çalışmayı yönetir.
 */
final class Speaker {

    interface Cb {
        /** Yeni bir cümle grubu okunmaya başladı: metindeki [a,b) aralığı. */
        void onSegment(int a, int b);

        /** Okunan kelime: metindeki [a,b) aralığı. */
        void onWord(int a, int b);

        /** Metnin sonuna gelindi. */
        void onFinished();

        /** Baştan/sondan öteye atlama istendi (dir: -1 önceki, +1 sonraki bölüm). */
        void onEdge(int dir);

        /** Çalıyor / duraklatıldı / durdu durumu değişti. */
        void onState();

        void onMessage(String msg);
    }

    private static final int MAX_SEG = 260;
    private static final int WINDOW = 3;

    private final Context ctx;
    private final Prefs prefs;
    private final Handler ui;
    private final Cb cb;

    private TextToSpeech tts;
    private boolean ready;
    private boolean pendingPlay;

    private String text = "";
    private List<int[]> segs = new ArrayList<>();
    private int idx;
    private int queued;
    private int session;
    private boolean playing;
    private boolean paused;
    private boolean pausedByFocus;
    private float volume = 1f;
    private int lastWordSeg = -1;
    private int lastWordStart = -1;
    private int errors;

    private AudioFocusRequest focusRequest;
    private PowerManager.WakeLock wakeLock;
    private boolean noisyRegistered;

    Speaker(Context c, Prefs p, Handler ui, Cb cb) {
        this.ctx = c.getApplicationContext();
        this.prefs = p;
        this.ui = ui;
        this.cb = cb;
        initTts();
    }

    private void initTts() {
        ready = false;
        try {
            TextToSpeech.OnInitListener l = status -> {
                if (status == TextToSpeech.SUCCESS && tts != null) {
                    ready = true;
                    tts.setOnUtteranceProgressListener(new Progress());
                    tts.setAudioAttributes(attrs());
                    applyConfig();
                    if (pendingPlay) {
                        pendingPlay = false;
                        play();
                    }
                    cb.onState();
                } else {
                    ready = false;
                    cb.onMessage("Ses motoru başlatılamadı. Telefonda bir metin okuma (TTS) motoru kurulu olmalı.");
                }
            };
            String eng = prefs.engine();
            tts = eng.isEmpty() ? new TextToSpeech(ctx, l) : new TextToSpeech(ctx, l, eng);
        } catch (Exception e) {
            tts = null;
        }
    }

    /** Ses motorunu değiştirir (boş = telefonun varsayılanı). */
    void switchEngine() {
        haltSpeech();
        playing = false;
        paused = false;
        try {
            if (tts != null) tts.shutdown();
        } catch (Exception ignored) {
        }
        tts = null;
        initTts();
    }

    static final class EngineInfo {
        final String pkg;
        final String label;

        EngineInfo(String pkg, String label) {
            this.pkg = pkg;
            this.label = label;
        }
    }

    List<EngineInfo> engines() {
        List<EngineInfo> out = new ArrayList<>();
        if (tts == null) return out;
        try {
            for (TextToSpeech.EngineInfo e : tts.getEngines()) out.add(new EngineInfo(e.name, e.label));
        } catch (Exception ignored) {
        }
        return out;
    }

    String currentEngine() {
        try {
            return tts == null ? "" : tts.getDefaultEngine();
        } catch (Exception e) {
            return "";
        }
    }

    // ------------------------------------------------------------------ durum

    boolean isReady() {
        return ready;
    }

    boolean isPlaying() {
        return playing;
    }

    boolean isPaused() {
        return paused;
    }

    /** Çalıyor veya duraklatılmış (yani bir okuma oturumu var). */
    boolean isActive() {
        return playing || paused;
    }

    int segmentCount() {
        return segs.size();
    }

    int currentSegment() {
        return idx;
    }

    String currentText() {
        return text;
    }

    // ------------------------------------------------------------------ metin yükleme

    /** Metni yükler; startOffset'ten itibaren ilk cümle grubundan başlayacak şekilde hazırlar. */
    void load(String t, int startOffset) {
        haltSpeech();
        text = t == null ? "" : t;
        segs = Seg.split(text, MAX_SEG);
        idx = 0;
        for (int i = 0; i < segs.size(); i++) {
            if (segs.get(i)[1] > startOffset) {
                idx = i;
                break;
            }
            idx = i;
        }
        queued = idx;
        lastWordSeg = -1;
        lastWordStart = -1;
        errors = 0;
    }

    // ------------------------------------------------------------------ denetim

    void play() {
        if (!cloudMode() && tts == null) {
            cb.onMessage("Ses motoru yok. Telefonda bir metin okuma (TTS) motoru kurulu olmalı.");
            return;
        }
        if (!cloudMode() && !ready) {
            pendingPlay = true;
            return;
        }
        if (segs.isEmpty()) {
            cb.onFinished();
            return;
        }
        playing = true;
        paused = false;
        pausedByFocus = false;
        acquire();
        startFrom(Math.max(0, Math.min(idx, segs.size() - 1)));
        cb.onState();
    }

    void pause() {
        if (!playing) return;
        playing = false;
        paused = true;
        session++;
        stopMp();
        try {
            if (tts != null) tts.stop();
        } catch (Exception ignored) {
        }
        release(false);
        cb.onState();
    }

    void toggle() {
        if (playing) pause();
        else play();
    }

    /** Okumayı tamamen bitirir. */
    void stop() {
        boolean was = isActive();
        haltSpeech();
        if (was) cb.onState();
    }

    private void haltSpeech() {
        playing = false;
        paused = false;
        pausedByFocus = false;
        pendingPlay = false;
        session++;
        cloudReset();
        try {
            if (tts != null) tts.stop();
        } catch (Exception ignored) {
        }
        release(true);
    }

    void skip(int dir) {
        if (segs.isEmpty()) {
            cb.onEdge(dir);
            return;
        }
        int ni = idx + dir;
        if (ni < 0 || ni >= segs.size()) {
            cb.onEdge(dir);
            return;
        }
        if (playing) {
            startFrom(ni);
        } else {
            idx = ni;
            queued = ni;
            int[] s = segs.get(ni);
            cb.onSegment(s[0], s[1]);
        }
    }

    void shutdown() {
        haltSpeech();
        net.shutdownNow();
        try {
            if (tts != null) tts.shutdown();
        } catch (Exception ignored) {
        }
        tts = null;
        ready = false;
    }

    /** Uyku zamanlayıcısının ses azaltması için (0..1). Yeni cümlelere uygulanır. */
    void setVolume(float v) {
        volume = Math.max(0.05f, Math.min(1f, v));
        try {
            if (mp != null) mp.setVolume(volume, volume);
        } catch (Exception ignored) {
        }
    }

    // ------------------------------------------------------------------ ayarlar

    void applyConfig() {
        if (tts == null || !ready) return;
        String l = prefs.lang();
        Locale loc;
        if ("tr".equals(l)) loc = new Locale("tr", "TR");
        else if ("en".equals(l)) loc = Locale.US;
        else loc = Locale.getDefault();
        int r = tts.setLanguage(loc);
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            cb.onMessage("Bu dil için ses verisi yok. Telefon Ayarları > Metin okuma bölümünden "
                    + "ilgili dili indirin.");
        }
        tts.setSpeechRate(prefs.rate());
        String vn = prefs.voice();
        try {
            Set<Voice> all = tts.getVoices();
            if (all != null) {
                Voice chosen = null;
                if (!vn.isEmpty()) {
                    for (Voice v : all) {
                        if (v.getName().equals(vn)) {
                            chosen = v;
                            break;
                        }
                    }
                }
                // Ses seçilmemişse en yüksek kaliteli, tercihen çevrimdışı Neural sesi seç
                if (chosen == null) {
                    String want = loc.getLanguage();
                    Voice best = null;
                    for (Voice v : all) {
                        if (v.getLocale() == null || !want.equals(v.getLocale().getLanguage())) continue;
                        if (best == null
                                || v.getQuality() > best.getQuality()
                                || (v.getQuality() == best.getQuality()
                                    && !v.isNetworkConnectionRequired()
                                    && best.isNetworkConnectionRequired())) {
                            best = v;
                        }
                    }
                    chosen = best;
                }
                if (chosen != null) tts.setVoice(chosen);
            }
        } catch (Exception ignored) {
        }
    }

    /** Ayar değişince çalıyorsa geçerli cümleyi yeni ayarlarla yeniden başlatır. */
    void applyAndRestart() {
        applyConfig();
        if (cloudMode() || mp != null) cloudInvalidate();
        if (playing && !segs.isEmpty()) startFrom(idx);
    }

    static final class VoiceInfo {
        final String name;
        final String label;

        VoiceInfo(String name, String label) {
            this.name = name;
            this.label = label;
        }
    }

    /** Seçili dile uyan sesler. En yüksek kalite ve çevrimdışı olanlar önce. */
    List<VoiceInfo> voices() {
        List<VoiceInfo> out = new ArrayList<>();
        if (tts == null || !ready) return out;
        String l = prefs.lang();
        String want = "tr".equals(l) ? "tr" : ("en".equals(l) ? "en" : Locale.getDefault().getLanguage());
        try {
            Set<Voice> all = tts.getVoices();
            if (all == null) return out;
            List<Voice> list = new ArrayList<>();
            for (Voice v : all) {
                if (v.getLocale() != null && want.equals(v.getLocale().getLanguage())) list.add(v);
            }
            Collections.sort(list, new Comparator<Voice>() {
                @Override
                public int compare(Voice a, Voice b) {
                    // Önce kalite (yüksek önce), sonra çevrimdışı tercih, sonra isim
                    int q = b.getQuality() - a.getQuality();
                    if (q != 0) return q;
                    if (a.isNetworkConnectionRequired() != b.isNetworkConnectionRequired())
                        return a.isNetworkConnectionRequired() ? 1 : -1;
                    // Neural / yüksek kalite isimlerinde tercih
                    boolean aN = a.getName().toLowerCase(Locale.ROOT).contains("neural")
                            || a.getName().toLowerCase(Locale.ROOT).contains("wavenet")
                            || a.getName().toLowerCase(Locale.ROOT).contains("natural");
                    boolean bN = b.getName().toLowerCase(Locale.ROOT).contains("neural")
                            || b.getName().toLowerCase(Locale.ROOT).contains("wavenet")
                            || b.getName().toLowerCase(Locale.ROOT).contains("natural");
                    if (aN != bN) return aN ? -1 : 1;
                    return a.getName().compareTo(b.getName());
                }
            });
            int n = 1;
            for (Voice v : list) {
                String name = v.getName();
                String shortName = name;
                // Google TTS isimlerini kısalt (com.google.android.tts:tr-tr-x-... -> daha okunur)
                int colon = name.lastIndexOf(':');
                if (colon > 0 && colon < name.length() - 1) shortName = name.substring(colon + 1);
                String label = shortName;
                if (v.getLocale() != null && !v.getLocale().getCountry().isEmpty()) {
                    label += " (" + v.getLocale().getCountry() + ")";
                }
                if (v.getQuality() >= Voice.QUALITY_VERY_HIGH) label += " · çok yüksek kalite";
                else if (v.getQuality() >= Voice.QUALITY_HIGH) label += " · yüksek kalite";
                else label += " · standart";
                if (!v.isNetworkConnectionRequired()) label += " · çevrimdışı";
                else label += " · çevrimiçi";
                String low = name.toLowerCase(Locale.ROOT);
                if (low.contains("neural") || low.contains("wavenet") || low.contains("natural")
                        || low.contains("studio")) {
                    label += " · Neural";
                }
                out.add(new VoiceInfo(v.getName(), label));
                n++;
            }
        } catch (Exception ignored) {
        }
        return out;
    }

    // ------------------------------------------------------------------ yapay zekâ sesi (Azure)

    private final ExecutorService net = Executors.newSingleThreadExecutor();
    private final Map<Integer, File> audio = new HashMap<>();
    private final HashSet<Integer> inflight = new HashSet<>();
    private int audioGen;
    private MediaPlayer mp;
    private int cloudWant;
    private int cloudErr;
    private int[][] wordPos = new int[0][];
    private float[] wordEnd = new float[0];
    private int curSeg = -1;

    boolean cloudMode() {
        return prefs.cloudOn() && !prefs.cloudKey().trim().isEmpty();
    }

    private void stopMp() {
        ui.removeCallbacks(wordTick);
        if (mp != null) {
            try {
                mp.setOnCompletionListener(null);
                mp.setOnPreparedListener(null);
                mp.setOnErrorListener(null);
                mp.stop();
            } catch (Exception ignored) {
            }
            try {
                mp.release();
            } catch (Exception ignored) {
            }
            mp = null;
        }
    }

    /** Hazır ses dosyalarını siler; uçuştaki istekleri geçersiz kılar. */
    private void cloudReset() {
        stopMp();
        audioGen++;
        for (File f : audio.values()) {
            try {
                f.delete();
            } catch (Exception ignored) {
            }
        }
        audio.clear();
        inflight.clear();
        cloudErr = 0;
    }

    /** Hız / ses değişti: hazır sesler geçersiz, çalıyorsa geçerli cümleden yeniden başlar. */
    private void cloudInvalidate() {
        cloudReset();
        if (playing && !segs.isEmpty() && cloudMode()) startFrom(idx);
    }

    private void cloudStart(int i) {
        stopMp();
        session++;
        idx = i;
        queued = i;
        cloudWant = i;
        lastWordSeg = -1;
        lastWordStart = -1;
        int[] s = segs.get(i);
        cb.onSegment(s[0], s[1]);
        prefetch(i);
        File f = audio.get(i);
        if (f != null) playFile(i, f);
    }

    private void prefetch(int from) {
        for (int k = from; k < segs.size() && k <= from + WINDOW; k++) {
            if (audio.containsKey(k) || inflight.contains(k)) continue;
            inflight.add(k);
            final int kk = k;
            final int gen = audioGen;
            final String txt = text.substring(segs.get(k)[0], segs.get(k)[1]);
            final String key = prefs.cloudKey();
            final String region = prefs.cloudRegion();
            final String voice = prefs.cloudVoice();
            final float rate = prefs.rate();
            final String provider = prefs.cloudProvider();
            try {
                net.execute(() -> {
                    try {
                        byte[] b;
                        if ("google".equals(provider)) {
                            b = GoogleTts.synth(key, voice, rate, txt);
                        } else {
                            b = CloudTts.synth(key, region, voice, rate, txt);
                        }
                        File f = File.createTempFile("tts", ".mp3", ctx.getCacheDir());
                        try (FileOutputStream o = new FileOutputStream(f)) {
                            o.write(b);
                        }
                        ui.post(() -> {
                            inflight.remove(kk);
                            if (gen != audioGen) {
                                f.delete();
                                return;
                            }
                            audio.put(kk, f);
                            if (playing && kk == cloudWant && mp == null) playFile(kk, f);
                        });
                    } catch (CloudTts.Err e) {
                        ui.post(() -> cloudFail(kk, gen, e.getMessage(), e.fatal));
                    } catch (GoogleTts.Err e) {
                        ui.post(() -> cloudFail(kk, gen, e.getMessage(), e.fatal));
                    } catch (Exception e) {
                        ui.post(() -> cloudFail(kk, gen, "Ses dosyası yazılamadı", false));
                    }
                });
            } catch (Exception e) {
                inflight.remove(k);
            }
        }
    }

    private void cloudFail(int k, int gen, String msg, boolean fatal) {
        inflight.remove(k);
        if (gen != audioGen || !playing) return;
        if (fatal || ++cloudErr > 3) {
            cb.onMessage(msg);
            pause();
            return;
        }
        ui.postDelayed(() -> {
            if (playing && gen == audioGen) prefetch(cloudWant);
        }, 1500);
    }

    private void playFile(final int k, File f) {
        stopMp();
        final int ses = session;
        try {
            final MediaPlayer m = new MediaPlayer();
            mp = m;
            m.setAudioAttributes(attrs());
            m.setDataSource(f.getPath());
            m.setVolume(volume, volume);
            m.setOnPreparedListener(p -> {
                if (mp != p || ses != session || !playing) return;
                errors = 0;
                cloudErr = 0;
                buildWords(k, p.getDuration());
                p.start();
                curSeg = k;
                ui.post(wordTick);
                prefetch(k + 1);
            });
            m.setOnCompletionListener(p -> {
                if (mp != p || ses != session || !playing) return;
                stopMp();
                File done = audio.remove(k);
                if (done != null) done.delete();
                if (k >= segs.size() - 1) {
                    playing = false;
                    paused = false;
                    release(true);
                    cb.onState();
                    cb.onFinished();
                } else {
                    cloudStart(k + 1);
                }
            });
            m.setOnErrorListener((p, what, extra) -> {
                if (mp != p || ses != session) return true;
                ui.post(() -> {
                    if (!playing) return;
                    if (++errors > 3) {
                        cb.onMessage("Ses çalınamadı, okuma duraklatıldı");
                        pause();
                    } else {
                        File bad = audio.remove(k);
                        if (bad != null) bad.delete();
                        cloudStart(k);
                    }
                });
                return true;
            });
            m.prepareAsync();
        } catch (Exception e) {
            ui.post(() -> {
                cb.onMessage("Ses çalınamadı");
                pause();
            });
        }
    }

    /** Azure REST kelime zamanı vermez; kelimelere harf sayısı + noktalama payıyla süre dağıtılır. */
    private void buildWords(int k, int durMs) {
        int[] s = segs.get(k);
        String seg = text.substring(s[0], s[1]);
        List<int[]> ws = new ArrayList<>();
        List<Float> w = new ArrayList<>();
        int from = 0;
        while (true) {
            int[] r = Seg.nextWord(seg, from);
            if (r == null) break;
            float weight = 1f + (r[1] - r[0]);
            if (r[1] < seg.length()) {
                char c = seg.charAt(r[1]);
                if (c == ',' || c == ';' || c == ':') weight += 2.5f;
                else if (c == '.' || c == '!' || c == '?') weight += 5f;
            }
            ws.add(r);
            w.add(weight);
            from = r[1];
        }
        wordPos = ws.toArray(new int[0][]);
        wordEnd = new float[w.size()];
        float tot = 0;
        for (float x : w) tot += x;
        float acc = 0;
        for (int i = 0; i < wordEnd.length; i++) {
            acc += w.get(i);
            wordEnd[i] = tot <= 0 ? 1f : acc / tot;
        }
    }

    private final Runnable wordTick = new Runnable() {
        @Override
        public void run() {
            MediaPlayer m = mp;
            if (m == null || !playing || curSeg < 0 || curSeg >= segs.size()) return;
            try {
                int dur = m.getDuration();
                if (dur > 0 && wordEnd.length > 0) {
                    // baştaki / sondaki sessizlik payı
                    float t = (m.getCurrentPosition() - 80f) / Math.max(1f, dur - 220f);
                    int wi = 0;
                    while (wi < wordEnd.length - 1 && wordEnd[wi] < t) wi++;
                    int[] s = segs.get(curSeg);
                    int a = wordPos[wi][0];
                    if (!(curSeg == lastWordSeg && a <= lastWordStart)) {
                        lastWordSeg = curSeg;
                        lastWordStart = a;
                        cb.onWord(s[0] + a, s[0] + wordPos[wi][1]);
                    }
                }
            } catch (Exception ignored) {
            }
            ui.postDelayed(this, 60);
        }
    };

    /** Anahtarı denemek için kısa bir cümle üretir (arka planda); sonuç ana iş parçacığında döner. */
    void testCloud(final Runnable ok, final java.util.function.Consumer<String> fail) {
        final String key = prefs.cloudKey();
        final String region = prefs.cloudRegion();
        final String voice = prefs.cloudVoice();
        final String provider = prefs.cloudProvider();
        new Thread(() -> {
            try {
                if ("google".equals(provider)) {
                    GoogleTts.synth(key, voice, 1f, "Merhaba, bağlantı çalışıyor.");
                } else {
                    CloudTts.synth(key, region, voice, 1f, "Merhaba, bağlantı çalışıyor.");
                }
                ui.post(ok);
            } catch (CloudTts.Err e) {
                ui.post(() -> fail.accept(e.getMessage()));
            } catch (GoogleTts.Err e) {
                ui.post(() -> fail.accept(e.getMessage()));
            } catch (Exception e) {
                ui.post(() -> fail.accept("Ses üretilemedi"));
            }
        }).start();
    }

    // ------------------------------------------------------------------ sıraya alma

    private void startFrom(int i) {
        if (segs.isEmpty()) return;
        if (cloudMode()) {
            cloudStart(Math.max(0, Math.min(i, segs.size() - 1)));
            return;
        }
        if (tts == null || !ready) return;
        session++;
        idx = Math.max(0, Math.min(i, segs.size() - 1));
        queued = idx;
        lastWordSeg = -1;
        lastWordStart = -1;
        try {
            tts.stop();
        } catch (Exception ignored) {
        }
        int[] s = segs.get(idx);
        cb.onSegment(s[0], s[1]);
        fill();
    }

    private void fill() {
        if (tts == null || !ready) return;
        while (queued < segs.size() && queued < idx + 1 + WINDOW) {
            int[] s = segs.get(queued);
            Bundle b = new Bundle();
            b.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, volume);
            int r = tts.speak(text.substring(s[0], s[1]), TextToSpeech.QUEUE_ADD, b,
                    "s" + session + "_" + queued);
            if (r != TextToSpeech.SUCCESS) {
                cb.onMessage("Ses motoru yanıt vermiyor");
                pause();
                return;
            }
            queued++;
        }
    }

    private int parseSeg(String id) {
        try {
            String[] a = id.substring(1).split("_");
            if (Integer.parseInt(a[0]) != session) return -1;
            return Integer.parseInt(a[1]);
        } catch (Exception e) {
            return -1;
        }
    }

    private final class Progress extends UtteranceProgressListener {
        @Override
        public void onStart(final String id) {
            ui.post(() -> {
                int i = parseSeg(id);
                if (i < 0 || !playing || i >= segs.size()) return;
                errors = 0;
                if (i != idx) {
                    idx = i;
                    lastWordSeg = -1;
                    lastWordStart = -1;
                    int[] s = segs.get(i);
                    cb.onSegment(s[0], s[1]);
                }
                fill();
            });
        }

        @Override
        public void onRangeStart(final String id, final int start, final int end, int frame) {
            ui.post(() -> {
                int i = parseSeg(id);
                if (i < 0 || !playing || i >= segs.size()) return;
                int[] s = segs.get(i);
                String seg = text.substring(s[0], s[1]);
                int[] w = Seg.snapWord(seg, start, end);
                if (w == null) return;
                if (i == lastWordSeg && w[0] <= lastWordStart) return; // geriye gitme
                lastWordSeg = i;
                lastWordStart = w[0];
                cb.onWord(s[0] + w[0], s[0] + w[1]);
            });
        }

        @Override
        public void onDone(final String id) {
            ui.post(() -> finishedSegment(id, false));
        }

        @Override
        public void onError(final String id) {
            ui.post(() -> finishedSegment(id, true));
        }
    }

    private void finishedSegment(String id, boolean error) {
        int i = parseSeg(id);
        if (i < 0 || !playing) return;
        if (error && ++errors > 3) {
            cb.onMessage("Ses motoru hata verdi, okuma duraklatıldı");
            pause();
            return;
        }
        if (i >= segs.size() - 1) {
            playing = false;
            paused = false;
            release(true);
            cb.onState();
            cb.onFinished();
        }
    }

    // ------------------------------------------------------------------ ses odağı, kulaklık, uyanık kalma

    private static AudioAttributes attrs() {
        return new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build();
    }

    private final AudioManager.OnAudioFocusChangeListener focusListener = change -> {
        if (change == AudioManager.AUDIOFOCUS_LOSS) {
            if (playing) pause();
            pausedByFocus = false;
        } else if (change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) {
            if (playing) {
                pausedByFocus = true; // odağı bırakma, geri gelince devam edeceğiz
                pause();
            }
        } else if (change == AudioManager.AUDIOFOCUS_GAIN) {
            if (pausedByFocus && paused) {
                pausedByFocus = false;
                play();
            }
        }
    };

    private final BroadcastReceiver noisy = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            if (playing) pause();
        }
    };

    private void acquire() {
        try {
            PowerManager pm = (PowerManager) ctx.getSystemService(Context.POWER_SERVICE);
            if (wakeLock == null && pm != null) {
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ekitap:tts");
            }
            if (wakeLock != null && !wakeLock.isHeld()) wakeLock.acquire(6 * 60 * 60 * 1000L);
        } catch (Exception ignored) {
        }
        try {
            AudioManager am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
            if (am != null) {
                if (focusRequest == null) {
                    focusRequest = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                            .setAudioAttributes(attrs())
                            .setOnAudioFocusChangeListener(focusListener, ui)
                            .build();
                }
                am.requestAudioFocus(focusRequest);
            }
        } catch (Exception ignored) {
        }
        if (!noisyRegistered) {
            try {
                IntentFilter f = new IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY);
                if (Build.VERSION.SDK_INT >= 33) {
                    ctx.registerReceiver(noisy, f, Context.RECEIVER_NOT_EXPORTED);
                } else {
                    ctx.registerReceiver(noisy, f);
                }
                noisyRegistered = true;
            } catch (Exception ignored) {
            }
        }
    }

    /** Duraklatınca / bitirince kaynakları bırakır. full=true ise ses odağı da bırakılır. */
    private void release(boolean full) {
        try {
            if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        } catch (Exception ignored) {
        }
        if (noisyRegistered) {
            try {
                ctx.unregisterReceiver(noisy);
            } catch (Exception ignored) {
            }
            noisyRegistered = false;
        }
        if (full || paused) {
            try {
                AudioManager am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
                if (am != null && focusRequest != null && !pausedByFocus) {
                    am.abandonAudioFocusRequest(focusRequest);
                }
            } catch (Exception ignored) {
            }
        }
    }
}
