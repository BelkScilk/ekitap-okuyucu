package com.fatih.ekitap;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

/** Azure Speech (resmi REST arayüzü) ile yapay zekâ sesi üretir. Kullanıcının kendi anahtarı gerekir. */
final class CloudTts {

    static final class Err extends Exception {
        final boolean fatal;

        Err(String m, boolean fatal) {
            super(m);
            this.fatal = fatal;
        }
    }

    /**
     * Türkçe Neural sesler (Azure). Emel / Ahmet ana sesler; çok dilli Neural sesler de Türkçe
     * konuşabilir ve genelde daha zengin prozodiye sahiptir.
     */
    static final String[][] VOICES_TR = {
            {"tr-TR-EmelNeural", "Emel (kadın · Neural)"},
            {"tr-TR-AhmetNeural", "Ahmet (erkek · Neural)"},
            {"en-US-AvaMultilingualNeural", "Ava (çok dilli · kadın)"},
            {"en-US-AndrewMultilingualNeural", "Andrew (çok dilli · erkek)"},
            {"en-US-EmmaMultilingualNeural", "Emma (çok dilli · kadın)"},
            {"en-US-BrianMultilingualNeural", "Brian (çok dilli · erkek)"},
            {"en-US-JennyMultilingualNeural", "Jenny (çok dilli · kadın)"},
            {"en-US-RyanMultilingualNeural", "Ryan (çok dilli · erkek)"}
    };

    /** İngilizce Neural / Multilingual sesler (en doğal seçenekler). */
    static final String[][] VOICES_EN = {
            {"en-US-AvaNeural", "Ava (female · Neural)"},
            {"en-US-AndrewNeural", "Andrew (male · Neural)"},
            {"en-US-EmmaNeural", "Emma (female · Neural)"},
            {"en-US-BrianNeural", "Brian (male · Neural)"},
            {"en-US-JennyNeural", "Jenny (female · Neural)"},
            {"en-US-GuyNeural", "Guy (male · Neural)"},
            {"en-US-SaraNeural", "Sara (female · Neural)"},
            {"en-US-TonyNeural", "Tony (male · Neural)"},
            {"en-US-AriaNeural", "Aria (female · Neural)"},
            {"en-US-DavisNeural", "Davis (male · Neural)"},
            {"en-US-JaneNeural", "Jane (female · Neural)"},
            {"en-US-JasonNeural", "Jason (male · Neural)"},
            {"en-US-NancyNeural", "Nancy (female · Neural)"},
            {"en-US-RogerNeural", "Roger (male · Neural)"},
            {"en-US-SteffanNeural", "Steffan (male · Neural)"},
            {"en-US-AvaMultilingualNeural", "Ava Multilingual"},
            {"en-US-AndrewMultilingualNeural", "Andrew Multilingual"},
            {"en-US-EmmaMultilingualNeural", "Emma Multilingual"},
            {"en-US-BrianMultilingualNeural", "Brian Multilingual"}
    };

    private CloudTts() {
    }

    static String esc(String s) {
        StringBuilder b = new StringBuilder(s.length() + 16);
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '&': b.append("&amp;"); break;
                case '<': b.append("&lt;"); break;
                case '>': b.append("&gt;"); break;
                case '"': b.append("&quot;"); break;
                case '\'': b.append("&apos;"); break;
                default:
                    if (c >= 0x20 || c == '\n' || c == '\t') b.append(c);
            }
        }
        return b.toString();
    }

    /**
     * Daha doğal prozodi için SSML üretir.
     * - Rate prosody
     * - Cümle sonu sessizlikleri (mstts:silence)
     * - Multilingual seslerde Türkçe için lang etiketi
     * - Destekleyen seslerde hafif narration stili
     */
    static String ssml(String voice, float rate, String text) {
        String lang = "tr-TR";
        if (voice != null && voice.length() >= 5) {
            String prefix = voice.substring(0, 5);
            if (prefix.startsWith("en-")) lang = "en-US";
            else if (prefix.startsWith("tr-")) lang = "tr-TR";
        }

        int pct = Math.round((rate - 1f) * 100f);
        pct = Math.max(-50, Math.min(100, pct));
        String rateStr = (pct >= 0 ? "+" : "") + pct + "%";

        boolean multi = voice != null && voice.contains("Multilingual");
        String body = esc(text);
        if (multi) {
            String textLang = lang.startsWith("tr") ? "tr-TR" : "en-US";
            body = "<lang xml:lang='" + textLang + "'>" + body + "</lang>";
        }

        String prosody = "<prosody rate='" + rateStr + "' pitch='+0%'>"
                + body
                + "</prosody>";

        String withSilence =
                "<mstts:silence type='Sentenceboundary' value='180ms'/>"
                        + prosody
                        + "<mstts:silence type='Sentenceboundary' value='120ms'/>";

        String styleWrap = withSilence;
        if (voice != null && (voice.contains("Jenny") || voice.contains("Aria")
                || voice.contains("Sara") || voice.contains("Ava")
                || voice.contains("Emma") || voice.contains("Nancy"))) {
            styleWrap = "<mstts:express-as style='narration-relaxed' styledegree='1'>"
                    + withSilence + "</mstts:express-as>";
        } else if (voice != null && (voice.contains("Guy") || voice.contains("Davis")
                || voice.contains("Tony") || voice.contains("Andrew")
                || voice.contains("Brian") || voice.contains("Roger"))) {
            styleWrap = "<mstts:express-as style='narration-professional' styledegree='1'>"
                    + withSilence + "</mstts:express-as>";
        }

        return "<speak version='1.0' xml:lang='" + lang
                + "' xmlns='http://www.w3.org/2001/10/synthesis'"
                + " xmlns:mstts='https://www.w3.org/2001/mstts'>"
                + "<voice name='" + voice + "'>"
                + styleWrap
                + "</voice></speak>";
    }

    /** MP3 baytlarını döndürür. */
    static byte[] synth(String key, String region, String voice, float rate, String text)
            throws Err {
        HttpURLConnection c = null;
        try {
            String reg = region == null || region.trim().isEmpty() ? "westeurope"
                    : region.trim().toLowerCase(Locale.ROOT);
            URL u = new URL("https://" + reg + ".tts.speech.microsoft.com/cognitiveservices/v1");
            c = (HttpURLConnection) u.openConnection();
            c.setConnectTimeout(12000);
            c.setReadTimeout(45000);
            c.setRequestMethod("POST");
            c.setDoOutput(true);
            c.setRequestProperty("Ocp-Apim-Subscription-Key", key.trim());
            c.setRequestProperty("Content-Type", "application/ssml+xml");
            // Daha yüksek kalite: 48 kHz 192 kbps
            c.setRequestProperty("X-Microsoft-OutputFormat", "audio-48khz-192kbitrate-mono-mp3");
            c.setRequestProperty("User-Agent", "EkitapOkuyucu/3");
            byte[] body = ssml(voice, rate, text).getBytes(StandardCharsets.UTF_8);
            try (OutputStream o = c.getOutputStream()) {
                o.write(body);
            }
            int code = c.getResponseCode();
            if (code == 200) {
                try (InputStream in = c.getInputStream()) {
                    ByteArrayOutputStream out = new ByteArrayOutputStream(65536);
                    byte[] buf = new byte[8192];
                    int n;
                    while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                    if (out.size() < 200) throw new Err("Boş ses geldi", false);
                    return out.toByteArray();
                }
            }
            // Daha düşük bitrate ile yeniden dene
            if (code == 400 || code == 415) {
                return synthFallback(key, reg, voice, rate, text);
            }
            if (code == 401 || code == 403)
                throw new Err("Azure anahtarı veya bölge hatalı (" + code + ")", true);
            if (code == 429)
                throw new Err("Azure ücretsiz kullanım sınırı doldu veya çok sık istek (429)", true);
            if (code == 400)
                throw new Err("Azure isteği reddetti (400). Ses adı bölgede yok olabilir", true);
            if (code == 404)
                throw new Err("Bölge adı hatalı (404)", true);
            throw new Err("Azure hatası " + code, false);
        } catch (Err e) {
            throw e;
        } catch (IOException e) {
            throw new Err("İnternet bağlantısı yok veya yavaş", false);
        } catch (Exception e) {
            throw new Err("Ses üretilemedi", false);
        } finally {
            if (c != null) c.disconnect();
        }
    }

    /** Eski formatla yedek sentez (daha geniş uyumluluk). */
    private static byte[] synthFallback(String key, String reg, String voice, float rate, String text)
            throws Err {
        HttpURLConnection c = null;
        try {
            URL u = new URL("https://" + reg + ".tts.speech.microsoft.com/cognitiveservices/v1");
            c = (HttpURLConnection) u.openConnection();
            c.setConnectTimeout(12000);
            c.setReadTimeout(45000);
            c.setRequestMethod("POST");
            c.setDoOutput(true);
            c.setRequestProperty("Ocp-Apim-Subscription-Key", key.trim());
            c.setRequestProperty("Content-Type", "application/ssml+xml");
            c.setRequestProperty("X-Microsoft-OutputFormat", "audio-24khz-48kbitrate-mono-mp3");
            c.setRequestProperty("User-Agent", "EkitapOkuyucu/3");
            byte[] body = ssml(voice, rate, text).getBytes(StandardCharsets.UTF_8);
            try (OutputStream o = c.getOutputStream()) {
                o.write(body);
            }
            int code = c.getResponseCode();
            if (code == 200) {
                try (InputStream in = c.getInputStream()) {
                    ByteArrayOutputStream out = new ByteArrayOutputStream(32768);
                    byte[] buf = new byte[8192];
                    int n;
                    while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                    if (out.size() < 200) throw new Err("Boş ses geldi", false);
                    return out.toByteArray();
                }
            }
            if (code == 401 || code == 403)
                throw new Err("Azure anahtarı veya bölge hatalı (" + code + ")", true);
            if (code == 429)
                throw new Err("Azure ücretsiz kullanım sınırı doldu veya çok sık istek (429)", true);
            if (code == 400)
                throw new Err("Azure isteği reddetti (400). Ses adı bölgede yok olabilir", true);
            throw new Err("Azure hatası " + code, false);
        } catch (Err e) {
            throw e;
        } catch (IOException e) {
            throw new Err("İnternet bağlantısı yok veya yavaş", false);
        } catch (Exception e) {
            throw new Err("Ses üretilemedi", false);
        } finally {
            if (c != null) c.disconnect();
        }
    }
}
