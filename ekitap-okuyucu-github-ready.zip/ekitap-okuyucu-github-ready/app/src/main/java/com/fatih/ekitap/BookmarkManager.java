package com.fatih.ekitap;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

public class BookmarkManager {
    public static class Bookmark {
        public final String id;
        public final String bookKey;
        public final String title;
        public final String textSnippet;
        public final int position;
        public final long timestamp;

        public Bookmark(String id, String bookKey, String title, String textSnippet, int position, long timestamp) {
            this.id = id;
            this.bookKey = bookKey;
            this.title = title;
            this.textSnippet = textSnippet;
            this.position = position;
            this.timestamp = timestamp;
        }
    }

    private final SharedPreferences sp;

    public BookmarkManager(Context context) {
        sp = context.getApplicationContext().getSharedPreferences("ekitap_bookmarks", Context.MODE_PRIVATE);
    }

    public List<Bookmark> getBookmarks(String bookKey) {
        List<Bookmark> list = new ArrayList<>();
        String json = sp.getString("bm_" + bookKey, "[]");
        try {
            JSONArray array = new JSONArray(json);
            for (int i = 0; i < array.length(); i++) {
                JSONObject obj = array.getJSONObject(i);
                list.add(new Bookmark(
                        obj.getString("id"),
                        obj.getString("bookKey"),
                        obj.optString("title", "Yer İmi"),
                        obj.optString("textSnippet", ""),
                        obj.optInt("position", 0),
                        obj.optLong("timestamp", System.currentTimeMillis())
                ));
            }
        } catch (Exception ignored) {}
        return list;
    }

    public void addBookmark(String bookKey, String title, String textSnippet, int position) {
        List<Bookmark> list = getBookmarks(bookKey);
        String id = String.valueOf(System.currentTimeMillis());
        list.add(0, new Bookmark(id, bookKey, title, textSnippet, position, System.currentTimeMillis()));
        saveBookmarks(bookKey, list);
    }

    public void removeBookmark(String bookKey, String bookmarkId) {
        List<Bookmark> list = getBookmarks(bookKey);
        for (int i = list.size() - 1; i >= 0; i--) {
            if (list.get(i).id.equals(bookmarkId)) {
                list.remove(i);
            }
        }
        saveBookmarks(bookKey, list);
    }

    private void saveBookmarks(String bookKey, List<Bookmark> list) {
        try {
            JSONArray array = new JSONArray();
            for (Bookmark b : list) {
                JSONObject obj = new JSONObject();
                obj.put("id", b.id);
                obj.put("bookKey", b.bookKey);
                obj.put("title", b.title);
                obj.put("textSnippet", b.textSnippet);
                obj.put("position", b.position);
                obj.put("timestamp", b.timestamp);
                array.put(obj);
            }
            sp.edit().putString("bm_" + bookKey, array.toString()).apply();
        } catch (Exception ignored) {}
    }
}
