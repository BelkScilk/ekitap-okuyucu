package com.fatih.ekitap;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** Ayarlar, okuma konumu ve son açılan kitaplar. */
final class Prefs {
    static final int LIGHT = 0;
    static final int DARK = 1;
    static final int SEPIA = 2;

    static final class Recent {
        final String uri;
        final String name;
        final String type;

        Recent(String uri, String name, String type) {
            this.uri = uri;
            this.name = name;
            this.type = type;
        }
    }

    private final SharedPreferences sp;

    Prefs(Context c) {
        sp = c.getApplicationContext().getSharedPreferences("ekitap", Context.MODE_PRIVATE);
    }

    // ---- görünüm / ses ayarları ----
    int theme() { return sp.getInt("theme", DARK); }
    void setTheme(int t) { sp.edit().putInt("theme", t).apply(); }

    int textZoom() { return sp.getInt("textZoom", 100); }
    void setTextZoom(int z) { sp.edit().putInt("textZoom", z).apply(); }

    float pdfZoom() { return sp.getFloat("pdfZoom", 1f); }
    void setPdfZoom(float z) { sp.edit().putFloat("pdfZoom", z).apply(); }

    float rate() { return sp.getFloat("rate", 1f); }
    void setRate(float r) { sp.edit().putFloat("rate", r).apply(); }

    String lang() { return sp.getString("lang", "tr"); }
    void setLang(String l) { sp.edit().putString("lang", l).apply(); }

    boolean keepOn() { return sp.getBoolean("keepOn", true); }
    void setKeepOn(boolean b) { sp.edit().putBoolean("keepOn", b).apply(); }

    // ---- tema renkleri ----
    static int bg(int t) {
        switch (t) {
            case LIGHT: return 0xFFFFFFFF;
            case SEPIA: return 0xFFF4ECD8;
            default: return 0xFF121212;
        }
    }

    static int fg(int t) {
        switch (t) {
            case LIGHT: return 0xFF1A1A1A;
            case SEPIA: return 0xFF5B4636;
            default: return 0xFFE0E0E0;
        }
    }

    static int bar(int t) {
        switch (t) {
            case LIGHT: return 0xFFEEEEEE;
            case SEPIA: return 0xFFE8DCBF;
            default: return 0xFF1E1E1E;
        }
    }

    static int link(int t) {
        switch (t) {
            case LIGHT: return 0xFF1A0DAB;
            case SEPIA: return 0xFF8B4513;
            default: return 0xFF8AB4F8;
        }
    }

    // ---- okuma konumu (kitap anahtarı ile) ----
    int chapter(String key) { return sp.getInt("ch_" + key, 0); }
    float frac(String key) { return sp.getFloat("fr_" + key, 0f); }
    int page(String key) { return sp.getInt("pg_" + key, 0); }

    void saveChapter(String key, int ch) { sp.edit().putInt("ch_" + key, ch).apply(); }
    void saveFrac(String key, float f) { sp.edit().putFloat("fr_" + key, f).apply(); }
    void savePage(String key, int p) { sp.edit().putInt("pg_" + key, p).apply(); }

    // ---- son açılanlar ----
    List<Recent> recents() {
        List<Recent> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(sp.getString("recents", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                out.add(new Recent(o.getString("uri"), o.optString("name", "Kitap"),
                        o.optString("type", "")));
            }
        } catch (Exception ignored) {
        }
        return out;
    }

    private void saveRecents(List<Recent> list) {
        try {
            JSONArray a = new JSONArray();
            for (Recent r : list) {
                JSONObject o = new JSONObject();
                o.put("uri", r.uri);
                o.put("name", r.name);
                o.put("type", r.type);
                a.put(o);
            }
            sp.edit().putString("recents", a.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    void addRecent(Recent r) {
        List<Recent> list = recents();
        for (int i = list.size() - 1; i >= 0; i--) {
            if (list.get(i).uri.equals(r.uri)) list.remove(i);
        }
        list.add(0, r);
        while (list.size() > 30) list.remove(list.size() - 1);
        saveRecents(list);
    }

    void removeRecent(String uri) {
        List<Recent> list = recents();
        for (int i = list.size() - 1; i >= 0; i--) {
            if (list.get(i).uri.equals(uri)) list.remove(i);
        }
        saveRecents(list);
    }
}
