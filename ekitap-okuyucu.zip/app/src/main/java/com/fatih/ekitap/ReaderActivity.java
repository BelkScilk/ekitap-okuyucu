package com.fatih.ekitap;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Matrix;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.os.PowerManager;
import android.os.SystemClock;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.text.InputType;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.view.GestureDetector;
import android.view.ScaleGestureDetector;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Consumer;
import java.util.zip.ZipEntry;

/** EPUB / PDF okuyucu: tema, yazı boyutu / yakınlaştırma, sesli okuma, uyku zamanlayıcısı. */
public class ReaderActivity extends Activity {

    private static final String HOST = "epub.local";
    private static final int MAX_CHUNK = 1200;

    private static final int M_TOC = 1;
    private static final int M_THEME = 2;
    private static final int M_TIMER = 3;
    private static final int M_RATE = 4;
    private static final int M_LANG = 5;
    private static final int M_KEEP = 6;
    private static final int M_CROP = 8;
    private static final int M_TEXT = 7;

    private Prefs prefs;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();

    // ---- görünümler ----
    private LinearLayout root;
    private LinearLayout topBar;
    private LinearLayout bottomBar;
    private FrameLayout content;
    private TextView titleView;
    private TextView timerView;
    private TextView pageView;
    private TextView loadingView;
    private Button btnBack;
    private Button btnMenu;
    private Button btnPrev;
    private Button btnNext;
    private Button btnMinus;
    private Button btnPlus;
    private Button btnPlay;
    private WebView web;
    private ScrollView pdfV;
    private HorizontalScrollView pdfH;
    private ImageView pdfImg;

    // ---- kitap durumu ----
    private Uri uri;
    private String key = "";
    private boolean isPdf;
    private boolean loaded;

    // EPUB
    private volatile EpubBook book;
    private int chapter;
    private float pendingFrac = -1f;
    private boolean speakAfterLoad;

    // PDF (PdfRenderer'a yalnızca io iş parçacığından dokunulur)
    private PdfRenderer pdf;
    private ParcelFileDescriptor pfd;
    private int pageCount;
    private int pageIndex;
    private float pdfZoom = 1f;
    private int renderToken;
    private ScaleGestureDetector scaleDetector;
    private GestureDetector flingDetector;
    private GestureDetector tapDetector;
    private boolean barsVisible = true;
    private final Map<Integer, float[]> boxCache = new HashMap<>(); // yalnızca io iş parçacığı
    private float[] hCrop; // {sol, sağ} oranları; yalnızca io iş parçacığı
    private TextRecognizer recognizer;
    private final Map<Integer, String> ocrCache = new HashMap<>();
    private final Map<Integer, List<Consumer<String>>> ocrWaiters = new HashMap<>();
    private ScrollView reflowV;
    private TextView reflowText;
    private boolean textMode;

    // ---- sesli okuma ----
    private TextToSpeech tts;
    private boolean ttsReady;
    private boolean speaking;
    private int session;
    private List<String> chunks = new ArrayList<>();
    private int[] cum = new int[0];
    private int totalLen;
    private double baseFrac;
    private int curIdx;
    private Runnable onSpeechEnd;
    private PowerManager.WakeLock wakeLock;

    // ---- uyku zamanlayıcısı ----
    private long timerEnd = 0;
    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (timerEnd <= 0) {
                timerView.setText("");
                return;
            }
            long rem = timerEnd - SystemClock.elapsedRealtime();
            if (rem <= 0) {
                onTimerExpired();
                return;
            }
            long s = rem / 1000;
            timerView.setText(String.format(Locale.US, "⏱ %d:%02d", s / 60, s % 60));
            ui.postDelayed(this, 1000);
        }
    };

    // =================================================================== yaşam döngüsü

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = new Prefs(this);
        pdfZoom = Math.max(1f, Math.min(5f, prefs.pdfZoom()));
        buildUi();
        applyChrome();
        if (prefs.keepOn()) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }
        initTts();
        initOcr();

        uri = getIntent() == null ? null : getIntent().getData();
        if (uri == null) {
            toast("Açılacak dosya bulunamadı");
            finish();
            return;
        }
        key = Integer.toHexString(uri.toString().hashCode());
        loadBook();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (timerEnd > 0) {
            ui.removeCallbacks(tick);
            ui.post(tick);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        saveEpubPosition();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        speaking = false;
        session++;
        ui.removeCallbacksAndMessages(null);
        releaseKeepAlive();
        if (tts != null) {
            try {
                tts.stop();
                tts.shutdown();
            } catch (Exception ignored) {
            }
            tts = null;
        }
        if (recognizer != null) {
            try {
                recognizer.close();
            } catch (Exception ignored) {
            }
            recognizer = null;
        }
        if (web != null) {
            try {
                web.destroy();
            } catch (Exception ignored) {
            }
            web = null;
        }
        final EpubBook b = book;
        book = null;
        if (b != null) {
            try {
                b.close();
            } catch (IOException ignored) {
            }
        }
        io.execute(() -> {
            try {
                if (pdf != null) pdf.close();
            } catch (Exception ignored) {
            }
            try {
                if (pfd != null) pfd.close();
            } catch (Exception ignored) {
            }
            pdf = null;
            pfd = null;
        });
        io.shutdown();
    }

    @Override
    public void onConfigurationChanged(android.content.res.Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (isPdf && pdfV != null) {
            ui.postDelayed(this::refreshPdfView, 300);
        }
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (loaded && tapDetector != null) tapDetector.onTouchEvent(ev);
        if (isPdf && pdf != null && scaleDetector != null) {
            scaleDetector.onTouchEvent(ev);
            if (!scaleDetector.isInProgress()) flingDetector.onTouchEvent(ev);
        }
        return super.dispatchTouchEvent(ev);
    }

    // =================================================================== arayüz

    private Button flat(String text) {
        Button b = new Button(this, null, android.R.attr.borderlessButtonStyle);
        b.setText(text);
        b.setAllCaps(false);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setTextSize(16);
        b.setPadding(Util.dp(this, 10), 0, Util.dp(this, 10), 0);
        return b;
    }

    private void buildUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        btnBack = flat("←");
        titleView = new TextView(this);
        titleView.setSingleLine(true);
        titleView.setEllipsize(TextUtils.TruncateAt.END);
        titleView.setTextSize(16);
        timerView = new TextView(this);
        timerView.setTextSize(14);
        timerView.setPadding(Util.dp(this, 6), 0, Util.dp(this, 6), 0);
        btnMenu = flat("⋮");
        int h = Util.dp(this, 48);
        topBar.addView(btnBack, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, h));
        topBar.addView(titleView, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        topBar.addView(timerView, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        topBar.addView(btnMenu, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, h));

        content = new FrameLayout(this);
        loadingView = new TextView(this);
        loadingView.setText("Yükleniyor…");
        loadingView.setGravity(Gravity.CENTER);
        loadingView.setTextSize(18);
        content.addView(loadingView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        bottomBar = new LinearLayout(this);
        bottomBar.setOrientation(LinearLayout.HORIZONTAL);
        bottomBar.setGravity(Gravity.CENTER_VERTICAL);
        btnPrev = flat("◀");
        pageView = new TextView(this);
        pageView.setGravity(Gravity.CENTER);
        pageView.setSingleLine(true);
        pageView.setTextSize(14);
        btnNext = flat("▶");
        btnMinus = flat("A−");
        btnPlus = flat("A+");
        btnPlay = flat("▶ Oku");
        bottomBar.addView(btnPrev, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, h));
        bottomBar.addView(pageView, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        bottomBar.addView(btnNext, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, h));
        bottomBar.addView(btnMinus, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, h));
        bottomBar.addView(btnPlus, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, h));
        bottomBar.addView(btnPlay, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, h));

        root.addView(topBar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(content, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        root.addView(bottomBar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(root);

        btnBack.setOnClickListener(v -> finish());
        btnMenu.setOnClickListener(this::showMenu);
        btnPrev.setOnClickListener(v -> {
            if (!loaded) return;
            stopSpeaking();
            goPrev();
        });
        btnNext.setOnClickListener(v -> {
            if (!loaded) return;
            stopSpeaking();
            goNext();
        });
        btnMinus.setOnClickListener(v -> {
            if (loaded) changeSize(false);
        });
        btnPlus.setOnClickListener(v -> {
            if (loaded) changeSize(true);
        });
        btnPlay.setOnClickListener(v -> {
            if (loaded) togglePlay();
        });
        pageView.setOnClickListener(v -> {
            if (loaded && isPdf) askPdfPage();
        });

        scaleDetector = new ScaleGestureDetector(this,
                new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                    private float factor = 1f;

                    @Override
                    public boolean onScaleBegin(ScaleGestureDetector d) {
                        factor = 1f;
                        return true;
                    }

                    @Override
                    public boolean onScale(ScaleGestureDetector d) {
                        factor *= d.getScaleFactor();
                        return true;
                    }

                    @Override
                    public void onScaleEnd(ScaleGestureDetector d) {
                        if (textMode) setReflowZoom(Math.round(prefs.textZoom() * factor));
                        else setPdfZoom(pdfZoom * factor);
                    }
                });
        flingDetector = new GestureDetector(this,
                new GestureDetector.SimpleOnGestureListener() {
                    @Override
                    public boolean onFling(MotionEvent e1, MotionEvent e2, float vx, float vy) {
                        if (e1 == null || e2 == null || (!textMode && pdfZoom > 1.05f) || !loaded) {
                            return false;
                        }
                        float dx = e2.getX() - e1.getX();
                        float dy = e2.getY() - e1.getY();
                        if (Math.abs(dx) > Util.dp(ReaderActivity.this, 80)
                                && Math.abs(dx) > Math.abs(dy) * 2) {
                            stopSpeaking();
                            if (dx < 0) goNext();
                            else goPrev();
                        }
                        return false;
                    }
                });
        tapDetector = new GestureDetector(this,
                new GestureDetector.SimpleOnGestureListener() {
                    @Override
                    public boolean onSingleTapConfirmed(MotionEvent e) {
                        int[] loc = new int[2];
                        content.getLocationOnScreen(loc);
                        float y = e.getRawY();
                        if (y >= loc[1] && y <= loc[1] + content.getHeight()) {
                            setBars(!barsVisible);
                        }
                        return false;
                    }
                });
    }

    /** Okurken üst/alt çubukları ve sistem çubuklarını gizler; dokununca geri getirir. */
    private void setBars(boolean show) {
        barsVisible = show;
        int v = show ? View.VISIBLE : View.GONE;
        topBar.setVisibility(v);
        bottomBar.setVisibility(v);
        updateSystemUi();
    }

    private void updateSystemUi() {
        int flags = 0;
        if (prefs.theme() != Prefs.DARK) {
            flags = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        }
        if (!barsVisible) {
            flags |= View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
        }
        getWindow().getDecorView().setSystemUiVisibility(flags);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && topBar != null) updateSystemUi();
    }

    private void applyChrome() {
        int t = prefs.theme();
        int bg = Prefs.bg(t);
        int fg = Prefs.fg(t);
        int bar = Prefs.bar(t);
        root.setBackgroundColor(bg);
        topBar.setBackgroundColor(bar);
        bottomBar.setBackgroundColor(bar);
        content.setBackgroundColor(bg);
        TextView[] texts = {titleView, timerView, pageView, loadingView, btnBack, btnMenu,
                btnPrev, btnNext, btnMinus, btnPlus, btnPlay};
        for (TextView v : texts) v.setTextColor(fg);
        getWindow().setStatusBarColor(bar);
        getWindow().setNavigationBarColor(bar);
        updateSystemUi();
        if (web != null) {
            web.setBackgroundColor(bg);
            injectTheme();
        }
        if (reflowV != null) {
            reflowV.setBackgroundColor(bg);
            reflowText.setTextColor(fg);
        }
        if (pdfV != null) {
            pdfV.setBackgroundColor(bg);
            pdfH.setBackgroundColor(bg);
            ColorMatrixColorFilter f = pdfFilter(t);
            pdfImg.setColorFilter(f);
        }
    }

    private ColorMatrixColorFilter pdfFilter(int t) {
        if (t == Prefs.DARK) {
            return new ColorMatrixColorFilter(new float[]{
                    -0.9f, 0, 0, 0, 235,
                    0, -0.9f, 0, 0, 235,
                    0, 0, -0.9f, 0, 235,
                    0, 0, 0, 1, 0});
        }
        if (t == Prefs.SEPIA) {
            return new ColorMatrixColorFilter(new float[]{
                    0.393f, 0.769f, 0.189f, 0, 0,
                    0.349f, 0.686f, 0.168f, 0, 0,
                    0.272f, 0.534f, 0.131f, 0, 0,
                    0, 0, 0, 1, 0});
        }
        return null;
    }

    private void injectTheme() {
        if (web == null) return;
        int t = prefs.theme();
        String bg = Util.hex(Prefs.bg(t));
        String fg = Util.hex(Prefs.fg(t));
        String link = Util.hex(Prefs.link(t));
        String css = "html,body{background:" + bg + " !important;color:" + fg + " !important;}"
                + "body{padding:12px 16px !important;line-height:1.6 !important;"
                + "max-width:100% !important;box-sizing:border-box !important;margin:0 !important;}"
                + "body *{color:" + fg + " !important;background-color:transparent !important;}"
                + "a,a *{color:" + link + " !important;}"
                + "img,svg,video{max-width:100% !important;height:auto !important;}";
        String js = "(function(){var s=document.getElementById('__et');if(!s){"
                + "s=document.createElement('style');s.id='__et';"
                + "(document.head||document.documentElement).appendChild(s);}"
                + "s.textContent='" + css + "';})();";
        web.evaluateJavascript(js, null);
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }

    // =================================================================== dosya yükleme

    private void loadBook() {
        io.execute(() -> {
            try {
                final String name = Util.displayName(this, uri);
                File dir = getCacheDir();
                File dest = new File(dir, "book_" + key);
                File[] old = dir.listFiles();
                if (old != null) {
                    for (File f : old) {
                        if (f.getName().startsWith("book_") && !f.equals(dest)) f.delete();
                    }
                }
                try (InputStream in = getContentResolver().openInputStream(uri);
                     OutputStream out = new FileOutputStream(dest)) {
                    if (in == null) throw new IOException("Dosya açılamadı");
                    byte[] buf = new byte[65536];
                    int n;
                    while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
                }
                byte[] head = new byte[5];
                int got;
                try (FileInputStream fi = new FileInputStream(dest)) {
                    got = fi.read(head);
                }
                boolean pdfFile = got >= 4 && head[0] == '%' && head[1] == 'P'
                        && head[2] == 'D' && head[3] == 'F';
                boolean zipFile = got >= 2 && head[0] == 'P' && head[1] == 'K';

                if (pdfFile) {
                    ParcelFileDescriptor fd = ParcelFileDescriptor.open(
                            dest, ParcelFileDescriptor.MODE_READ_ONLY);
                    PdfRenderer r;
                    try {
                        r = new PdfRenderer(fd);
                    } catch (Exception e) {
                        try {
                            fd.close();
                        } catch (IOException ignored) {
                        }
                        throw e;
                    }
                    final PdfRenderer renderer = r;
                    final ParcelFileDescriptor desc = fd;
                    if (renderer.getPageCount() <= 0) {
                        renderer.close();
                        desc.close();
                        throw new IOException("PDF boş görünüyor");
                    }
                    ui.post(() -> {
                        if (isDestroyed()) return;
                        pdf = renderer;
                        pfd = desc;
                        setupPdf(name);
                    });
                } else if (zipFile) {
                    final EpubBook b = EpubBook.open(dest);
                    ui.post(() -> {
                        if (isDestroyed()) {
                            try {
                                b.close();
                            } catch (IOException ignored) {
                            }
                            return;
                        }
                        setupEpub(b, name);
                    });
                } else {
                    throw new IOException("Desteklenmeyen dosya. Lütfen EPUB veya PDF seçin.");
                }
            } catch (final SecurityException se) {
                fail("Bu PDF parola korumalı veya erişim izni yok.");
            } catch (final Exception e) {
                fail("Kitap açılamadı: " + e.getMessage());
            }
        });
    }

    private void fail(final String msg) {
        ui.post(() -> {
            if (isDestroyed()) return;
            toast(msg);
            finish();
        });
    }

    private void rememberBook(String name, String type) {
        try {
            getContentResolver().takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) {
        }
        prefs.addRecent(new Prefs.Recent(uri.toString(), name, type));
    }

    // =================================================================== EPUB

    private void setupEpub(EpubBook b, String name) {
        book = b;
        isPdf = false;
        loaded = true;
        rememberBook(name, "epub");
        titleView.setText(b.title.isEmpty() ? name : b.title);
        content.removeAllViews();

        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setTextZoom(prefs.textZoom());
        web.setWebViewClient(new EpubClient());
        content.addView(web, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        applyChrome();
        setBars(false);
        Toast.makeText(this, "Menü için ekrana dokun", Toast.LENGTH_SHORT).show();

        chapter = Math.max(0, Math.min(prefs.chapter(key), b.spine.size() - 1));
        pendingFrac = prefs.frac(key);
        showChapter(chapter);
    }

    private void showChapter(int i) {
        EpubBook b = book;
        if (b == null || web == null || i < 0 || i >= b.spine.size()) return;
        chapter = i;
        prefs.saveChapter(key, i);
        updateLabel();
        web.loadUrl("https://" + HOST + "/" + Uri.encode(b.spine.get(i), "/"));
    }

    private final class EpubClient extends WebViewClient {
        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
            return serve(req.getUrl());
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
            Uri u = req.getUrl();
            EpubBook b = book;
            if (b != null && HOST.equals(u.getHost()) && u.getPath() != null) {
                String path = u.getPath();
                if (path.startsWith("/")) path = path.substring(1);
                int idx = b.spine.indexOf(path);
                if (idx == chapter) return false; // aynı bölümde dipnot / bağlantı
                if (idx >= 0) {
                    stopSpeaking();
                    pendingFrac = 0f;
                    showChapter(idx);
                }
            }
            return true; // dış bağlantılar açılmaz
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            injectTheme();
            if (pendingFrac >= 0f) {
                final float f = pendingFrac;
                pendingFrac = -1f;
                ui.postDelayed(() -> scrollToFraction(f), 150);
            }
            if (speakAfterLoad) {
                speakAfterLoad = false;
                if (speaking) {
                    ui.postDelayed(() -> {
                        if (speaking) speakEpub(true);
                    }, 500);
                }
            }
        }
    }

    private WebResourceResponse serve(Uri u) {
        EpubBook b = book;
        if (b == null || !HOST.equals(u.getHost())) return notFound();
        String path = u.getPath();
        if (path == null) return notFound();
        if (path.startsWith("/")) path = path.substring(1);
        try {
            ZipEntry e = b.zip.getEntry(path);
            if (e == null) return notFound();
            String mime = EpubBook.mimeOf(path);
            if (mime.contains("javascript")) return notFound(); // kitap içi betikler çalışmasın
            boolean text = mime.startsWith("text/") || mime.contains("xml");
            return new WebResourceResponse(mime, text ? "UTF-8" : null, b.zip.getInputStream(e));
        } catch (Exception ex) {
            return notFound();
        }
    }

    private static WebResourceResponse notFound() {
        return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found",
                new HashMap<String, String>(), new ByteArrayInputStream(new byte[0]));
    }

    private void scrollToFraction(float f) {
        if (web == null) return;
        web.evaluateJavascript("(function(){var h=document.documentElement.scrollHeight-"
                + "window.innerHeight;window.scrollTo(0,h>0?h*" + f + ":0);})();", null);
    }

    private void saveEpubPosition() {
        if (isPdf || web == null || !loaded) return;
        final String k = key;
        web.evaluateJavascript("(function(){var h=document.documentElement.scrollHeight-"
                + "window.innerHeight;return h>0?window.scrollY/h:0;})()", value -> {
            try {
                float f = Float.parseFloat(value);
                if (f >= 0f && f <= 1f) prefs.saveFrac(k, f);
            } catch (Exception ignored) {
            }
        });
    }

    private void showToc() {
        EpubBook b = book;
        if (b == null) return;
        final List<EpubBook.TocItem> items = b.toc;
        String[] names = new String[items.size()];
        for (int i = 0; i < names.length; i++) names[i] = items.get(i).title;
        new AlertDialog.Builder(this)
                .setTitle("İçindekiler")
                .setItems(names, (d, which) -> {
                    stopSpeaking();
                    pendingFrac = 0f;
                    showChapter(items.get(which).spineIndex);
                })
                .show();
    }

    // =================================================================== PDF

    private void setupPdf(String name) {
        isPdf = true;
        loaded = true;
        pageCount = pdf.getPageCount();
        rememberBook(name, "pdf");
        titleView.setText(name);
        content.removeAllViews();

        pdfV = new ScrollView(this);
        pdfH = new HorizontalScrollView(this);
        pdfImg = new ImageView(this);
        pdfH.addView(pdfImg, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        pdfV.addView(pdfH, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        content.addView(pdfV, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        reflowV = new ScrollView(this);
        reflowText = new TextView(this);
        int rp = Util.dp(this, 16);
        reflowText.setPadding(rp, rp, rp, rp * 2);
        reflowText.setLineSpacing(0f, 1.4f);
        reflowV.addView(reflowText, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        content.addView(reflowV, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        textMode = prefs.pdfTextMode();
        applyModeVisibility();

        applyChrome();
        setBars(false);
        Toast.makeText(this, "Menü için ekrana dokun", Toast.LENGTH_SHORT).show();

        pageIndex = Math.max(0, Math.min(prefs.page(key), pageCount - 1));
        updateLabel();
        if (textMode) loadReflow(pageIndex);
        else pdfV.post(this::renderPdfPage);
    }

    private void applyModeVisibility() {
        if (pdfV == null || reflowV == null) return;
        pdfV.setVisibility(textMode ? View.GONE : View.VISIBLE);
        reflowV.setVisibility(textMode ? View.VISIBLE : View.GONE);
        reflowText.setTextSize(18f * prefs.textZoom() / 100f);
    }

    private void setTextMode(boolean on) {
        textMode = on;
        prefs.setPdfTextMode(on);
        applyModeVisibility();
        refreshPdfView();
    }

    private void refreshPdfView() {
        if (textMode) loadReflow(pageIndex);
        else renderPdfPage();
    }

    /** Sayfayı OCR ile metne çevirip ekrana sığacak şekilde gösterir. */
    private void loadReflow(final int p) {
        if (reflowText == null) return;
        reflowText.setText("Sayfa metne çevriliyor…");
        ocrPage(p, text -> {
            if (!textMode || p != pageIndex || reflowText == null) return;
            if (text == null || text.trim().isEmpty()) {
                reflowText.setText("(Bu sayfada okunabilir metin bulunamadı. "
                        + "Görüntü moduna dönmek için menüden metin modunu kapat.)");
            } else {
                reflowText.setText(text);
            }
            reflowV.scrollTo(0, 0);
        });
        if (p + 1 < pageCount) ocrPage(p + 1, t -> { });
    }

    private void setReflowZoom(int z) {
        int nz = Math.max(50, Math.min(300, z));
        if (nz == prefs.textZoom()) return;
        prefs.setTextZoom(nz);
        if (reflowText != null) reflowText.setTextSize(18f * nz / 100f);
        toast("Yazı boyutu: %" + nz);
    }

    /** Yalnızca io iş parçacığında çağrılır. */
    private Bitmap renderFull(int p, int targetW) {
        PdfRenderer r = pdf;
        if (r == null || p < 0 || p >= r.getPageCount()) return null;
        PdfRenderer.Page page = r.openPage(p);
        try {
            float ratio = (float) page.getHeight() / (float) page.getWidth();
            int w = Math.max(200, targetW);
            int h = Math.max(200, Math.round(w * ratio));
            long px = (long) w * (long) h;
            if (px > 12_000_000L) {
                double s = Math.sqrt(12_000_000d / (double) px);
                w = Math.max(200, (int) (w * s));
                h = Math.max(200, (int) (h * s));
            }
            Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            b.eraseColor(Color.WHITE);
            page.render(b, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
            b.setDensity(Bitmap.DENSITY_NONE);
            return b;
        } finally {
            page.close();
        }
    }

    private void renderPdfPage() {
        if (!isPdf || pdfV == null || pdf == null || textMode) return;
        final int p = pageIndex;
        final int token = ++renderToken;
        final int vw = Math.max(1, content.getWidth());
        final boolean crop = prefs.pdfCrop();
        final int target = Math.round(vw * pdfZoom);
        try {
            io.execute(() -> {
                Bitmap b = null;
                try {
                    b = crop ? renderCropped(p, target) : renderFull(p, target);
                } catch (Throwable ignored) {
                }
                final Bitmap bmp = b;
                ui.post(() -> {
                    if (bmp == null || token != renderToken || pdfImg == null) return;
                    pdfImg.setImageBitmap(bmp);
                });
            });
        } catch (Exception ignored) {
            // activity kapanmış olabilir
        }
    }

    private void showPdfPage(int p, boolean resetScroll) {
        if (p < 0 || p >= pageCount) return;
        pageIndex = p;
        prefs.savePage(key, p);
        updateLabel();
        if (resetScroll && pdfV != null) {
            pdfV.scrollTo(0, 0);
            pdfH.scrollTo(0, 0);
        }
        if (resetScroll && reflowV != null) reflowV.scrollTo(0, 0);
        refreshPdfView();
    }

    private void setPdfZoom(float z) {
        if (textMode) return;
        float nz = Math.max(1f, Math.min(5f, z));
        if (Math.abs(nz - pdfZoom) < 0.01f) return;
        pdfZoom = nz;
        prefs.setPdfZoom(nz);
        renderPdfPage();
        toast(String.format(Locale.US, "Yakınlaştırma: %d%%", Math.round(nz * 100)));
    }

    private void askPdfPage() {
        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER);
        input.setHint("1 - " + pageCount);
        new AlertDialog.Builder(this)
                .setTitle("Sayfaya git")
                .setView(input)
                .setPositiveButton("Git", (d, w) -> {
                    try {
                        int p = Integer.parseInt(input.getText().toString().trim());
                        stopSpeaking();
                        showPdfPage(Math.max(1, Math.min(pageCount, p)) - 1, true);
                    } catch (NumberFormatException ignored) {
                    }
                })
                .setNegativeButton("Vazgeç", null)
                .show();
    }

    // ---- sayfa görüntüsünü kenar boşluklarından kırpma (yalnızca io iş parçacığı) ----

    private Bitmap renderCropped(int p, int targetW) {
        PdfRenderer r = pdf;
        if (r == null || p < 0 || p >= r.getPageCount()) return null;
        float[] box = effectiveBox(p);
        PdfRenderer.Page page = r.openPage(p);
        try {
            float pw = page.getWidth();
            float ph = page.getHeight();
            float cw = (box[2] - box[0]) * pw;
            float ch = (box[3] - box[1]) * ph;
            int w = Math.max(200, targetW);
            int h = Math.max(200, Math.round(w * ch / cw));
            long px = (long) w * (long) h;
            if (px > 12_000_000L) {
                double s = Math.sqrt(12_000_000d / (double) px);
                w = Math.max(200, (int) (w * s));
                h = Math.max(200, (int) (h * s));
            }
            float sx = w / cw;
            float sy = h / ch;
            Matrix m = new Matrix();
            m.setScale(sx, sy);
            m.postTranslate(-box[0] * pw * sx, -box[1] * ph * sy);
            Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            b.eraseColor(Color.WHITE);
            page.render(b, null, m, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
            b.setDensity(Bitmap.DENSITY_NONE);
            return b;
        } finally {
            page.close();
        }
    }

    /** {sol, üst, sağ, alt} oranları: sol/sağ tüm kitap için ortak, üst/alt sayfaya özel. */
    private float[] effectiveBox(int p) {
        float[] hc = horizontalCrop();
        float[] pb = pageBox(p);
        float t = 0f;
        float b = 1f;
        if (pb != null) {
            t = pb[1];
            b = pb[3];
        }
        float l = hc[0];
        float r = hc[1];
        if (r - l < 0.5f) {
            l = 0f;
            r = 1f;
        }
        if (b - t < 0.15f) {
            t = 0f;
            b = 1f;
        }
        return new float[]{l, t, r, b};
    }

    private float[] horizontalCrop() {
        if (hCrop != null) return hCrop;
        List<Float> ls = new ArrayList<>();
        List<Float> rs = new ArrayList<>();
        int n = Math.min(15, pageCount);
        for (int i = 0; i < n; i++) {
            int p = (int) ((long) i * pageCount / n);
            float[] bx = pageBox(p);
            if (bx != null) {
                ls.add(bx[0]);
                rs.add(bx[2]);
            }
        }
        float l = 0f;
        float r = 1f;
        if (ls.size() >= 3) {
            Collections.sort(ls);
            Collections.sort(rs);
            l = ls.get((int) (ls.size() * 0.1f));
            r = rs.get(Math.max(0, (int) Math.ceil(rs.size() * 0.9f) - 1));
        }
        hCrop = new float[]{l, r};
        return hCrop;
    }

    /** Sayfanın koyu (yazı) piksellerinin sınırlayıcı kutusu; bulunamazsa null. */
    private float[] pageBox(int p) {
        float[] cached = boxCache.get(p);
        if (cached != null) return cached.length == 4 ? cached : null;
        float[] result = new float[0];
        PdfRenderer.Page page = pdf.openPage(p);
        try {
            int tw = 400;
            int th = Math.max(1, Math.round(tw * (float) page.getHeight() / (float) page.getWidth()));
            Bitmap bmp = Bitmap.createBitmap(tw, th, Bitmap.Config.ARGB_8888);
            bmp.eraseColor(Color.WHITE);
            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
            int[] px = new int[tw * th];
            bmp.getPixels(px, 0, tw, 0, 0, tw, th);
            bmp.recycle();
            int[] rows = new int[th];
            int[] cols = new int[tw];
            for (int y = 0; y < th; y++) {
                for (int x = 0; x < tw; x++) {
                    int c = px[y * tw + x];
                    int lum = (Color.red(c) * 30 + Color.green(c) * 59 + Color.blue(c) * 11) / 100;
                    if (lum < 150) {
                        rows[y]++;
                        cols[x]++;
                    }
                }
            }
            int y0 = firstAtLeast(rows, 2, false);
            int y1 = firstAtLeast(rows, 2, true);
            int x0 = firstAtLeast(cols, 2, false);
            int x1 = firstAtLeast(cols, 2, true);
            if (y0 >= 0 && y1 > y0 && x0 >= 0 && x1 > x0) {
                result = new float[]{
                        Math.max(0f, x0 / (float) tw - 0.02f),
                        Math.max(0f, y0 / (float) th - 0.01f),
                        Math.min(1f, (x1 + 1) / (float) tw + 0.02f),
                        Math.min(1f, (y1 + 1) / (float) th + 0.01f)};
            }
        } finally {
            page.close();
        }
        boxCache.put(p, result);
        return result.length == 4 ? result : null;
    }

    private static int firstAtLeast(int[] a, int min, boolean fromEnd) {
        if (fromEnd) {
            for (int i = a.length - 1; i >= 0; i--) if (a[i] >= min) return i;
        } else {
            for (int i = 0; i < a.length; i++) if (a[i] >= min) return i;
        }
        return -1;
    }

    private void initOcr() {
        try {
            recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        } catch (Throwable t) {
            recognizer = null;
        }
    }

    /** Sayfayı görüntüye çevirip cihaz üzerinde OCR ile metne dönüştürür (taranmış PDF'ler için). */
    private void ocrPage(final int p, final Consumer<String> cb) {
        String cached = ocrCache.get(p);
        if (cached != null) {
            cb.accept(cached);
            return;
        }
        List<Consumer<String>> w = ocrWaiters.get(p);
        if (w != null) {
            w.add(cb); // aynı sayfa zaten çevriliyor, sonucu bekle
            return;
        }
        w = new ArrayList<>();
        w.add(cb);
        ocrWaiters.put(p, w);
        ocrRun(p, text -> {
            List<Consumer<String>> ws = ocrWaiters.remove(p);
            if (ws != null) {
                for (Consumer<String> c : ws) c.accept(text);
            }
        });
    }

    /** OCR sonucundaki blokları paragraf yapar: satır sonlarını ve tireleri birleştirir. */
    private static String joinBlocks(Text result) {
        StringBuilder sb = new StringBuilder();
        for (Text.TextBlock b : result.getTextBlocks()) {
            String s = b.getText().replaceAll("-\\s*\\n\\s*", "")
                    .replaceAll("\\s*\\n\\s*", " ").trim();
            if (s.isEmpty()) continue;
            if (sb.length() > 0) sb.append("\n\n");
            sb.append(s);
        }
        return sb.length() > 0 ? sb.toString() : result.getText();
    }

    private void ocrRun(final int p, final Consumer<String> cb) {
        String cached = ocrCache.get(p);
        if (cached != null) {
            cb.accept(cached);
            return;
        }
        final TextRecognizer rec = recognizer;
        if (rec == null) {
            cb.accept("");
            return;
        }
        try {
            io.execute(() -> {
                Bitmap b = null;
                try {
                    b = renderFull(p, 1800);
                } catch (Throwable ignored) {
                }
                final Bitmap bmp = b;
                ui.post(() -> {
                    if (bmp == null || isDestroyed()) {
                        cb.accept("");
                        return;
                    }
                    try {
                        rec.process(InputImage.fromBitmap(bmp, 0))
                                .addOnSuccessListener(result -> {
                                    String text = joinBlocks(result);
                                    ocrCache.put(p, text);
                                    bmp.recycle();
                                    cb.accept(text);
                                })
                                .addOnFailureListener(err -> {
                                    bmp.recycle();
                                    cb.accept("");
                                });
                    } catch (Throwable t) {
                        cb.accept("");
                    }
                });
            });
        } catch (Exception e) {
            cb.accept("");
        }
    }

    // =================================================================== gezinme / boyut

    private void updateLabel() {
        if (isPdf) {
            pageView.setText("Sayfa " + (pageIndex + 1) + " / " + pageCount);
        } else if (book != null) {
            pageView.setText("Bölüm " + (chapter + 1) + " / " + book.spine.size());
        }
    }

    private void goNext() {
        if (isPdf) {
            if (pageIndex + 1 < pageCount) showPdfPage(pageIndex + 1, true);
        } else if (book != null && chapter + 1 < book.spine.size()) {
            pendingFrac = 0f;
            showChapter(chapter + 1);
        }
    }

    private void goPrev() {
        if (isPdf) {
            if (pageIndex > 0) showPdfPage(pageIndex - 1, true);
        } else if (chapter > 0) {
            pendingFrac = 0f;
            showChapter(chapter - 1);
        }
    }

    private void changeSize(boolean bigger) {
        if (isPdf && textMode) {
            setReflowZoom(prefs.textZoom() + (bigger ? 10 : -10));
        } else if (isPdf) {
            setPdfZoom(bigger ? pdfZoom * 1.25f : pdfZoom / 1.25f);
        } else if (web != null) {
            int z = prefs.textZoom() + (bigger ? 10 : -10);
            z = Math.max(50, Math.min(300, z));
            prefs.setTextZoom(z);
            web.getSettings().setTextZoom(z);
            toast("Yazı boyutu: %" + z);
        }
    }

    // =================================================================== menü

    private void showMenu(View anchor) {
        PopupMenu m = new PopupMenu(this, anchor);
        if (isPdf) m.getMenu().add(0, M_TOC, 0, "Sayfaya git");
        else m.getMenu().add(0, M_TOC, 0, "İçindekiler");
        m.getMenu().add(0, M_THEME, 1, "Tema (açık / karanlık / sepya)");
        m.getMenu().add(0, M_TIMER, 2, "Uyku zamanlayıcısı");
        m.getMenu().add(0, M_RATE, 3, "Okuma hızı");
        m.getMenu().add(0, M_LANG, 4, "Okuma dili");
        m.getMenu().add(0, M_KEEP, 5,
                prefs.keepOn() ? "Ekranı açık tutma: AÇIK" : "Ekranı açık tutma: KAPALI");
        if (isPdf && !textMode) {
            m.getMenu().add(0, M_CROP, 7, prefs.pdfCrop()
                    ? "Kenar boşluklarını kırp: AÇIK" : "Kenar boşluklarını kırp: KAPALI");
        }
        if (isPdf) {
            m.getMenu().add(0, M_TEXT, 6, textMode
                    ? "Metin modu (yazı ekrana sığar): AÇIK"
                    : "Metin modu (yazı ekrana sığar): KAPALI");
        }
        m.setOnMenuItemClickListener(item -> {
            switch (item.getItemId()) {
                case M_TOC:
                    if (!loaded) return true;
                    if (isPdf) askPdfPage();
                    else showToc();
                    return true;
                case M_THEME:
                    chooseTheme();
                    return true;
                case M_TIMER:
                    chooseTimer();
                    return true;
                case M_RATE:
                    chooseRate();
                    return true;
                case M_LANG:
                    chooseLang();
                    return true;
                case M_TEXT:
                    if (loaded && isPdf) {
                        setTextMode(!textMode);
                        if (textMode) toast("Metin modu açıldı. Sayfa OCR ile metne çevriliyor.");
                    }
                    return true;
                case M_KEEP:
                    boolean now = !prefs.keepOn();
                    prefs.setKeepOn(now);
                    if (now) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                    else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                    toast(now ? "Ekran açık kalacak" : "Ekran normal şekilde kapanacak");
                    return true;
                case M_CROP:
                    prefs.setPdfCrop(!prefs.pdfCrop());
                    renderPdfPage();
                    return true;
                default:
                    return false;
            }
        });
        m.show();
    }

    private void chooseTheme() {
        new AlertDialog.Builder(this)
                .setTitle("Tema")
                .setItems(new String[]{"Açık", "Karanlık", "Sepya"}, (d, which) -> {
                    prefs.setTheme(which);
                    applyChrome();
                })
                .show();
    }

    private void chooseTimer() {
        final int[] mins = {0, 15, 30, 45, 60, 90};
        String[] names = {"Kapalı", "15 dakika", "30 dakika", "45 dakika", "60 dakika",
                "90 dakika", "Özel süre (dakika)…"};
        new AlertDialog.Builder(this)
                .setTitle("Uyku zamanlayıcısı")
                .setItems(names, (d, which) -> {
                    if (which < mins.length) setSleepTimer(mins[which]);
                    else askCustomTimer();
                })
                .show();
    }

    private void askCustomTimer() {
        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER);
        input.setHint("Dakika");
        new AlertDialog.Builder(this)
                .setTitle("Kaç dakika sonra kapansın?")
                .setView(input)
                .setPositiveButton("Başlat", (d, w) -> {
                    try {
                        int m = Integer.parseInt(input.getText().toString().trim());
                        if (m > 0 && m <= 1440) setSleepTimer(m);
                    } catch (NumberFormatException ignored) {
                    }
                })
                .setNegativeButton("Vazgeç", null)
                .show();
    }

    private void setSleepTimer(int minutes) {
        ui.removeCallbacks(tick);
        if (minutes <= 0) {
            timerEnd = 0;
            timerView.setText("");
            toast("Uyku zamanlayıcısı kapatıldı");
        } else {
            timerEnd = SystemClock.elapsedRealtime() + minutes * 60_000L;
            ui.post(tick);
            toast(minutes + " dakika sonra uygulama kapanacak");
        }
    }

    private void onTimerExpired() {
        timerEnd = 0;
        stopSpeaking();
        saveEpubPosition();
        toast("Uyku zamanlayıcısı doldu, uygulama kapanıyor");
        finishAffinity();
    }

    private void chooseRate() {
        final float[] rates = {0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f};
        String[] names = {"0.5x (yavaş)", "0.75x", "1x (normal)", "1.25x", "1.5x", "2x (hızlı)"};
        new AlertDialog.Builder(this)
                .setTitle("Okuma hızı")
                .setItems(names, (d, which) -> {
                    prefs.setRate(rates[which]);
                    applyTtsConfig();
                    if (speaking) speakFrom(curIdx);
                })
                .show();
    }

    private void chooseLang() {
        final String[] codes = {"tr", "en", "sys"};
        String[] names = {"Türkçe", "English", "Telefonun dili"};
        new AlertDialog.Builder(this)
                .setTitle("Okuma dili")
                .setItems(names, (d, which) -> {
                    prefs.setLang(codes[which]);
                    applyTtsConfig();
                    if (speaking) speakFrom(curIdx);
                })
                .show();
    }

    // =================================================================== sesli okuma

    private void initTts() {
        try {
            tts = new TextToSpeech(getApplicationContext(), status -> {
                if (status == TextToSpeech.SUCCESS && tts != null) {
                    ttsReady = true;
                    tts.setOnUtteranceProgressListener(new Progress());
                    applyTtsConfig();
                } else {
                    ttsReady = false;
                }
            });
        } catch (Exception e) {
            tts = null;
        }
    }

    private void applyTtsConfig() {
        if (tts == null || !ttsReady) return;
        String l = prefs.lang();
        Locale loc;
        if ("tr".equals(l)) loc = new Locale("tr", "TR");
        else if ("en".equals(l)) loc = Locale.US;
        else loc = Locale.getDefault();
        int r = tts.setLanguage(loc);
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            toast("Bu dil için ses verisi yok. Telefon Ayarları > Metin okuma bölümünden "
                    + "ilgili dili indirin.");
        }
        tts.setSpeechRate(prefs.rate());
    }

    private final class Progress extends UtteranceProgressListener {
        @Override
        public void onStart(String id) {
            ui.post(() -> onChunkStart(id));
        }

        @Override
        public void onDone(String id) {
            ui.post(() -> onChunkDone(id));
        }

        @Override
        public void onError(String id) {
            ui.post(() -> onChunkDone(id));
        }
    }

    /** "s<oturum>_<parça>" biçimindeki kimliği çözer; eski oturumsa -1 döner. */
    private int parseChunk(String id) {
        try {
            String[] a = id.substring(1).split("_");
            if (Integer.parseInt(a[0]) != session) return -1;
            return Integer.parseInt(a[1]);
        } catch (Exception e) {
            return -1;
        }
    }

    private void onChunkStart(String id) {
        int idx = parseChunk(id);
        if (idx < 0 || !speaking) return;
        curIdx = idx;
        if (!isPdf && web != null && totalLen > 0 && idx < cum.length) {
            double f = baseFrac + (1.0 - baseFrac) * ((double) cum[idx] / (double) totalLen);
            f = Math.max(0.0, Math.min(1.0, f));
            scrollToFraction((float) f);
        }
    }

    private void onChunkDone(String id) {
        int idx = parseChunk(id);
        if (idx < 0 || !speaking) return;
        if (idx >= chunks.size() - 1) {
            Runnable r = onSpeechEnd;
            if (r != null) r.run();
        }
    }

    private static List<String> splitText(String text) {
        List<String> out = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        for (String raw : text.split("(?<=[.!?…:;])\\s+|\\n+")) {
            String s = raw.trim();
            if (s.isEmpty()) continue;
            while (s.length() > MAX_CHUNK) {
                int cut = s.lastIndexOf(' ', MAX_CHUNK);
                if (cut <= 0) cut = MAX_CHUNK;
                if (cur.length() > 0) {
                    out.add(cur.toString());
                    cur.setLength(0);
                }
                out.add(s.substring(0, cut).trim());
                s = s.substring(cut).trim();
            }
            if (s.isEmpty()) continue;
            if (cur.length() + s.length() + 1 > MAX_CHUNK && cur.length() > 0) {
                out.add(cur.toString());
                cur.setLength(0);
            }
            if (cur.length() > 0) cur.append(' ');
            cur.append(s);
        }
        if (cur.length() > 0) out.add(cur.toString());
        return out;
    }

    private void beginSpeech(String text, double base, Runnable end) {
        chunks = splitText(text);
        if (chunks.isEmpty()) {
            if (end != null) end.run();
            return;
        }
        cum = new int[chunks.size()];
        int sum = 0;
        for (int i = 0; i < chunks.size(); i++) {
            cum[i] = sum;
            sum += chunks.get(i).length();
        }
        totalLen = sum;
        baseFrac = base;
        onSpeechEnd = end;
        speakFrom(0);
    }

    private void speakFrom(int idx) {
        if (tts == null || !ttsReady || chunks.isEmpty()) return;
        if (idx < 0 || idx >= chunks.size()) idx = 0;
        session++;
        curIdx = idx;
        tts.stop();
        for (int i = idx; i < chunks.size(); i++) {
            tts.speak(chunks.get(i),
                    i == idx ? TextToSpeech.QUEUE_FLUSH : TextToSpeech.QUEUE_ADD,
                    null, "s" + session + "_" + i);
        }
    }

    private void togglePlay() {
        if (speaking) {
            stopSpeaking();
            return;
        }
        if (!ttsReady) {
            toast("Ses motoru hazır değil. Telefonda bir metin okuma (TTS) motoru kurulu olmalı.");
            return;
        }
        speaking = true;
        startKeepAlive();
        setPlayLabel();
        if (isPdf) {
            toast("Sayfa metne çevriliyor (OCR), birkaç saniye sürebilir…");
            speakPdfPage();
        } else {
            speakEpub(false);
        }
    }

    private void stopSpeaking() {
        boolean was = speaking;
        speaking = false;
        speakAfterLoad = false;
        session++;
        if (tts != null && was) {
            try {
                tts.stop();
            } catch (Exception ignored) {
            }
        }
        releaseKeepAlive();
        setPlayLabel();
    }

    private void setPlayLabel() {
        btnPlay.setText(speaking ? "⏸ Dur" : "▶ Oku");
    }

    private void startKeepAlive() {
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (wakeLock == null && pm != null) {
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ekitap:tts");
            }
            if (wakeLock != null && !wakeLock.isHeld()) wakeLock.acquire(6 * 60 * 60 * 1000L);
        } catch (Exception ignored) {
        }
        try {
            startForegroundService(new Intent(this, KeepAliveService.class));
        } catch (Exception ignored) {
        }
    }

    private void releaseKeepAlive() {
        try {
            if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        } catch (Exception ignored) {
        }
        try {
            stopService(new Intent(this, KeepAliveService.class));
        } catch (Exception ignored) {
        }
    }

    // ---- EPUB sesli okuma ----

    private void speakEpub(final boolean fromStart) {
        if (web == null) return;
        web.evaluateJavascript(
                "(function(){var h=document.documentElement.scrollHeight-window.innerHeight;"
                        + "return JSON.stringify({f:(h>0?window.scrollY/h:0),"
                        + "t:(document.body?document.body.innerText:'')});})()",
                value -> {
                    if (!speaking) return;
                    try {
                        Object o = new JSONTokener(value).nextValue();
                        if (!(o instanceof String)) {
                            epubChapterDone();
                            return;
                        }
                        JSONObject j = new JSONObject((String) o);
                        String text = j.optString("t", "");
                        double f = fromStart ? 0.0 : j.optDouble("f", 0.0);
                        if (Double.isNaN(f) || f < 0) f = 0.0;
                        if (f > 1) f = 1.0;
                        int start = 0;
                        if (!text.isEmpty()) {
                            start = (int) (f * text.length());
                            start = Math.min(start, text.length() - 1);
                            while (start > 0 && !Character.isWhitespace(text.charAt(start))) {
                                start--;
                            }
                        }
                        String part = text.substring(start);
                        if (part.trim().isEmpty()) {
                            epubChapterDone();
                            return;
                        }
                        beginSpeech(part, f, this::epubChapterDone);
                    } catch (Exception e) {
                        stopSpeaking();
                        toast("Metin okunamadı");
                    }
                });
    }

    private void epubChapterDone() {
        if (!speaking) return;
        EpubBook b = book;
        if (b != null && chapter + 1 < b.spine.size()) {
            speakAfterLoad = true;
            pendingFrac = 0f;
            showChapter(chapter + 1);
        } else {
            stopSpeaking();
            toast("Kitap bitti");
        }
    }

    // ---- PDF sesli okuma (OCR ile) ----

    private void speakPdfPage() {
        if (!speaking) return;
        final int p = pageIndex;
        ocrPage(p, text -> {
            if (!speaking || p != pageIndex) return;
            if (text == null || text.trim().isEmpty()) {
                pdfPageDone();
                return;
            }
            beginSpeech(text, 0.0, this::pdfPageDone);
            if (p + 1 < pageCount) ocrPage(p + 1, t -> { });
        });
    }

    private void pdfPageDone() {
        if (!speaking) return;
        if (pageIndex + 1 < pageCount) {
            showPdfPage(pageIndex + 1, true);
            speakPdfPage();
        } else {
            stopSpeaking();
            toast("Belge bitti");
        }
    }
}
