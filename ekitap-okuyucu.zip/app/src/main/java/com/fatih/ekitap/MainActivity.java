package com.fatih.ekitap;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/** Ana ekran: kitap aç + son açılanlar. */
public class MainActivity extends Activity {
    private static final int REQ_OPEN = 1;
    private static final int REQ_NOTIF = 2;

    private Prefs prefs;
    private LinearLayout root;
    private TextView heading;
    private TextView empty;
    private Button openBtn;
    private Button themeBtn;
    private ListView list;
    private List<Prefs.Recent> recents = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = new Prefs(this);
        buildUi();

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS},
                    REQ_NOTIF);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        applyTheme();
        refreshList();
    }

    private void buildUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = Util.dp(this, 16);
        root.setPadding(pad, pad, pad, pad);

        heading = new TextView(this);
        heading.setText("Ekitap Okuyucu");
        heading.setTextSize(26);
        heading.setTypeface(Typeface.DEFAULT_BOLD);
        heading.setPadding(0, Util.dp(this, 8), 0, Util.dp(this, 12));
        root.addView(heading, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        openBtn = new Button(this);
        openBtn.setAllCaps(false);
        openBtn.setText("Kitap aç (EPUB / PDF)");
        openBtn.setOnClickListener(v -> pickFile());
        root.addView(openBtn, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        themeBtn = new Button(this);
        themeBtn.setAllCaps(false);
        themeBtn.setOnClickListener(v -> chooseTheme());
        root.addView(themeBtn, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView sub = new TextView(this);
        sub.setText("Son açılanlar");
        sub.setTextSize(14);
        sub.setPadding(0, Util.dp(this, 16), 0, Util.dp(this, 4));
        sub.setTag("sub");
        root.addView(sub, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        empty = new TextView(this);
        empty.setText("Henüz kitap yok. Yukarıdaki düğmeyle bir EPUB veya PDF seç.");
        empty.setGravity(Gravity.CENTER);
        empty.setPadding(0, Util.dp(this, 24), 0, 0);
        root.addView(empty, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        list = new ListView(this);
        list.setDividerHeight(0);
        list.setOnItemClickListener((parent, view, position, id) -> {
            if (position >= 0 && position < recents.size()) {
                openBook(Uri.parse(recents.get(position).uri));
            }
        });
        list.setOnItemLongClickListener((parent, view, position, id) -> {
            if (position < 0 || position >= recents.size()) return true;
            final Prefs.Recent r = recents.get(position);
            new AlertDialog.Builder(this)
                    .setTitle("Listeden kaldır?")
                    .setMessage(r.name)
                    .setPositiveButton("Kaldır", (d, w) -> {
                        prefs.removeRecent(r.uri);
                        refreshList();
                    })
                    .setNegativeButton("Vazgeç", null)
                    .show();
            return true;
        });
        root.addView(list, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);
    }

    private void applyTheme() {
        int t = prefs.theme();
        int bg = Prefs.bg(t);
        int fg = Prefs.fg(t);
        int bar = Prefs.bar(t);
        root.setBackgroundColor(bg);
        heading.setTextColor(fg);
        empty.setTextColor(fg);
        View sub = root.findViewWithTag("sub");
        if (sub instanceof TextView) ((TextView) sub).setTextColor(fg);
        openBtn.setBackgroundColor(bar);
        openBtn.setTextColor(fg);
        themeBtn.setBackgroundColor(bar);
        themeBtn.setTextColor(fg);
        themeBtn.setText("Tema: " + themeName(t));
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        int flags = 0;
        if (t != Prefs.DARK) {
            flags = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        }
        getWindow().getDecorView().setSystemUiVisibility(flags);
    }

    private static String themeName(int t) {
        switch (t) {
            case Prefs.LIGHT: return "Açık";
            case Prefs.SEPIA: return "Sepya";
            default: return "Karanlık";
        }
    }

    private void chooseTheme() {
        new AlertDialog.Builder(this)
                .setTitle("Tema")
                .setItems(new String[]{"Açık", "Karanlık", "Sepya"}, (d, which) -> {
                    prefs.setTheme(which);
                    applyTheme();
                    refreshList();
                })
                .show();
    }

    private void refreshList() {
        recents = prefs.recents();
        final int fg = Prefs.fg(prefs.theme());
        List<String> names = new ArrayList<>();
        for (Prefs.Recent r : recents) {
            String tag = "pdf".equals(r.type) ? "PDF" : "EPUB";
            names.add("[" + tag + "]  " + r.name);
        }
        list.setAdapter(new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, names) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View v = super.getView(position, convertView, parent);
                if (v instanceof TextView) {
                    ((TextView) v).setTextColor(fg);
                    ((TextView) v).setTextSize(16);
                }
                return v;
            }
        });
        empty.setVisibility(recents.isEmpty() ? View.VISIBLE : View.GONE);
        list.setVisibility(recents.isEmpty() ? View.GONE : View.VISIBLE);
    }

    private void pickFile() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try {
            startActivityForResult(i, REQ_OPEN);
        } catch (Exception e) {
            Toast.makeText(this, "Dosya seçici açılamadı", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_OPEN && resultCode == RESULT_OK && data != null
                && data.getData() != null) {
            Uri uri = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(
                        uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) {
            }
            openBook(uri);
        }
    }

    private void openBook(Uri uri) {
        Intent i = new Intent(this, ReaderActivity.class);
        i.setData(uri);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(i);
    }
}
