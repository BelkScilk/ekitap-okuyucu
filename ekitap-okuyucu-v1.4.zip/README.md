# Ekitap Okuyucu (Android)

EPUB ve PDF okuyan, sesli okuyabilen, uyku zamanlayıcılı basit bir Android e-kitap uygulaması.

## Özellikler

- **EPUB ve PDF** okuma (taranmış / tarayıcıdan çıkmış PDF'ler dahil)
- **Yazı boyutu**: `A−` / `A+` düğmeleri (EPUB'da yazı boyutu, PDF'de yakınlaştırma; PDF'de iki parmakla da büyütülür)
- **Temalar**: Açık, Karanlık, Sepya (PDF sayfalarına da uygulanır)
- **Sesli okuma**: `▶ Oku` düğmesi. Hız ve dil (Türkçe / English / telefon dili) menüden seçilir
- **Uyku zamanlayıcısı**: 15 / 30 / 45 / 60 / 90 dk veya özel süre. Süre dolunca okuma durur ve uygulama kapanır
- Kitaplık: son okunan kitap en üstte büyük kartla, kategoriler, raf / kapak ızgarası görünümü
- Okurken çubuklar gizlenir; ortaya dokun = menü, sol/sağ kenara dokun = sayfa çevir
- Sesli okurken okunan kelime renkli, yuvarlak köşeli bir zeminle vurgulanır ve sayfa kelimeyi takip eder (EPUB ve PDF metin modu)
- **Kalan süre tahmini**: alt çubukta “~X dk” / “~X sa Y dk” olarak gösterilir (ilerleme + ortalama okuma hızı; sesli okumada daha isabetli)
- PDF’de sesli okuma başlatılırken metin modu kapalıysa otomatik açılır (böylece okunan yazı takip edilir / vurgulanır)
- Yer imleri (menü > Yer imi ekle / Yer imleri; silmek için listede uzun bas)
- Sesli okuma kontrolleri: bildirimden Önceki / Duraklat / Sonraki / Durdur, kulaklık-bluetooth medya tuşları; arama gelince veya kulaklık çıkınca otomatik duraklar
- PDF: kenar boşluğu kırpma ve "Metin modu" (OCR ile yazı ekrana sığar)
- Kaldığın yeri hatırlar (bölüm/sayfa ve konum)
- İçindekiler (EPUB), sayfaya git (PDF, sayfa yazısına dokun)
- Ekran kapalıyken de sesli okuma ve zamanlayıcı çalışır

## APK'yı alma (bilgisayarda hiçbir şey kurmadan)

1. GitHub'da yeni bir depo (repository) oluştur.
2. Bu klasörün **içindeki her şeyi** depoya yükle (`.github` klasörü dahil! Gizli klasör olduğu için dosya yöneticisinde "gizli dosyaları göster" açık olmalı). Git kullanıyorsan:
   ```
   git init
   git add .
   git commit -m "ilk sürüm"
   git branch -M main
   git remote add origin https://github.com/KULLANICI/DEPO.git
   git push -u origin main
   ```
3. GitHub'da depoda **Actions** sekmesine gir. "APK Derle" otomatik çalışır (2-5 dk). Çalışmazsa "APK Derle" > **Run workflow**.
4. Bitince çalışmanın sayfasının altındaki **Artifacts** bölümünden `ekitap-okuyucu-apk` dosyasını indir, zip'ten çıkan `ekitap-okuyucu.apk` dosyasını telefona at.
5. Telefonda APK'ya dokun, "bilinmeyen kaynaklardan yüklemeye izin ver" de, kur.

İstersen `v1.0` gibi bir etiket (tag) atarsan APK **Releases** bölümüne de otomatik eklenir; telefondan doğrudan oradan indirebilirsin.

## Notlar

- Sesli okuma telefondaki metin okuma (TTS) motorunu kullanır (Google TTS vb.). Türkçe ses yoksa: Ayarlar > Metin okuma > Google > Türkçe sesi indir.
- PDF'lerde sesli okuma, sayfayı cihaz üzerinde OCR ile metne çevirir (internet gerekmez). İlk sayfa birkaç saniye sürebilir; Türkçe harflerde (ş, ğ, ı) bazen hata yapabilir. Taranmış PDF'in kalitesi okumayı doğrudan etkiler.
- DRM korumalı EPUB'lar ve parolalı PDF'ler açılmaz.
- APK, projeyle birlikte gelen sabit bir anahtarla (`app/ekitap.keystore`) imzalanır. Böylece her yeni sürüm eskisinin üstüne kurulur ve kitaplığın/konumların silinmez. (Anahtarın parolası depoda açıktır; yalnızca kişisel kullanım içindir, Play Store için kendi anahtarını kullan.)
- Not: Daha önce anahtarsız (geçici imzalı) bir sürüm kurduysan, bu sürüme geçerken **bir kez** eskisini silip yenisini kurman gerekir. Sonraki güncellemelerde gerekmez.
- Yerelde derlemek istersen: Android Studio ile klasörü aç, ya da `./gradlew assembleDebug`.
