package com.fatih.ekitap;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

/** Azure Speech (resmi REST arayüzü) ile yapay zekâ sesi üretir. Kullanıcının kendi anahtarı gerekir. */
final class CloudTts {

    static final class Err extends Exception {
        final boolean fatal;

        Err(String m, boolean fatal) {
            super(m);
            this.fatal = fatal;
        }
    }

    static final String[][] VOICES_TR = {
            {"tr-TR-EmelNeural", "Emel (kadın)"},
            {"tr-TR-AhmetNeural", "Ahmet (erkek)"}};
    static final String[][] VOICES_EN = {
            {"en-US-JennyNeural", "Jenny (female)"},
            {"en-US-GuyNeural", "Guy (male)"}};

    private CloudTts() {
    }

    static String esc(String s) {
        StringBuilder b = new StringBuilder(s.length() + 16);
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '&': b.append("&amp;"); break;
                case '<': b.append("&lt;"); break;
                case '>': b.append("&gt;"); break;
                case '"': b.append("&quot;"); break;
                case '\'': b.append("&apos;"); break;
                default:
                    if (c >= 0x20 || c == '\n' || c == '\t') b.append(c);
            }
        }
        return b.toString();
    }

    static String ssml(String voice, float rate, String text) {
        String lang = voice.length() >= 5 ? voice.substring(0, 5) : "tr-TR";
        int pct = Math.round((rate - 1f) * 100f);
        pct = Math.max(-50, Math.min(100, pct));
        return "<speak version='1.0' xml:lang='" + lang
                + "' xmlns='http://www.w3.org/2001/10/synthesis'><voice name='" + voice
                + "'><prosody rate='" + (pct >= 0 ? "+" : "") + pct + "%'>" + esc(text)
                + "</prosody></voice></speak>";
    }

    /** MP3 baytlarını döndürür. */
    static byte[] synth(String key, String region, String voice, float rate, String text)
            throws Err {
        HttpURLConnection c = null;
        try {
            String reg = region == null || region.trim().isEmpty() ? "westeurope"
                    : region.trim().toLowerCase(Locale.ROOT);
            URL u = new URL("https://" + reg + ".tts.speech.microsoft.com/cognitiveservices/v1");
            c = (HttpURLConnection) u.openConnection();
            c.setConnectTimeout(12000);
            c.setReadTimeout(30000);
            c.setRequestMethod("POST");
            c.setDoOutput(true);
            c.setRequestProperty("Ocp-Apim-Subscription-Key", key.trim());
            c.setRequestProperty("Content-Type", "application/ssml+xml");
            c.setRequestProperty("X-Microsoft-OutputFormat", "audio-24khz-48kbitrate-mono-mp3");
            c.setRequestProperty("User-Agent", "EkitapOkuyucu");
            byte[] body = ssml(voice, rate, text).getBytes(StandardCharsets.UTF_8);
            try (OutputStream o = c.getOutputStream()) {
                o.write(body);
            }
            int code = c.getResponseCode();
            if (code == 200) {
                try (InputStream in = c.getInputStream()) {
                    ByteArrayOutputStream out = new ByteArrayOutputStream(32768);
                    byte[] buf = new byte[8192];
                    int n;
                    while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                    if (out.size() < 200) throw new Err("Boş ses geldi", false);
                    return out.toByteArray();
                }
            }
            if (code == 401 || code == 403)
                throw new Err("Azure anahtarı veya bölge hatalı (" + code + ")", true);
            if (code == 429)
                throw new Err("Azure ücretsiz kullanım sınırı doldu veya çok sık istek (429)", true);
            if (code == 400)
                throw new Err("Azure isteği reddetti (400). Ses adı bölgede yok olabilir", true);
            if (code == 404)
                throw new Err("Bölge adı hatalı (404)", true);
            throw new Err("Azure hatası " + code, false);
        } catch (Err e) {
            throw e;
        } catch (IOException e) {
            throw new Err("İnternet bağlantısı yok veya yavaş", false);
        } catch (Exception e) {
            throw new Err("Ses üretilemedi", false);
        } finally {
            if (c != null) c.disconnect();
        }
    }
}
