package com.fatih.ekitap;

import android.net.Uri;
import android.util.Xml;

import org.xmlpull.v1.XmlPullParser;

import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/** Basit EPUB ayrıştırıcı: kapsayıcı -> OPF -> spine + içindekiler. */
final class EpubBook implements Closeable {

    static final class TocItem {
        final String title;
        final int spineIndex;

        TocItem(String title, int spineIndex) {
            this.title = title;
            this.spineIndex = spineIndex;
        }
    }

    final ZipFile zip;
    String title = "";
    /** Okuma sırasındaki bölümlerin zip içindeki yolları. */
    final List<String> spine = new ArrayList<>();
    final List<TocItem> toc = new ArrayList<>();

    static EpubBook open(File f) throws Exception {
        ZipFile z = new ZipFile(f);
        try {
            return new EpubBook(z);
        } catch (Exception e) {
            try {
                z.close();
            } catch (IOException ignored) {
            }
            throw e;
        }
    }

    private EpubBook(ZipFile z) throws Exception {
        zip = z;
        String opfPath = findOpfPath();
        String opfDir = dirOf(opfPath);

        Map<String, String[]> manifest = new LinkedHashMap<>(); // id -> {href, type, properties}
        List<String> idrefs = new ArrayList<>();
        String tocId = null;

        XmlPullParser p = parser(opfPath);
        for (int e = p.getEventType(); e != XmlPullParser.END_DOCUMENT; e = p.next()) {
            if (e != XmlPullParser.START_TAG) continue;
            String n = local(p.getName());
            if (n.equals("title") && title.isEmpty()) {
                title = textUntilEnd(p);
            } else if (n.equals("item")) {
                String id = p.getAttributeValue(null, "id");
                String href = p.getAttributeValue(null, "href");
                if (id != null && href != null) {
                    manifest.put(id, new String[]{href,
                            nz(p.getAttributeValue(null, "media-type")),
                            nz(p.getAttributeValue(null, "properties"))});
                }
            } else if (n.equals("spine")) {
                tocId = p.getAttributeValue(null, "toc");
            } else if (n.equals("itemref")) {
                String idref = p.getAttributeValue(null, "idref");
                if (idref != null) idrefs.add(idref);
            }
        }

        for (String id : idrefs) {
            String[] m = manifest.get(id);
            if (m == null || m[1].startsWith("image/")) continue;
            String path = resolve(opfDir, Uri.decode(m[0]));
            if (zip.getEntry(path) != null) spine.add(path);
        }
        if (spine.isEmpty()) throw new IOException("Kitapta okunabilir bölüm bulunamadı");

        try {
            buildToc(manifest, tocId, opfDir);
        } catch (Exception ignored) {
            // içindekiler olmasa da kitap okunur
        }
        if (toc.isEmpty()) {
            for (int i = 0; i < spine.size(); i++) {
                toc.add(new TocItem("Bölüm " + (i + 1), i));
            }
        }
    }

    // ---------------------------------------------------------------- içindekiler

    private void buildToc(Map<String, String[]> manifest, String tocId, String opfDir) {
        String ncxPath = null;
        String navPath = null;
        if (tocId != null) {
            String[] m = manifest.get(tocId);
            if (m != null) ncxPath = resolve(opfDir, Uri.decode(m[0]));
        }
        for (String[] m : manifest.values()) {
            if (navPath == null && (" " + m[2] + " ").contains(" nav ")) {
                navPath = resolve(opfDir, Uri.decode(m[0]));
            }
            if (ncxPath == null && m[1].equals("application/x-dtbncx+xml")) {
                ncxPath = resolve(opfDir, Uri.decode(m[0]));
            }
        }
        if (navPath != null && zip.getEntry(navPath) != null) parseNav(navPath);
        if (toc.isEmpty() && ncxPath != null && zip.getEntry(ncxPath) != null) parseNcx(ncxPath);
    }

    private void addToc(String label, String href, String baseDir) {
        if (label == null || label.isEmpty() || href == null) return;
        String path = resolve(baseDir, Uri.decode(href));
        int idx = spine.indexOf(path);
        if (idx >= 0) toc.add(new TocItem(label, idx));
    }

    /** EPUB3 nav belgesi. Hatalı XHTML olursa o ana kadar okunanlar kalır. */
    private void parseNav(String navPath) {
        String base = dirOf(navPath);
        try {
            XmlPullParser p = parser(navPath);
            boolean in = false;
            boolean done = false;
            for (int e = p.getEventType(); e != XmlPullParser.END_DOCUMENT && !done; e = p.next()) {
                if (e == XmlPullParser.START_TAG) {
                    String n = local(p.getName());
                    if (n.equals("nav") && !in) {
                        String t = p.getAttributeValue(null, "epub:type");
                        if (t == null || t.contains("toc")) in = true;
                    } else if (n.equals("a") && in) {
                        String href = p.getAttributeValue(null, "href");
                        String label = textUntilEnd(p);
                        addToc(label, href, base);
                    }
                } else if (e == XmlPullParser.END_TAG && in && local(p.getName()).equals("nav")) {
                    in = false;
                    done = true;
                }
            }
        } catch (Exception ignored) {
        }
    }

    /** EPUB2 toc.ncx. */
    private void parseNcx(String ncxPath) {
        String base = dirOf(ncxPath);
        try {
            XmlPullParser p = parser(ncxPath);
            String pendingLabel = null;
            for (int e = p.getEventType(); e != XmlPullParser.END_DOCUMENT; e = p.next()) {
                if (e != XmlPullParser.START_TAG) continue;
                String n = local(p.getName());
                if (n.equals("text")) {
                    String t = textUntilEnd(p);
                    if (pendingLabel == null) pendingLabel = t;
                } else if (n.equals("content")) {
                    addToc(pendingLabel, p.getAttributeValue(null, "src"), base);
                    pendingLabel = null;
                } else if (n.equals("navPoint")) {
                    pendingLabel = null;
                }
            }
        } catch (Exception ignored) {
        }
    }

    // ---------------------------------------------------------------- yardımcılar

    private String findOpfPath() throws Exception {
        XmlPullParser p = parser("META-INF/container.xml");
        for (int e = p.getEventType(); e != XmlPullParser.END_DOCUMENT; e = p.next()) {
            if (e == XmlPullParser.START_TAG && local(p.getName()).equals("rootfile")) {
                String path = p.getAttributeValue(null, "full-path");
                if (path != null) return path;
            }
        }
        throw new IOException("Geçersiz EPUB (OPF bulunamadı)");
    }

    private XmlPullParser parser(String path) throws Exception {
        ZipEntry entry = zip.getEntry(path);
        if (entry == null) throw new IOException("EPUB içinde eksik dosya: " + path);
        XmlPullParser p = Xml.newPullParser();
        try {
            p.defineEntityReplacementText("nbsp", " ");
            p.defineEntityReplacementText("copy", "©");
            p.defineEntityReplacementText("hellip", "…");
            p.defineEntityReplacementText("mdash", "—");
            p.defineEntityReplacementText("ndash", "–");
            p.defineEntityReplacementText("laquo", "«");
            p.defineEntityReplacementText("raquo", "»");
        } catch (Exception ignored) {
        }
        p.setInput(zip.getInputStream(entry), null);
        return p;
    }

    /** START_TAG üzerindeyken etiketin kapanışına kadar tüm metni toplar. */
    private static String textUntilEnd(XmlPullParser p) throws Exception {
        StringBuilder sb = new StringBuilder();
        int depth = 1;
        while (depth > 0) {
            int e = p.next();
            if (e == XmlPullParser.START_TAG) depth++;
            else if (e == XmlPullParser.END_TAG) depth--;
            else if (e == XmlPullParser.TEXT) sb.append(p.getText());
            else if (e == XmlPullParser.END_DOCUMENT) break;
        }
        return sb.toString().trim().replaceAll("\\s+", " ");
    }

    private static String local(String name) {
        int i = name.indexOf(':');
        return i >= 0 ? name.substring(i + 1) : name;
    }

    private static String nz(String s) {
        return s == null ? "" : s;
    }

    static String dirOf(String path) {
        int i = path.lastIndexOf('/');
        return i >= 0 ? path.substring(0, i) : "";
    }

    /** dir içinde göreli yolu çözer; '#' sonrasını atar, '..' ve '.' parçalarını işler. */
    static String resolve(String dir, String rel) {
        int h = rel.indexOf('#');
        if (h >= 0) rel = rel.substring(0, h);
        String full;
        if (rel.startsWith("/")) full = rel.substring(1);
        else full = dir.isEmpty() ? rel : dir + "/" + rel;
        List<String> out = new ArrayList<>();
        for (String part : full.split("/")) {
            if (part.isEmpty() || part.equals(".")) continue;
            if (part.equals("..")) {
                if (!out.isEmpty()) out.remove(out.size() - 1);
            } else {
                out.add(part);
            }
        }
        return String.join("/", out);
    }

    static String mimeOf(String path) {
        String p = path.toLowerCase(Locale.ROOT);
        int dot = p.lastIndexOf('.');
        String ext = dot >= 0 ? p.substring(dot + 1) : "";
        switch (ext) {
            case "xhtml": return "application/xhtml+xml";
            case "html":
            case "htm": return "text/html";
            case "css": return "text/css";
            case "js": return "application/javascript";
            case "jpg":
            case "jpeg": return "image/jpeg";
            case "png": return "image/png";
            case "gif": return "image/gif";
            case "webp": return "image/webp";
            case "svg": return "image/svg+xml";
            case "ttf": return "font/ttf";
            case "otf": return "font/otf";
            case "woff": return "font/woff";
            case "woff2": return "font/woff2";
            default: return "application/octet-stream";
        }
    }

    @Override
    public void close() throws IOException {
        zip.close();
    }
}
