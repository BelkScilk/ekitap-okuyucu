package com.fatih.ekitap;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;

final class Util {
    private Util() {}

    static String displayName(Context c, Uri u) {
        String n = null;
        if ("content".equals(u.getScheme())) {
            try (Cursor cur = c.getContentResolver().query(
                    u, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
                if (cur != null && cur.moveToFirst()) {
                    n = cur.getString(0);
                }
            } catch (Exception ignored) {
            }
        }
        if (n == null || n.isEmpty()) {
            n = u.getLastPathSegment();
        }
        return (n == null || n.isEmpty()) ? "Kitap" : n;
    }

    static String hex(int color) {
        return String.format("#%06X", color & 0xFFFFFF);
    }

    static int dp(Context c, int v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }
}
