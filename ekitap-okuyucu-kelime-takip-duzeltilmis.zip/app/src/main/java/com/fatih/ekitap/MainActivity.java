package com.fatih.ekitap;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Kitaplık: son okunan öne çıkar, kategoriler, raf veya kapak ızgarası görünümü. */
public class MainActivity extends Activity {
    private static final int REQ_OPEN = 1;
    private static final int REQ_NOTIF = 2;

    private static final int AMBER = 0xFFF5A623;
    private static final int AMBER_TEXT = 0xFF1A1205;
    private static final int[] PALETTE = {
            0xFF7B4A24, // kahve
            0xFF8E2F2F, // kırmızı
            0xFFC27B1E, // turuncu
            0xFF2F4A8E, // mavi
            0xFF2F6B4A, // yeşil
            0xFF4A5568, // gri
            0xFF6B3F8E, // mor
            0xFF1F7A7A  // turkuaz
    };

    private Prefs prefs;
    private ScrollView scroll;
    private LinearLayout body;
    private String selectedCat = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = new Prefs(this);

        scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(16);
        body.setPadding(pad, dp(12), pad, dp(28));
        scroll.addView(body, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(scroll);

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS},
                    REQ_NOTIF);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        render();
    }

    // =================================================================== çizim

    private int dp(int v) {
        return Util.dp(this, v);
    }

    private void render() {
        final int t = prefs.theme();
        final int bg = Prefs.bg(t);
        final int fg = Prefs.fg(t);
        scroll.setBackgroundColor(bg);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        int flags = 0;
        if (t != Prefs.DARK) {
            flags = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        }
        getWindow().getDecorView().setSystemUiVisibility(flags);

        body.removeAllViews();
        final List<Prefs.Recent> all = prefs.recents();

        // ---- başlık satırı ----
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = new TextView(this);
        title.setText("Kitaplığım");
        title.setTextSize(26);
        title.setTextColor(fg);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        head.addView(title, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView themeBtn = pill("◐", Prefs.bar(t), fg, v -> chooseTheme());
        head.addView(themeBtn);
        TextView addBtn = pill("＋ Kitap ekle", AMBER, AMBER_TEXT, v -> pickFile());
        addBtn.setTypeface(Typeface.DEFAULT_BOLD);
        head.addView(addBtn);
        add(head, 0);

        if (all.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("Henüz kitap yok.\n\"Kitap ekle\" düğmesiyle bir EPUB veya PDF seç.");
            empty.setTextColor(fg);
            empty.setTextSize(16);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(0, dp(60), 0, 0);
            add(empty, 0);
            return;
        }

        // ---- son okunan: büyük kart ----
        add(featuredCard(all.get(0), fg), 16);

        // ---- kategori sekmeleri ----
        List<String> cats = new ArrayList<>();
        for (Prefs.Recent r : all) {
            if (!r.category.isEmpty() && !cats.contains(r.category)) cats.add(r.category);
        }
        if (!selectedCat.isEmpty() && !cats.contains(selectedCat)) selectedCat = "";

        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout chips = new LinearLayout(this);
        chips.setOrientation(LinearLayout.HORIZONTAL);
        chips.addView(chip("Tümü (" + all.size() + ")", selectedCat.isEmpty(), v -> {
            selectedCat = "";
            render();
        }));
        for (final String c : cats) {
            int n = 0;
            for (Prefs.Recent r : all) if (r.category.equals(c)) n++;
            chips.addView(chip(c + " (" + n + ")", c.equals(selectedCat), v -> {
                selectedCat = c;
                render();
            }));
        }
        hs.addView(chips);
        add(hs, 20);

        if (cats.isEmpty()) {
            TextView hint = new TextView(this);
            hint.setText("İpucu: bir kitabın üstüne uzun basarak kategori atayabilirsin.");
            hint.setTextColor(fg);
            hint.setAlpha(0.6f);
            hint.setTextSize(12);
            add(hint, 8);
        }

        // ---- görünüm seçimi ----
        final boolean grid = prefs.libGrid();
        LinearLayout modes = new LinearLayout(this);
        modes.setOrientation(LinearLayout.HORIZONTAL);
        modes.addView(chip("Kitaplık rafı", !grid, v -> {
            prefs.setLibGrid(false);
            render();
        }));
        modes.addView(chip("Kapak ızgarası", grid, v -> {
            prefs.setLibGrid(true);
            render();
        }));
        add(modes, 12);

        // ---- kitaplar ----
        final List<Prefs.Recent> shown = new ArrayList<>();
        for (Prefs.Recent r : all) {
            if (selectedCat.isEmpty() || r.category.equals(selectedCat)) shown.add(r);
        }
        if (shown.isEmpty()) {
            TextView none = new TextView(this);
            none.setText("Bu kategoride kitap yok.");
            none.setTextColor(fg);
            none.setPadding(0, dp(24), 0, 0);
            add(none, 0);
            return;
        }
        if (grid) buildGrid(shown);
        else buildShelves(shown);
    }

    private void add(View v, int topDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(topDp);
        body.addView(v, lp);
    }

    private GradientDrawable rounded(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private TextView pill(String text, int bgColor, int textColor, View.OnClickListener l) {
        TextView c = new TextView(this);
        c.setText(text);
        c.setTextSize(14);
        c.setTextColor(textColor);
        c.setPadding(dp(14), dp(9), dp(14), dp(9));
        c.setBackground(rounded(bgColor, 20));
        c.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.rightMargin = dp(8);
        c.setLayoutParams(lp);
        return c;
    }

    private TextView chip(String label, boolean selected, View.OnClickListener l) {
        int t = prefs.theme();
        TextView c = pill(label, selected ? AMBER : Prefs.bar(t),
                selected ? AMBER_TEXT : Prefs.fg(t), l);
        if (selected) c.setTypeface(Typeface.DEFAULT_BOLD);
        return c;
    }

    private View featuredCard(final Prefs.Recent r, int fg) {
        int base = colorOf(r);
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(16), dp(18), dp(18));
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{blend(base, Color.WHITE, 0.12f), blend(base, Color.BLACK, 0.35f)});
        g.setCornerRadius(dp(18));
        card.setBackground(g);

        float progress = prefs.progress(r.key());
        TextView tag = new TextView(this);
        tag.setText("SON OKUNAN · KALDIĞIN YERDEN DEVAM ET");
        tag.setTextSize(11);
        tag.setTextColor(0xFFFFD27A);
        tag.setTypeface(Typeface.DEFAULT_BOLD);
        card.addView(tag);

        TextView ttl = new TextView(this);
        ttl.setText(cleanTitle(r.name));
        ttl.setTextSize(21);
        ttl.setTextColor(Color.WHITE);
        ttl.setTypeface(Typeface.DEFAULT_BOLD);
        ttl.setMaxLines(3);
        ttl.setEllipsize(TextUtils.TruncateAt.END);
        ttl.setPadding(0, dp(8), 0, dp(4));
        card.addView(ttl);

        String sub = typeTag(r) + (r.category.isEmpty() ? "" : " · " + r.category)
                + String.format(Locale.US, " · %%%d okundu", Math.round(progress * 100));
        TextView st = new TextView(this);
        st.setText(sub);
        st.setTextSize(13);
        st.setTextColor(0xCCFFFFFF);
        card.addView(st);

        Bar bar = new Bar(this, progress, AMBER, 0x44FFFFFF);
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(6));
        bl.topMargin = dp(12);
        card.addView(bar, bl);

        TextView go = pill("Devam et ▶", AMBER, AMBER_TEXT, v -> openBook(Uri.parse(r.uri)));
        go.setTypeface(Typeface.DEFAULT_BOLD);
        LinearLayout.LayoutParams gl = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        gl.topMargin = dp(14);
        card.addView(go, gl);

        card.setOnClickListener(v -> openBook(Uri.parse(r.uri)));
        card.setOnLongClickListener(v -> {
            bookMenu(r);
            return true;
        });
        return card;
    }

    private void buildShelves(List<Prefs.Recent> shown) {
        int cw = getResources().getDisplayMetrics().widthPixels - dp(32);
        int w = dp(54);
        int gap = dp(8);
        int per = Math.max(3, (cw + gap) / (w + gap));
        for (int i = 0; i < shown.size(); i += per) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.BOTTOM);
            row.setPadding(dp(6), 0, dp(6), 0);
            int end = Math.min(shown.size(), i + per);
            for (int j = i; j < end; j++) {
                final Prefs.Recent r = shown.get(j);
                int h = dp(150 + (hashOf(r) % 5) * 10);
                SpineView sv = new SpineView(this, cleanTitle(r.name), colorOf(r),
                        prefs.progress(r.key()));
                sv.setOnClickListener(v -> openBook(Uri.parse(r.uri)));
                sv.setOnLongClickListener(v -> {
                    bookMenu(r);
                    return true;
                });
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(w, h);
                lp.rightMargin = gap;
                row.addView(sv, lp);
            }
            add(row, 20);

            View plank = new View(this);
            GradientDrawable pg = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                    new int[]{0xFF9A6630, 0xFF5A3815});
            pg.setCornerRadius(dp(5));
            plank.setBackground(pg);
            LinearLayout.LayoutParams pl = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(14));
            body.addView(plank, pl);
        }
    }

    private void buildGrid(List<Prefs.Recent> shown) {
        final int perRow = 3;
        int cw = getResources().getDisplayMetrics().widthPixels - dp(32);
        int gap = dp(10);
        int w = (cw - gap * (perRow - 1)) / perRow;
        int h = Math.round(w * 1.5f);
        for (int i = 0; i < shown.size(); i += perRow) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            for (int j = 0; j < perRow; j++) {
                int idx = i + j;
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(w, h);
                if (j < perRow - 1) lp.rightMargin = gap;
                if (idx < shown.size()) {
                    final Prefs.Recent r = shown.get(idx);
                    CoverView cv = new CoverView(this, cleanTitle(r.name), colorOf(r),
                            prefs.progress(r.key()), typeTag(r));
                    cv.setOnClickListener(v -> openBook(Uri.parse(r.uri)));
                    cv.setOnLongClickListener(v -> {
                        bookMenu(r);
                        return true;
                    });
                    row.addView(cv, lp);
                } else {
                    row.addView(new View(this), lp);
                }
            }
            add(row, 12);
        }
    }

    // =================================================================== menüler

    private void bookMenu(final Prefs.Recent r) {
        new AlertDialog.Builder(this)
                .setTitle(cleanTitle(r.name))
                .setItems(new String[]{"Kategori ata / değiştir", "Listeden kaldır"},
                        (d, which) -> {
                            if (which == 0) chooseCategory(r);
                            else {
                                prefs.removeRecent(r.uri);
                                render();
                            }
                        })
                .show();
    }

    private void chooseCategory(final Prefs.Recent r) {
        final List<String> cats = new ArrayList<>();
        for (Prefs.Recent x : prefs.recents()) {
            if (!x.category.isEmpty() && !cats.contains(x.category)) cats.add(x.category);
        }
        final List<String> items = new ArrayList<>(cats);
        items.add("＋ Yeni kategori…");
        final boolean hasCat = !r.category.isEmpty();
        if (hasCat) items.add("Kategorisiz yap");
        new AlertDialog.Builder(this)
                .setTitle("Kategori")
                .setItems(items.toArray(new String[0]), (d, which) -> {
                    if (which < cats.size()) {
                        prefs.setCategory(r.uri, cats.get(which));
                        render();
                    } else if (which == cats.size()) {
                        askNewCategory(r);
                    } else {
                        prefs.setCategory(r.uri, "");
                        render();
                    }
                })
                .show();
    }

    private void askNewCategory(final Prefs.Recent r) {
        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        input.setHint("Örn. Roman, Tarih, Ders");
        new AlertDialog.Builder(this)
                .setTitle("Yeni kategori")
                .setView(input)
                .setPositiveButton("Kaydet", (d, w) -> {
                    String name = input.getText().toString().trim();
                    if (!name.isEmpty()) {
                        prefs.setCategory(r.uri, name);
                        selectedCat = name;
                        render();
                    }
                })
                .setNegativeButton("Vazgeç", null)
                .show();
    }

    private void chooseTheme() {
        new AlertDialog.Builder(this)
                .setTitle("Tema")
                .setItems(new String[]{"Açık", "Karanlık", "Sepya"}, (d, which) -> {
                    prefs.setTheme(which);
                    render();
                })
                .show();
    }

    // =================================================================== dosya seçimi

    private void pickFile() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try {
            startActivityForResult(i, REQ_OPEN);
        } catch (Exception e) {
            Toast.makeText(this, "Dosya seçici açılamadı", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_OPEN && resultCode == RESULT_OK && data != null
                && data.getData() != null) {
            Uri uri = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(
                        uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) {
            }
            openBook(uri);
        }
    }

    private void openBook(Uri uri) {
        Intent i = new Intent(this, ReaderActivity.class);
        i.setData(uri);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(i);
    }

    // =================================================================== yardımcılar

    private static String typeTag(Prefs.Recent r) {
        return "pdf".equals(r.type) ? "PDF" : "EPUB";
    }

    private static int hashOf(Prefs.Recent r) {
        return r.name.hashCode() & 0x7fffffff;
    }

    private static int colorOf(Prefs.Recent r) {
        return PALETTE[hashOf(r) % PALETTE.length];
    }

    /** "16163341_017-Sabahattin-Ali-Kurk-Mantolu.pdf" -> "Sabahattin Ali Kurk Mantolu" */
    static String cleanTitle(String name) {
        String s = name;
        int dot = s.lastIndexOf('.');
        if (dot > 0 && s.length() - dot <= 6) s = s.substring(0, dot);
        s = s.replace('_', ' ').replace('-', ' ');
        s = s.replaceFirst("^(\\d+\\s+)+", "");
        s = s.replaceAll("\\s+", " ").trim();
        return s.isEmpty() ? name : s;
    }

    static int blend(int a, int b, float t) {
        int r = Math.round(Color.red(a) * (1 - t) + Color.red(b) * t);
        int g = Math.round(Color.green(a) * (1 - t) + Color.green(b) * t);
        int bl = Math.round(Color.blue(a) * (1 - t) + Color.blue(b) * t);
        return Color.rgb(r, g, bl);
    }

    // =================================================================== özel görünümler

    /** Raftaki kitap sırtı: dikey başlık + alt kısımda ilerleme çubuğu. */
    static final class SpineView extends View {
        private final String title;
        private final int color;
        private final float progress;
        private final float d;
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint barBg = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint barFg = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final TextPaint text = new TextPaint(Paint.ANTI_ALIAS_FLAG);

        SpineView(Context c, String title, int color, float progress) {
            super(c);
            this.title = title;
            this.color = color;
            this.progress = progress;
            this.d = c.getResources().getDisplayMetrics().density;
            line.setColor(0x33FFFFFF);
            barBg.setColor(0x55000000);
            barFg.setColor(AMBER);
            text.setColor(Color.WHITE);
            text.setTextSize(15 * d);
            text.setTypeface(Typeface.DEFAULT_BOLD);
        }

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) {
            fill.setShader(new LinearGradient(0, 0, w, 0,
                    new int[]{blend(color, Color.WHITE, 0.18f), color,
                            blend(color, Color.BLACK, 0.30f)},
                    new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth();
            float h = getHeight();
            c.drawRoundRect(new RectF(0, 0, w, h), 4 * d, 4 * d, fill);
            c.drawRect(w * 0.22f, 12 * d, w * 0.78f, 13.5f * d, line);

            float bottomPad = 34 * d;
            float avail = h - bottomPad - 24 * d;
            CharSequence t = TextUtils.ellipsize(title, text, avail, TextUtils.TruncateAt.END);
            c.save();
            c.translate(w / 2f + text.getTextSize() * 0.35f, h - bottomPad);
            c.rotate(-90);
            c.drawText(t, 0, t.length(), 0, 0, text);
            c.restore();

            float bx = 10 * d;
            float bw = w - 20 * d;
            float bh = 5 * d;
            float by = h - 16 * d;
            c.drawRoundRect(new RectF(bx, by, bx + bw, by + bh), bh / 2, bh / 2, barBg);
            if (progress > 0f) {
                float fw = Math.max(bh, bw * progress);
                c.drawRoundRect(new RectF(bx, by, bx + fw, by + bh), bh / 2, bh / 2, barFg);
            }
        }
    }

    /** Izgara görünümündeki kapak: renkli zemin üstünde ortalanmış başlık. */
    static final class CoverView extends View {
        private final String title;
        private final String tag;
        private final int color;
        private final float progress;
        private final float d;
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint barBg = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint barFg = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final TextPaint text = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        private final TextPaint tagPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        private StaticLayout layout;

        CoverView(Context c, String title, int color, float progress, String tag) {
            super(c);
            this.title = title;
            this.color = color;
            this.progress = progress;
            this.tag = tag;
            this.d = c.getResources().getDisplayMetrics().density;
            barBg.setColor(0x55000000);
            barFg.setColor(AMBER);
            text.setColor(Color.WHITE);
            text.setTextSize(14 * d);
            text.setTypeface(Typeface.DEFAULT_BOLD);
            tagPaint.setColor(0xFFFFD27A);
            tagPaint.setTextSize(10 * d);
            tagPaint.setTypeface(Typeface.DEFAULT_BOLD);
        }

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) {
            fill.setShader(new LinearGradient(0, 0, w, h,
                    blend(color, Color.WHITE, 0.15f), blend(color, Color.BLACK, 0.35f),
                    Shader.TileMode.CLAMP));
            int tw = Math.max(1, (int) (w - 20 * d));
            layout = StaticLayout.Builder.obtain(title, 0, title.length(), text, tw)
                    .setAlignment(Layout.Alignment.ALIGN_CENTER)
                    .setMaxLines(6)
                    .setEllipsize(TextUtils.TruncateAt.END)
                    .build();
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth();
            float h = getHeight();
            c.drawRoundRect(new RectF(0, 0, w, h), 10 * d, 10 * d, fill);
            c.drawText(tag, 10 * d, 18 * d, tagPaint);
            if (layout != null) {
                c.save();
                c.translate(10 * d, Math.max(24 * d, (h - layout.getHeight()) / 2f));
                layout.draw(c);
                c.restore();
            }
            float bx = 10 * d;
            float bw = w - 20 * d;
            float bh = 5 * d;
            float by = h - 14 * d;
            c.drawRoundRect(new RectF(bx, by, bx + bw, by + bh), bh / 2, bh / 2, barBg);
            if (progress > 0f) {
                float fw = Math.max(bh, bw * progress);
                c.drawRoundRect(new RectF(bx, by, bx + fw, by + bh), bh / 2, bh / 2, barFg);
            }
        }
    }

    /** Düz ilerleme çubuğu. */
    static final class Bar extends View {
        private final float progress;
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);

        Bar(Context c, float progress, int fillColor, int trackColor) {
            super(c);
            this.progress = progress;
            fill.setColor(fillColor);
            track.setColor(trackColor);
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth();
            float h = getHeight();
            c.drawRoundRect(new RectF(0, 0, w, h), h / 2, h / 2, track);
            if (progress > 0f) {
                c.drawRoundRect(new RectF(0, 0, Math.max(h, w * progress), h), h / 2, h / 2, fill);
            }
        }
    }
}
