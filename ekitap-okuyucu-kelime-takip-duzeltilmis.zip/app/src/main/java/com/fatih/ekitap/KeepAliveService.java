package com.fatih.ekitap;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;

/** Ekran kapalıyken sesli okuma ve uyku zamanlayıcısı çalışmaya devam etsin diye. */
public class KeepAliveService extends Service {
    private static final String CHANNEL = "reading";

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(
                CHANNEL, "Sesli okuma", NotificationManager.IMPORTANCE_LOW));

        PendingIntent pi = null;
        Intent launch = getPackageManager().getLaunchIntentForPackage(getPackageName());
        if (launch != null) {
            pi = PendingIntent.getActivity(this, 0, launch, PendingIntent.FLAG_IMMUTABLE);
        }

        Notification.Builder b = new Notification.Builder(this, CHANNEL)
                .setContentTitle("Ekitap Okuyucu")
                .setContentText("Sesli okuma sürüyor")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setOngoing(true);
        if (pi != null) b.setContentIntent(pi);
        Notification n = b.build();

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        } else {
            startForeground(1, n);
        }
        return START_NOT_STICKY;
    }
}
