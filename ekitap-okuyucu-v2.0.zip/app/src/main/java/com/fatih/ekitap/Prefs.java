package com.fatih.ekitap;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** Ayarlar, okuma konumu ve son açılan kitaplar. */
final class Prefs {
    static final int LIGHT = 0;
    static final int DARK = 1;
    static final int SEPIA = 2;

    static final class Recent {
        final String uri;
        final String name;
        final String type;
        final String category; // "" = kategorisiz

        Recent(String uri, String name, String type) {
            this(uri, name, type, "");
        }

        Recent(String uri, String name, String type, String category) {
            this.uri = uri;
            this.name = name;
            this.type = type;
            this.category = category == null ? "" : category;
        }

        /** Okuma konumunun saklandığı anahtar (ReaderActivity ile aynı biçim). */
        String key() {
            return Integer.toHexString(uri.hashCode());
        }
    }

    private final SharedPreferences sp;

    Prefs(Context c) {
        sp = c.getApplicationContext().getSharedPreferences("ekitap", Context.MODE_PRIVATE);
    }

    // ---- görünüm / ses ayarları ----
    int theme() { return sp.getInt("theme", DARK); }
    void setTheme(int t) { sp.edit().putInt("theme", t).apply(); }

    int textZoom() { return sp.getInt("textZoom", 100); }
    void setTextZoom(int z) { sp.edit().putInt("textZoom", z).apply(); }

    float pdfZoom() { return sp.getFloat("pdfZoom", 1f); }
    void setPdfZoom(float z) { sp.edit().putFloat("pdfZoom", z).apply(); }

    float rate() { return sp.getFloat("rate", 1f); }
    void setRate(float r) { sp.edit().putFloat("rate", r).apply(); }

    /** Ortalama okuma hızı (kelime/dakika). Kalan süre tahmini için. */
    float wpm() { return sp.getFloat("wpm", 200f); }
    void setWpm(float w) { sp.edit().putFloat("wpm", Math.max(80f, Math.min(400f, w))).apply(); }

    String lang() { return sp.getString("lang", "tr"); }
    void setLang(String l) { sp.edit().putString("lang", l).apply(); }

    boolean pdfTextMode() { return sp.getBoolean("pdfTextMode", false); }
    void setPdfTextMode(boolean b) { sp.edit().putBoolean("pdfTextMode", b).apply(); }

    boolean pdfCrop() { return sp.getBoolean("pdfCrop", true); }
    void setPdfCrop(boolean b) { sp.edit().putBoolean("pdfCrop", b).apply(); }

    boolean tapPaging() { return sp.getBoolean("tapPaging", true); }
    void setTapPaging(boolean b) { sp.edit().putBoolean("tapPaging", b).apply(); }

    boolean keepOn() { return sp.getBoolean("keepOn", true); }
    void setKeepOn(boolean b) { sp.edit().putBoolean("keepOn", b).apply(); }

    // ---- profesyonel okuma ayarları ----
    /** 0=sistem, 1=serif, 2=sans, 3=mono */
    int fontFamily() { return sp.getInt("fontFamily", 0); }
    void setFontFamily(int f) { sp.edit().putInt("fontFamily", Math.max(0, Math.min(3, f))).apply(); }

    /** Satır aralığı çarpanı (1.0 – 2.0) */
    float lineSpacing() { return sp.getFloat("lineSpacing", 1.4f); }
    void setLineSpacing(float s) { sp.edit().putFloat("lineSpacing", Math.max(1.0f, Math.min(2.2f, s))).apply(); }

    /** Kenar boşluğu dp (8 – 40) */
    int marginDp() { return sp.getInt("marginDp", 16); }
    void setMarginDp(int m) { sp.edit().putInt("marginDp", Math.max(8, Math.min(48, m))).apply(); }

    /** Toplam okuma süresi (ms) – istatistik */
    long totalReadingMs() { return sp.getLong("totalReadingMs", 0L); }
    void addReadingMs(long ms) {
        if (ms > 0) sp.edit().putLong("totalReadingMs", totalReadingMs() + ms).apply();
    }

    /** Kitap başına okuma süresi */
    long bookReadingMs(String key) { return sp.getLong("brms_" + key, 0L); }
    void addBookReadingMs(String key, long ms) {
        if (ms > 0 && key != null) {
            sp.edit().putLong("brms_" + key, bookReadingMs(key) + ms).apply();
            addReadingMs(ms);
        }
    }

    // ---- tema renkleri ----
    static int bg(int t) {
        switch (t) {
            case LIGHT: return 0xFFFFFFFF;
            case SEPIA: return 0xFFF4ECD8;
            default: return 0xFF121212;
        }
    }

    static int fg(int t) {
        switch (t) {
            case LIGHT: return 0xFF1A1A1A;
            case SEPIA: return 0xFF5B4636;
            default: return 0xFFE0E0E0;
        }
    }

    static int bar(int t) {
        switch (t) {
            case LIGHT: return 0xFFEEEEEE;
            case SEPIA: return 0xFFE8DCBF;
            default: return 0xFF1E1E1E;
        }
    }

    static int link(int t) {
        switch (t) {
            case LIGHT: return 0xFF1A0DAB;
            case SEPIA: return 0xFF8B4513;
            default: return 0xFF8AB4F8;
        }
    }

    // ---- okuma konumu (kitap anahtarı ile) ----
    int chapter(String key) { return sp.getInt("ch_" + key, 0); }
    float frac(String key) { return sp.getFloat("fr_" + key, 0f); }
    int page(String key) { return sp.getInt("pg_" + key, 0); }

    void saveChapter(String key, int ch) { sp.edit().putInt("ch_" + key, ch).apply(); }
    void saveFrac(String key, float f) { sp.edit().putFloat("fr_" + key, f).apply(); }
    void savePage(String key, int p) { sp.edit().putInt("pg_" + key, p).apply(); }

    /** 0..1 arası genel okuma ilerlemesi (kitaplıkta ilerleme çubuğu için). */
    float progress(String key) { return sp.getFloat("pr_" + key, 0f); }
    void saveProgress(String key, float f) {
        sp.edit().putFloat("pr_" + key, Math.max(0f, Math.min(1f, f))).apply();
    }

    boolean libGrid() { return sp.getBoolean("libGrid", false); }
    void setLibGrid(boolean b) { sp.edit().putBoolean("libGrid", b).apply(); }

    // ---- yer imleri (kitap anahtarı ile) ----
    static final class Bookmark {
        final String label;
        final int pos;     // EPUB: bölüm sırası, PDF: sayfa sırası
        final float frac;  // EPUB: bölüm içindeki konum (0..1)

        Bookmark(String label, int pos, float frac) {
            this.label = label;
            this.pos = pos;
            this.frac = frac;
        }
    }

    List<Bookmark> bookmarks(String key) {
        List<Bookmark> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(sp.getString("bm_" + key, "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                out.add(new Bookmark(o.optString("l", "Yer imi"), o.optInt("p", 0),
                        (float) o.optDouble("f", 0.0)));
            }
        } catch (Exception ignored) {
        }
        return out;
    }

    private void saveBookmarks(String key, List<Bookmark> list) {
        try {
            JSONArray a = new JSONArray();
            for (Bookmark b : list) {
                JSONObject o = new JSONObject();
                o.put("l", b.label);
                o.put("p", b.pos);
                o.put("f", (double) b.frac);
                a.put(o);
            }
            sp.edit().putString("bm_" + key, a.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    /** En yeni başa eklenir; aynı yere (çok yakın) tekrar eklenmez. */
    void addBookmark(String key, Bookmark b) {
        List<Bookmark> list = bookmarks(key);
        for (int i = list.size() - 1; i >= 0; i--) {
            Bookmark x = list.get(i);
            if (x.pos == b.pos && Math.abs(x.frac - b.frac) < 0.01f) list.remove(i);
        }
        list.add(0, b);
        while (list.size() > 100) list.remove(list.size() - 1);
        saveBookmarks(key, list);
    }

    void removeBookmark(String key, int index) {
        List<Bookmark> list = bookmarks(key);
        if (index >= 0 && index < list.size()) {
            list.remove(index);
            saveBookmarks(key, list);
        }
    }

    // ---- son açılanlar ----
    List<Recent> recents() {
        List<Recent> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(sp.getString("recents", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                out.add(new Recent(o.getString("uri"), o.optString("name", "Kitap"),
                        o.optString("type", ""), o.optString("cat", "")));
            }
        } catch (Exception ignored) {
        }
        return out;
    }

    private void saveRecents(List<Recent> list) {
        try {
            JSONArray a = new JSONArray();
            for (Recent r : list) {
                JSONObject o = new JSONObject();
                o.put("uri", r.uri);
                o.put("name", r.name);
                o.put("type", r.type);
                o.put("cat", r.category);
                a.put(o);
            }
            sp.edit().putString("recents", a.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    void addRecent(Recent r) {
        List<Recent> list = recents();
        String cat = r.category;
        for (int i = list.size() - 1; i >= 0; i--) {
            if (list.get(i).uri.equals(r.uri)) {
                if (cat.isEmpty()) cat = list.get(i).category; // kategori korunur
                list.remove(i);
            }
        }
        list.add(0, new Recent(r.uri, r.name, r.type, cat));
        while (list.size() > 300) list.remove(list.size() - 1);
        saveRecents(list);
    }

    /** Kitabı başka kategoriye taşır ("" = kategorisiz); sıralama değişmez. */
    void setCategory(String uri, String category) {
        List<Recent> list = recents();
        for (int i = 0; i < list.size(); i++) {
            Recent r = list.get(i);
            if (r.uri.equals(uri)) {
                list.set(i, new Recent(r.uri, r.name, r.type, category));
            }
        }
        saveRecents(list);
    }

    void removeRecent(String uri) {
        List<Recent> list = recents();
        for (int i = list.size() - 1; i >= 0; i--) {
            if (list.get(i).uri.equals(uri)) list.remove(i);
        }
        saveRecents(list);
    }
}
