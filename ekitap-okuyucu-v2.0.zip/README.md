# Ekitap Okuyucu (Android)

EPUB ve PDF okuyan, sesli okuyabilen, profesyonel özelliklere sahip hafif bir Android e-kitap uygulaması.

## Özellikler

### Okuma deneyimi
- **EPUB ve PDF** (taranmış PDF’ler dahil, cihaz üzerinde OCR)
- **Yazı tipi** seçimi: Sistem / Serif / Sans-serif / Monospace
- **Yazı boyutu**, **satır aralığı** ve **kenar boşluğu** ayarları
- **Temalar**: Açık, Karanlık, Sepya
- **İlerleme çubuğu**: sayfa/bölüm + yüzde + kalan süre tahmini (`~2 sa 15 dk`)
- **Kitapta ara**: mevcut bölüm/sayfada kelime arama + vurgulama
- **Yer imleri** (ekle / listele / uzun basarak sil)
- Kaldığın yeri hatırlar (bölüm, sayfa, konum)

### Sesli okuma
- Kelime vurgulama + otomatik takip (EPUB + PDF metin modu)
- PDF’de metin modu kapalıysa TTS başlarken otomatik açılır
- Hız ve dil seçimi
- Bildirimden kontrol (Önceki / Duraklat / Sonraki / Durdur)
- Kulaklık & Bluetooth medya tuşları
- Bildirimde gerçek süre çubuğu (ilerleme güncellenir)
- Arama gelince / kulaklık çıkınca otomatik duraklama

### Diğer
- **Okuma istatistikleri**: bu kitapta ve toplamda geçen süre
- **Uyku zamanlayıcısı** (15–90 dk veya özel)
- Kitaplık: son okunan, kategoriler, ızgara / liste
- PDF: kenar kırpma + metin modu (OCR ile yazı ekrana sığar)
- Ekran kapalıyken de sesli okuma çalışır

## APK'yı alma (bilgisayarda hiçbir şey kurmadan)

1. GitHub'da yeni bir depo (repository) oluştur.
2. Bu klasörün **içindeki her şeyi** depoya yükle (`.github` klasörü dahil! Gizli klasör olduğu için dosya yöneticisinde "gizli dosyaları göster" açık olmalı). Git kullanıyorsan:
   ```
   git init
   git add .
   git commit -m "ilk sürüm"
   git branch -M main
   git remote add origin https://github.com/KULLANICI/DEPO.git
   git push -u origin main
   ```
3. GitHub'da depoda **Actions** sekmesine gir. "APK Derle" otomatik çalışır (2-5 dk). Çalışmazsa "APK Derle" > **Run workflow**.
4. Bitince çalışmanın sayfasının altındaki **Artifacts** bölümünden `ekitap-okuyucu-apk` dosyasını indir, zip'ten çıkan `ekitap-okuyucu.apk` dosyasını telefona at.
5. Telefonda APK'ya dokun, "bilinmeyen kaynaklardan yüklemeye izin ver" de, kur.

İstersen `v1.0` gibi bir etiket (tag) atarsan APK **Releases** bölümüne de otomatik eklenir; telefondan doğrudan oradan indirebilirsin.

## Notlar

- Sesli okuma telefondaki metin okuma (TTS) motorunu kullanır (Google TTS vb.). Türkçe ses yoksa: Ayarlar > Metin okuma > Google > Türkçe sesi indir.
- PDF'lerde sesli okuma, sayfayı cihaz üzerinde OCR ile metne çevirir (internet gerekmez). İlk sayfa birkaç saniye sürebilir; Türkçe harflerde (ş, ğ, ı) bazen hata yapabilir. Taranmış PDF'in kalitesi okumayı doğrudan etkiler.
- DRM korumalı EPUB'lar ve parolalı PDF'ler açılmaz.
- APK, projeyle birlikte gelen sabit bir anahtarla (`app/ekitap.keystore`) imzalanır. Böylece her yeni sürüm eskisinin üstüne kurulur ve kitaplığın/konumların silinmez. (Anahtarın parolası depoda açıktır; yalnızca kişisel kullanım içindir, Play Store için kendi anahtarını kullan.)
- Not: Daha önce anahtarsız (geçici imzalı) bir sürüm kurduysan, bu sürüme geçerken **bir kez** eskisini silip yenisini kurman gerekir. Sonraki güncellemelerde gerekmez.
- Yerelde derlemek istersen: Android Studio ile klasörü aç, ya da `./gradlew assembleDebug`.
