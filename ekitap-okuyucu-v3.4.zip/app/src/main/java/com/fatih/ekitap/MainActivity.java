package com.fatih.ekitap;

import android.app.Activity;
import android.content.ClipData;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.LruCache;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.Collator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Kitaplık: devam kartı, kategori çipleri, raf görünümü, arama ve sıralama. */
public class MainActivity extends Activity {
    private static final int REQ_OPEN = 11;

    private Prefs prefs;
    private Palette pal;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final LruCache<String, Bitmap> covers = new LruCache<>(60);

    private FrameLayout root;
    private ScrollView scroll;
    private LinearLayout content;
    private EditText searchBox;
    private boolean searching;
    private String query = "";
    private String selCat; // null = Tümü
    private boolean preparing;
    private boolean destroyed;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = new Prefs(this);
        pal = prefs.palette();
        root = new FrameLayout(this);
        setContentView(root);
        applyWindow();
        build();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (prefs.theme() != pal.id) {
            pal = prefs.palette();
            applyWindow();
        }
        build();
        prepareCovers();
    }

    @Override
    protected void onDestroy() {
        destroyed = true;
        io.shutdownNow();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (searching) {
            closeSearch();
            return;
        }
        super.onBackPressed();
    }

    private void applyWindow() {
        root.setBackgroundColor(pal.bg);
        getWindow().setStatusBarColor(pal.bg);
        getWindow().setNavigationBarColor(pal.bg);
        int f = 0;
        if (pal.lightUi) {
            f = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        }
        getWindow().getDecorView().setSystemUiVisibility(f);
    }

    // ------------------------------------------------------------------ yapı

    private void build() {
        root.removeAllViews();
        scroll = new ScrollView(this);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setClipToPadding(false);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(content, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(scroll, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        root.addView(addButton(), fabParams());
        render();
    }

    private FrameLayout.LayoutParams fabParams() {
        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | Gravity.END);
        p.setMargins(0, 0, Ui.dp(this, 18), Ui.dp(this, 22));
        return p;
    }

    private View addButton() {
        LinearLayout b = new LinearLayout(this);
        b.setOrientation(LinearLayout.HORIZONTAL);
        b.setGravity(Gravity.CENTER_VERTICAL);
        b.setPadding(Ui.dp(this, 16), Ui.dp(this, 14), Ui.dp(this, 20), Ui.dp(this, 14));
        Ui.press(b, pal, pal.accent, 28);
        b.setElevation(Ui.dp(this, 6));
        ImageView ic = Ui.icon(this, Icons.PLUS, pal.accentOn, 22, 0);
        b.addView(ic, new LinearLayout.LayoutParams(Ui.dp(this, 22), Ui.dp(this, 22)));
        TextView t = Ui.bold(this, "Kitap ekle", 15f, pal.accentOn);
        t.setPadding(Ui.dp(this, 8), 0, 0, 0);
        b.addView(t);
        b.setOnClickListener(v -> pickBooks());
        return b;
    }

    private void render() {
        content.removeAllViews();
        int sidePad = Ui.dp(this, 20);
        content.setPadding(0, Ui.dp(this, 8), 0, Ui.dp(this, 110));

        content.addView(header());
        if (searching) content.addView(searchRow());

        List<Prefs.Recent> all = prefs.recents();
        if (all.isEmpty()) {
            content.addView(emptyState());
            return;
        }

        // Devam kartı
        if (!searching && selCat == null) {
            Prefs.Recent last = all.get(0);
            content.addView(hero(last));
        }

        // Kategori çipleri
        if (!searching) content.addView(categoryChips(all));

        // Liste
        List<Prefs.Recent> shown = filtered(all);
        sort(shown);
        if (shown.isEmpty()) {
            TextView t = Ui.text(this, searching ? "Sonuç bulunamadı." : "Bu kategoride kitap yok.",
                    15f, pal.muted);
            t.setGravity(Gravity.CENTER);
            t.setPadding(sidePad, Ui.dp(this, 40), sidePad, 0);
            content.addView(t);
        } else if (prefs.libGrid()) {
            addShelves(shown);
        } else {
            addRows(shown);
        }
    }

    private List<Prefs.Recent> filtered(List<Prefs.Recent> all) {
        List<Prefs.Recent> out = new ArrayList<>();
        Locale tr = new Locale("tr", "TR");
        String q = query.trim().toLowerCase(tr);
        for (Prefs.Recent r : all) {
            if (selCat != null && !searching) {
                if (selCat.isEmpty() ? !r.category.isEmpty() : !r.category.equals(selCat)) continue;
            }
            if (!q.isEmpty() && !(r.name.toLowerCase(tr).contains(q)
                    || r.author.toLowerCase(tr).contains(q))) continue;
            out.add(r);
        }
        return out;
    }

    private void sort(List<Prefs.Recent> list) {
        int s = prefs.sort();
        if (s == Prefs.SORT_TITLE) {
            final Collator col = Collator.getInstance(new Locale("tr", "TR"));
            Collections.sort(list, new Comparator<Prefs.Recent>() {
                @Override
                public int compare(Prefs.Recent a, Prefs.Recent b) {
                    return col.compare(a.name, b.name);
                }
            });
        } else if (s == Prefs.SORT_PROGRESS) {
            final Prefs p = prefs;
            Collections.sort(list, new Comparator<Prefs.Recent>() {
                @Override
                public int compare(Prefs.Recent a, Prefs.Recent b) {
                    return Float.compare(p.progress(b.key()), p.progress(a.key()));
                }
            });
        }
    }

    // ------------------------------------------------------------------ üst bölüm

    private View header() {
        LinearLayout h = new LinearLayout(this);
        h.setOrientation(LinearLayout.HORIZONTAL);
        h.setGravity(Gravity.CENTER_VERTICAL);
        h.setPadding(Ui.dp(this, 22), Ui.dp(this, 10), Ui.dp(this, 10), Ui.dp(this, 6));
        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.addView(Ui.serif(this, "Kitaplığım", 30f, pal.fg));
        int n = prefs.recents().size();
        TextView sub = Ui.text(this, n == 0 ? "Henüz kitap yok" : n + " kitap", 13.5f, pal.muted);
        sub.setPadding(0, Ui.dp(this, 4), 0, 0);
        titles.addView(sub);
        h.addView(titles, Ui.lpWeight(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        ImageView search = Ui.iconButton(this, pal, Icons.SEARCH, pal.fg, 44, 10);
        search.setOnClickListener(v -> toggleSearch());
        ImageView view = Ui.iconButton(this, pal,
                prefs.libGrid() ? Icons.ROWS : Icons.GRID, pal.fg, 44, 10);
        view.setOnClickListener(v -> {
            prefs.setLibGrid(!prefs.libGrid());
            render();
        });
        ImageView sort = Ui.iconButton(this, pal, Icons.SORT, pal.fg, 44, 10);
        sort.setOnClickListener(v -> showSortSheet());
        ImageView theme = Ui.iconButton(this, pal, Icons.PALETTE, pal.fg, 44, 10);
        theme.setOnClickListener(v -> showThemeSheet());
        h.addView(search);
        h.addView(view);
        h.addView(sort);
        h.addView(theme);
        return h;
    }

    private View searchRow() {
        LinearLayout r = new LinearLayout(this);
        r.setPadding(Ui.dp(this, 20), Ui.dp(this, 6), Ui.dp(this, 20), Ui.dp(this, 10));
        searchBox = Ui.input(this, pal, "Kitap veya yazar ara", query);
        searchBox.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void onTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void afterTextChanged(Editable e) {
                query = e.toString();
                renderList();
            }
        });
        r.addView(searchBox, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        ui.post(() -> {
            if (searchBox == null) return;
            searchBox.requestFocus();
            InputMethodManager im = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            if (im != null) im.showSoftInput(searchBox, 0);
        });
        return r;
    }

    private void toggleSearch() {
        if (searching) closeSearch();
        else {
            searching = true;
            render();
        }
    }

    private void closeSearch() {
        searching = false;
        query = "";
        InputMethodManager im = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (im != null && searchBox != null) im.hideSoftInputFromWindow(searchBox.getWindowToken(), 0);
        searchBox = null;
        render();
    }

    /** Arama yazılırken yalnızca kitap listesini yeniler (klavye kapanmasın). */
    private void renderList() {
        int keep = content.getChildCount();
        // başlık + arama satırı dışındakileri sil
        while (content.getChildCount() > 2) content.removeViewAt(content.getChildCount() - 1);
        List<Prefs.Recent> shown = filtered(prefs.recents());
        sort(shown);
        if (shown.isEmpty()) {
            TextView t = Ui.text(this, "Sonuç bulunamadı.", 15f, pal.muted);
            t.setGravity(Gravity.CENTER);
            t.setPadding(0, Ui.dp(this, 40), 0, 0);
            content.addView(t);
        } else if (prefs.libGrid()) {
            addShelves(shown);
        } else {
            addRows(shown);
        }
    }

    // ------------------------------------------------------------------ devam kartı

    private View hero(final Prefs.Recent r) {
        FrameLayout wrap = new FrameLayout(this);
        wrap.setPadding(Ui.dp(this, 18), Ui.dp(this, 8), Ui.dp(this, 18), Ui.dp(this, 14));
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(Ui.dp(this, 16), Ui.dp(this, 16), Ui.dp(this, 16), Ui.dp(this, 16));
        card.setBackground(Ui.ripple(this, Ui.rect(this, pal.surface, 22),
                Palette.withAlpha(pal.fg, 30), 22));
        card.setElevation(Ui.dp(this, 2));
        card.setClickable(true);
        card.setOnClickListener(v -> openBook(r));

        CoverView cv = coverFor(r);
        card.addView(cv, new LinearLayout.LayoutParams(Ui.dp(this, 92),
                ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(Ui.dp(this, 16), 0, 0, 0);
        TextView lab = Ui.bold(this, "KALDIĞIN YERDEN", 11f, pal.accent);
        lab.setLetterSpacing(0.1f);
        col.addView(lab);
        TextView title = Ui.serif(this, r.name, 19f, pal.fg);
        title.setMaxLines(3);
        title.setEllipsize(android.text.TextUtils.TruncateAt.END);
        title.setPadding(0, Ui.dp(this, 6), 0, 0);
        col.addView(title);
        if (!r.author.isEmpty()) {
            TextView au = Ui.oneLine(Ui.text(this, r.author, 13.5f, pal.muted));
            au.setPadding(0, Ui.dp(this, 3), 0, 0);
            col.addView(au);
        }
        float pr = prefs.progress(r.key());
        Bar bar = new Bar(this, pal);
        bar.set(pr);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 5));
        bp.topMargin = Ui.dp(this, 14);
        col.addView(bar, bp);
        TextView pct = Ui.text(this, pr < 0.005f ? "Henüz başlamadın" : "%" + Math.round(pr * 100)
                + " okundu", 12.5f, pal.muted);
        pct.setPadding(0, Ui.dp(this, 6), 0, 0);
        col.addView(pct);
        TextView go = Ui.pill(this, pal, "Devam et", true);
        go.setOnClickListener(v -> openBook(r));
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        gp.topMargin = Ui.dp(this, 12);
        col.addView(go, gp);
        card.addView(col, Ui.lpWeight(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        wrap.addView(card, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return wrap;
    }

    // ------------------------------------------------------------------ kategori çipleri

    private View categoryChips(List<Prefs.Recent> all) {
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(Ui.dp(this, 16), Ui.dp(this, 4), Ui.dp(this, 16), Ui.dp(this, 10));
        row.addView(catChip("Tümü  " + all.size(), selCat == null, null));
        List<String> cats = prefs.categories();
        for (String c : cats) {
            int n = 0;
            for (Prefs.Recent r : all) if (r.category.equals(c)) n++;
            row.addView(catChip(c + "  " + n, c.equals(selCat), c));
        }
        int none = 0;
        for (Prefs.Recent r : all) if (r.category.isEmpty()) none++;
        if (!cats.isEmpty() && none > 0) {
            row.addView(catChip("Kategorisiz  " + none, "".equals(selCat), ""));
        }
        TextView add = Ui.chip(this, pal, "+ Kategori", false);
        add.setTextColor(pal.accent);
        add.setOnClickListener(v -> promptNewCategory(null));
        row.addView(add, chipLp());
        hs.addView(row);
        return hs;
    }

    private LinearLayout.LayoutParams chipLp() {
        return Ui.lpMargin(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Ui.dp(this, 4), 0, Ui.dp(this, 4), 0);
    }

    private View catChip(String label, boolean selected, final String cat) {
        TextView c = Ui.chip(this, pal, label, selected);
        c.setOnClickListener(v -> {
            selCat = cat;
            render();
        });
        if (cat != null && !cat.isEmpty()) {
            c.setOnLongClickListener(v -> {
                showCategoryMenu(cat);
                return true;
            });
        }
        c.setLayoutParams(chipLp());
        return c;
    }

    private void showCategoryMenu(final String cat) {
        final Ui.Sheet sh = new Ui.Sheet(this, pal, cat);
        View rename = Ui.actionRow(this, pal, Icons.TEXT, "Adını değiştir", null);
        rename.setOnClickListener(v -> {
            sh.dismiss();
            promptRenameCategory(cat);
        });
        View del = Ui.actionRow(this, pal, Icons.CLOSE, "Kategoriyi sil",
                "Kitaplar silinmez, kategorisiz kalır");
        del.setOnClickListener(v -> {
            prefs.removeCategory(cat);
            if (cat.equals(selCat)) selCat = null;
            sh.dismiss();
            render();
        });
        sh.body().addView(rename);
        sh.body().addView(del);
        sh.show();
    }

    private void promptNewCategory(final Prefs.Recent assignTo) {
        prompt("Yeni kategori", "", "Örn. Romanlar", "Ekle", text -> {
            String n = prefs.addCategory(text);
            if (n == null) {
                toast("Bu ad kullanılamıyor");
                return;
            }
            if (assignTo != null) prefs.setCategory(assignTo.uri, n);
            render();
        });
    }

    private void promptRenameCategory(final String old) {
        prompt("Kategori adı", old, "Kategori adı", "Kaydet", text -> {
            prefs.renameCategory(old, text);
            if (old.equals(selCat)) selCat = text.trim();
            render();
        });
    }

    private interface TextCb {
        void on(String text);
    }

    private void prompt(String title, String initial, String hint, String ok, final TextCb cb) {
        final Ui.Sheet sh = new Ui.Sheet(this, pal, title);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(Ui.dp(this, 20), Ui.dp(this, 6), Ui.dp(this, 20), Ui.dp(this, 6));
        final EditText e = Ui.input(this, pal, hint, initial);
        box.addView(e, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        TextView go = Ui.pill(this, pal, ok, true);
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        gp.topMargin = Ui.dp(this, 14);
        box.addView(go, gp);
        go.setOnClickListener(v -> {
            String t = e.getText().toString().trim();
            if (t.isEmpty()) return;
            sh.dismiss();
            cb.on(t);
        });
        sh.body().addView(box);
        sh.show();
        e.requestFocus();
        e.setSelection(e.getText().length());
    }

    // ------------------------------------------------------------------ kitap hücreleri

    private CoverView coverFor(final Prefs.Recent r) {
        CoverView cv = new CoverView(this);
        final String key = r.key();
        cv.set(r.name, r.author, covers.get(key));
        cv.setTag(key);
        if (covers.get(key) == null && BookStore.hasCover(this, key)) {
            final CoverView target = cv;
            try {
                io.execute(() -> {
                    final Bitmap bm = BookStore.loadCover(MainActivity.this, key);
                    if (bm == null) return;
                    covers.put(key, bm);
                    ui.post(() -> {
                        if (!destroyed && key.equals(target.getTag())) {
                            target.set(r.name, r.author, bm);
                        }
                    });
                });
            } catch (Exception ignored) {
            }
        }
        return cv;
    }

    private int columns() {
        float wDp = getResources().getDisplayMetrics().widthPixels
                / getResources().getDisplayMetrics().density;
        return Math.max(3, Math.min(7, (int) (wDp / 118f)));
    }

    private void addShelves(List<Prefs.Recent> list) {
        int cols = columns();
        int gap = Ui.dp(this, 14);
        for (int i = 0; i < list.size(); i += cols) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.BOTTOM);
            row.setPadding(Ui.dp(this, 14), Ui.dp(this, 8), Ui.dp(this, 14), 0);
            for (int k = 0; k < cols; k++) {
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
                lp.setMargins(gap / 2, 0, gap / 2, 0);
                if (i + k < list.size()) row.addView(bookCell(list.get(i + k)), lp);
                else row.addView(new View(this), lp);
            }
            content.addView(row);
            content.addView(shelfBoard());
        }
    }

    private View shelfBoard() {
        View b = new View(this);
        android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{Palette.mix(pal.surfaceAlt, pal.fg, 0.10f), pal.surfaceAlt,
                        Palette.mix(pal.surfaceAlt, pal.bg, 0.4f)});
        g.setCornerRadius(Ui.dp(this, 3));
        b.setBackground(g);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 9));
        p.setMargins(Ui.dp(this, 10), 0, Ui.dp(this, 10), Ui.dp(this, 10));
        b.setLayoutParams(p);
        b.setElevation(Ui.dp(this, 1));
        return b;
    }

    private View bookCell(final Prefs.Recent r) {
        LinearLayout cell = new LinearLayout(this);
        cell.setOrientation(LinearLayout.VERTICAL);
        cell.setPadding(0, 0, 0, Ui.dp(this, 6));
        Ui.press(cell, pal, 0, 10);
        cell.setOnClickListener(v -> openBook(r));
        cell.setOnLongClickListener(v -> {
            showBookMenu(r);
            return true;
        });
        FrameLayout f = new FrameLayout(this);
        CoverView cv = coverFor(r);
        f.addView(cv, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        float pr = prefs.progress(r.key());
        if (pr > 0.005f) {
            Bar bar = new Bar(this, pal);
            bar.set(pr);
            FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 4), Gravity.BOTTOM);
            bp.setMargins(Ui.dp(this, 8), 0, Ui.dp(this, 8), Ui.dp(this, 6));
            f.addView(bar, bp);
        }
        cell.addView(f, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        TextView t = Ui.text(this, r.name, 12.5f, pal.fg);
        t.setMaxLines(2);
        t.setEllipsize(android.text.TextUtils.TruncateAt.END);
        t.setPadding(Ui.dp(this, 2), Ui.dp(this, 8), Ui.dp(this, 2), 0);
        cell.addView(t);
        String sub = pr >= 0.98f ? "Okundu" : (pr > 0.005f ? "%" + Math.round(pr * 100) : "");
        if (!sub.isEmpty()) {
            TextView s = Ui.text(this, sub, 11.5f, pr >= 0.98f ? pal.accent : pal.muted);
            s.setPadding(Ui.dp(this, 2), Ui.dp(this, 2), 0, 0);
            cell.addView(s);
        }
        return cell;
    }

    private void addRows(List<Prefs.Recent> list) {
        for (final Prefs.Recent r : list) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(Ui.dp(this, 20), Ui.dp(this, 10), Ui.dp(this, 20), Ui.dp(this, 10));
            Ui.press(row, pal, 0, 0);
            row.setOnClickListener(v -> openBook(r));
            row.setOnLongClickListener(v -> {
                showBookMenu(r);
                return true;
            });
            row.addView(coverFor(r), new LinearLayout.LayoutParams(
                    Ui.dp(this, 56), ViewGroup.LayoutParams.WRAP_CONTENT));
            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setPadding(Ui.dp(this, 16), 0, 0, 0);
            TextView t = Ui.text(this, r.name, 16f, pal.fg);
            t.setMaxLines(2);
            t.setEllipsize(android.text.TextUtils.TruncateAt.END);
            col.addView(t);
            String meta = r.author.isEmpty() ? "" : r.author;
            if (!r.category.isEmpty()) meta = meta.isEmpty() ? r.category : meta + " · " + r.category;
            if (!meta.isEmpty()) {
                TextView m = Ui.oneLine(Ui.text(this, meta, 12.5f, pal.muted));
                m.setPadding(0, Ui.dp(this, 3), 0, 0);
                col.addView(m);
            }
            float pr = prefs.progress(r.key());
            Bar bar = new Bar(this, pal);
            bar.set(pr);
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 4));
            bp.topMargin = Ui.dp(this, 10);
            col.addView(bar, bp);
            row.addView(col, Ui.lpWeight(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            TextView pc = Ui.bold(this, pr >= 0.98f ? "Okundu" : "%" + Math.round(pr * 100), 12.5f,
                    pr >= 0.98f ? pal.accent : pal.muted);
            pc.setPadding(Ui.dp(this, 12), 0, 0, 0);
            row.addView(pc);
            content.addView(row);
        }
    }

    // ------------------------------------------------------------------ boş durum

    private View emptyState() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER_HORIZONTAL);
        c.setPadding(Ui.dp(this, 32), Ui.dp(this, 80), Ui.dp(this, 32), 0);
        FrameLayout disc = new FrameLayout(this);
        disc.setBackground(Ui.circle(Palette.withAlpha(pal.accent, 36)));
        ImageView ic = Ui.icon(this, Icons.BOOK, pal.accent, 64, 0);
        disc.addView(ic, new FrameLayout.LayoutParams(Ui.dp(this, 64), Ui.dp(this, 64), Gravity.CENTER));
        c.addView(disc, new LinearLayout.LayoutParams(Ui.dp(this, 132), Ui.dp(this, 132)));
        TextView t = Ui.serif(this, "Kitaplığın henüz boş", 22f, pal.fg);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, Ui.dp(this, 26), 0, 0);
        c.addView(t);
        TextView s = Ui.text(this, "EPUB ve PDF kitaplarını ekle. Taranmış PDF'leri de sesli okuyabilirsin.",
                14.5f, pal.muted);
        s.setGravity(Gravity.CENTER);
        s.setLineSpacing(0f, 1.25f);
        s.setPadding(0, Ui.dp(this, 10), 0, Ui.dp(this, 22));
        c.addView(s);
        TextView b = Ui.pill(this, pal, "Kitap ekle", true);
        b.setOnClickListener(v -> pickBooks());
        c.addView(b);
        return c;
    }

    // ------------------------------------------------------------------ menüler

    private void showSortSheet() {
        final Ui.Sheet sh = new Ui.Sheet(this, pal, "Sıralama");
        String[] names = {"Son okunana göre", "Ada göre (A-Z)", "İlerlemeye göre"};
        for (int i = 0; i < names.length; i++) {
            final int idx = i;
            View r = Ui.actionRow(this, pal, prefs.sort() == i ? Icons.CHECK : -1, names[i], null);
            if (prefs.sort() != i) r.setPadding(Ui.dp(this, 60), Ui.dp(this, 13), Ui.dp(this, 20), Ui.dp(this, 13));
            r.setOnClickListener(v -> {
                prefs.setSort(idx);
                sh.dismiss();
                render();
            });
            sh.body().addView(r);
        }
        sh.show();
    }

    private void showThemeSheet() {
        final Ui.Sheet sh = new Ui.Sheet(this, pal, "Tema");
        String[] names = new String[Palette.COUNT];
        for (int i = 0; i < names.length; i++) names[i] = Palette.of(i).name;
        sh.body().addView(Ui.chipRow(this, pal, names, prefs.theme(), idx -> {
            prefs.pickTheme(idx);
            pal = prefs.palette();
            applyWindow();
            sh.dismiss();
            build();
        }));
        sh.body().addView(Ui.switchRow(this, pal, "Sisteme göre otomatik",
                "Telefon koyu moddaysa koyu, değilse açık tema; seçtiğin temalar kullanılır",
                prefs.autoTheme(), on -> {
                    prefs.setAutoTheme(on);
                    pal = prefs.palette();
                    applyWindow();
                    sh.dismiss();
                    build();
                }));
        sh.show();
    }

    private void showBookMenu(final Prefs.Recent r) {
        final Ui.Sheet sh = new Ui.Sheet(this, pal, r.name);
        View cat = Ui.actionRow(this, pal, Icons.LIST, "Kategori",
                r.category.isEmpty() ? "Kategorisiz" : r.category);
        cat.setOnClickListener(v -> {
            sh.dismiss();
            showCategoryPicker(r);
        });
        View ren = Ui.actionRow(this, pal, Icons.TEXT, "Adını değiştir", null);
        ren.setOnClickListener(v -> {
            sh.dismiss();
            prompt("Kitap adı", r.name, "Kitap adı", "Kaydet", text -> {
                prefs.renameBook(r.uri, text);
                render();
            });
        });
        View reset = Ui.actionRow(this, pal, Icons.CHECK, "İlerlemeyi sıfırla", "Baştan okumaya başla");
        reset.setOnClickListener(v -> {
            String k = r.key();
            prefs.saveChapter(k, 0);
            prefs.saveFrac(k, 0f);
            prefs.savePage(k, 0);
            prefs.saveProgress(k, 0f);
            sh.dismiss();
            render();
        });
        View del = Ui.actionRow(this, pal, Icons.CLOSE, "Kitaplıktan kaldır",
                "Yer imleri ve ilerleme de silinir");
        del.setOnClickListener(v -> {
            sh.dismiss();
            String k = r.key();
            prefs.removeRecent(r.uri);
            prefs.forgetBook(k);
            BookStore.delete(this, k);
            covers.remove(k);
            render();
        });
        sh.body().addView(cat);
        sh.body().addView(ren);
        sh.body().addView(reset);
        sh.body().addView(del);
        sh.show();
    }

    private void showCategoryPicker(final Prefs.Recent r) {
        final Ui.Sheet sh = new Ui.Sheet(this, pal, "Kategori seç");
        List<String> cats = prefs.categories();
        for (final String c : cats) {
            View row = Ui.actionRow(this, pal, c.equals(r.category) ? Icons.CHECK : -1, c, null);
            if (!c.equals(r.category)) row.setPadding(Ui.dp(this, 60), Ui.dp(this, 13), Ui.dp(this, 20), Ui.dp(this, 13));
            row.setOnClickListener(v -> {
                prefs.setCategory(r.uri, c);
                sh.dismiss();
                render();
            });
            sh.body().addView(row);
        }
        View none = Ui.actionRow(this, pal, r.category.isEmpty() ? Icons.CHECK : -1, "Kategorisiz", null);
        if (!r.category.isEmpty()) none.setPadding(Ui.dp(this, 60), Ui.dp(this, 13), Ui.dp(this, 20), Ui.dp(this, 13));
        none.setOnClickListener(v -> {
            prefs.setCategory(r.uri, "");
            sh.dismiss();
            render();
        });
        sh.body().addView(none);
        View add = Ui.actionRow(this, pal, Icons.PLUS, "Yeni kategori…", null);
        add.setOnClickListener(v -> {
            sh.dismiss();
            promptNewCategory(r);
        });
        sh.body().addView(add);
        sh.show();
    }

    // ------------------------------------------------------------------ kitap açma / ekleme

    private void openBook(Prefs.Recent r) {
        Intent i = new Intent(this, ReaderActivity.class);
        i.setData(Uri.parse(r.uri));
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(i);
    }

    private void pickBooks() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/epub+zip", "application/pdf"});
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        i.addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            startActivityForResult(i, REQ_OPEN);
        } catch (Exception e) {
            toast("Dosya seçici açılamadı");
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_OPEN || res != RESULT_OK || data == null) return;
        List<Uri> uris = new ArrayList<>();
        ClipData clip = data.getClipData();
        if (clip != null) {
            for (int i = 0; i < clip.getItemCount(); i++) uris.add(clip.getItemAt(i).getUri());
        } else if (data.getData() != null) {
            uris.add(data.getData());
        }
        int added = 0;
        for (int i = uris.size() - 1; i >= 0; i--) {
            Uri u = uris.get(i);
            try {
                getContentResolver().takePersistableUriPermission(u,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) {
            }
            String name = Util.displayName(this, u);
            String type = name.toLowerCase(Locale.ROOT).endsWith(".pdf") ? "pdf" : "epub";
            String cat = selCat == null ? "" : selCat;
            if (prefs.findRecent(u.toString()) == null) {
                prefs.addIfMissing(new Prefs.Recent(u.toString(), Util.cleanName(name), type, cat, ""));
                added++;
            }
        }
        if (added > 0) toast(added + " kitap eklendi");
        else if (!uris.isEmpty()) toast("Bu kitap zaten kitaplıkta");
        render();
        prepareCovers();
    }

    /** Kapağı olmayan kitapların kapağını ve bilgisini arka planda hazırlar. */
    private void prepareCovers() {
        if (preparing) return;
        preparing = true;
        try {
            io.execute(() -> {
                try {
                    boolean any = false;
                    for (Prefs.Recent r : prefs.recents()) {
                        if (destroyed) return;
                        if (BookStore.prepare(MainActivity.this, prefs, r)) {
                            any = true;
                            final boolean last = false;
                            ui.post(() -> {
                                if (!destroyed && !searching) render();
                            });
                        }
                    }
                } finally {
                    preparing = false;
                }
            });
        } catch (Exception e) {
            preparing = false;
        }
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    // ------------------------------------------------------------------ ilerleme çubuğu

    /** İnce yuvarlak ilerleme çubuğu. */
    static final class Bar extends View {
        private final Palette p;
        private float value;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF r = new RectF();

        Bar(android.content.Context c, Palette p) {
            super(c);
            this.p = p;
        }

        void set(float v) {
            value = Math.max(0f, Math.min(1f, v));
            invalidate();
        }

        @Override
        protected void onDraw(Canvas c) {
            float h = getHeight();
            float w = getWidth();
            paint.setColor(Palette.withAlpha(p.fg, 45));
            r.set(0, 0, w, h);
            c.drawRoundRect(r, h / 2f, h / 2f, paint);
            if (value > 0f) {
                paint.setColor(p.accent);
                r.set(0, 0, Math.max(h, w * value), h);
                c.drawRoundRect(r, h / 2f, h / 2f, paint);
            }
        }
    }
}
