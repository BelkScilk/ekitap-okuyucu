package com.fatih.ekitap;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.DocumentsContract;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * SAF tree (klasör) üzerinden EPUB/PDF listeler.
 * Google Drive, OneDrive, yerel klasör vb. hepsi çalışır.
 * Okuma konumu Prefs'te kalır → her cihazda ayrıdır, karışmaz.
 */
final class LibraryFolder {

    static final class Entry {
        final String uri;
        final String name;
        final String type; // epub | pdf

        Entry(String uri, String name, String type) {
            this.uri = uri;
            this.name = name;
            this.type = type;
        }
    }

    private LibraryFolder() {
    }

    /** Klasördeki (1 seviye) EPUB ve PDF dosyalarını listeler. */
    static List<Entry> listBooks(Context c, String treeUriStr) {
        List<Entry> out = new ArrayList<>();
        if (treeUriStr == null || treeUriStr.isEmpty()) return out;
        try {
            Uri tree = Uri.parse(treeUriStr);
            String docId = DocumentsContract.getTreeDocumentId(tree);
            Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId);
            String[] cols = new String[]{
                    DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                    DocumentsContract.Document.COLUMN_MIME_TYPE
            };
            try (Cursor cur = c.getContentResolver().query(children, cols, null, null, null)) {
                if (cur == null) return out;
                int iId = cur.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID);
                int iName = cur.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME);
                int iMime = cur.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE);
                while (cur.moveToNext()) {
                    String id = iId >= 0 ? cur.getString(iId) : null;
                    String name = iName >= 0 ? cur.getString(iName) : null;
                    String mime = iMime >= 0 ? cur.getString(iMime) : null;
                    if (id == null || name == null) continue;
                    String type = typeOf(name, mime);
                    if (type == null) continue;
                    Uri fileUri = DocumentsContract.buildDocumentUriUsingTree(tree, id);
                    out.add(new Entry(fileUri.toString(), Util.cleanName(name), type));
                }
            }
        } catch (Exception ignored) {
        }
        return out;
    }

    private static String typeOf(String name, String mime) {
        String n = name == null ? "" : name.toLowerCase(Locale.ROOT);
        String m = mime == null ? "" : mime.toLowerCase(Locale.ROOT);
        if (m.contains("epub") || n.endsWith(".epub")) return "epub";
        if (m.contains("pdf") || n.endsWith(".pdf")) return "pdf";
        return null;
    }

    /** Kalıcı okuma izni al. */
    static void takePermission(Context c, Uri treeUri) {
        try {
            c.getContentResolver().takePersistableUriPermission(treeUri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) {
        }
    }

    /** Klasör görünen adı (mümkünse). */
    static String folderName(Context c, Uri treeUri) {
        try {
            String docId = DocumentsContract.getTreeDocumentId(treeUri);
            Uri doc = DocumentsContract.buildDocumentUriUsingTree(treeUri, docId);
            try (Cursor cur = c.getContentResolver().query(doc,
                    new String[]{DocumentsContract.Document.COLUMN_DISPLAY_NAME}, null, null, null)) {
                if (cur != null && cur.moveToFirst()) {
                    String n = cur.getString(0);
                    if (n != null && !n.isEmpty()) return n;
                }
            }
        } catch (Exception ignored) {
        }
        return "Kitap klasörü";
    }
}
