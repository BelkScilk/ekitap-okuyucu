# Ekitap Okuyucu 2.0 (Android)

EPUB ve PDF (taranmış PDF dahil, OCR) okuyan, sesli okuyan, uyku zamanlayıcılı e-kitap uygulaması. Sıfırdan yeniden yazıldı.

## Özellikler

- Kitaplık: gerçek kapaklar, raf / liste görünümü, kategoriler, sıralama, arama, "Kaldığın yerden" kartı
- Okurken çubuklar kaybolur; ortaya dokun = menü, sol/sağ kenara dokun = sayfa çevir
- 4 tema (Açık, Koyu, Sepya, Siyah), yazı boyutu, yazı tipi, satır aralığı, kenar boşluğu, parlaklık
- Sesli okuma: cümle + kelime vurgusu (yazı rengi korunur), en kaliteli Türkçe TTS sesini otomatik seçme, 0,94× doğal başlangıç hızı, EPUB ve PDF (görüntü ve metin kipi), bildirim ve kulaklık kontrolleri
- Uyku zamanlayıcısı: 15-90 dk veya bölüm sonu, sesi yavaşça kısarak kapanır
- Yer imleri, kitap içi arama (EPUB), içindekiler, sayfaya git (PDF)
- PDF: "Metni ekrana sığdır" (OCR), kenar kırpma, iki parmakla yakınlaştırma

## APK'yı alma (bilgisayarda hiçbir şey kurmadan)

1. GitHub'da yeni bir depo (repository) oluştur.
2. Bu klasörün **içindeki her şeyi** depoya yükle (`.github` klasörü dahil! Gizli klasör olduğu için dosya yöneticisinde "gizli dosyaları göster" açık olmalı). Git kullanıyorsan:
   ```
   git init
   git add .
   git commit -m "ilk sürüm"
   git branch -M main
   git remote add origin https://github.com/KULLANICI/DEPO.git
   git push -u origin main
   ```
3. GitHub'da depoda **Actions** sekmesine gir. "APK Derle" otomatik çalışır (2-5 dk). Çalışmazsa "APK Derle" > **Run workflow**.
4. Bitince çalışmanın sayfasının altındaki **Artifacts** bölümünden `ekitap-okuyucu-apk` dosyasını indir, zip'ten çıkan `ekitap-okuyucu.apk` dosyasını telefona at.
5. Telefonda APK'ya dokun, "bilinmeyen kaynaklardan yüklemeye izin ver" de, kur.

İstersen `v1.0` gibi bir etiket (tag) atarsan APK **Releases** bölümüne de otomatik eklenir; telefondan doğrudan oradan indirebilirsin.

## Notlar

- Sesli okuma telefondaki metin okuma (TTS) motorunu kullanır (Google TTS vb.). Türkçe ses yoksa: Ayarlar > Metin okuma > Google > Türkçe sesi indir.
- PDF'lerde sesli okuma, sayfayı cihaz üzerinde OCR ile metne çevirir (internet gerekmez). İlk sayfa birkaç saniye sürebilir; Türkçe harflerde (ş, ğ, ı) bazen hata yapabilir. Taranmış PDF'in kalitesi okumayı doğrudan etkiler.
- DRM korumalı EPUB'lar ve parolalı PDF'ler açılmaz.
- APK, projeyle birlikte gelen sabit bir anahtarla (`app/ekitap.keystore`) imzalanır. Böylece her yeni sürüm eskisinin üstüne kurulur ve kitaplığın/konumların silinmez. (Anahtarın parolası depoda açıktır; yalnızca kişisel kullanım içindir, Play Store için kendi anahtarını kullan.)
- Not: Daha önce anahtarsız (geçici imzalı) bir sürüm kurduysan, bu sürüme geçerken **bir kez** eskisini silip yenisini kurman gerekir. Sonraki güncellemelerde gerekmez.
- Yerelde derlemek istersen: Android Studio ile klasörü aç, ya da `./gradlew assembleDebug`.
