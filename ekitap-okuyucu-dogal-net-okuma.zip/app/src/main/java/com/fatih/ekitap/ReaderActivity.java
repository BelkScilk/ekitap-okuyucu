package com.fatih.ekitap;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Okuma ekranı: EPUB/PDF yüzeyi, üstte yüzen çubuklar, sesli okuma ve uyku zamanlayıcısı. */
public class ReaderActivity extends Activity implements Pane.Host, Speaker.Cb {

    Prefs prefs;
    Palette pal;
    final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();

    private Uri uri;
    String key;
    String bookTitle = "";
    Pane pane;
    Speaker speaker;
    private boolean destroyed;

    // yerleşim
    private FrameLayout root;
    private FrameLayout holder;
    private LinearLayout topBar;
    private LinearLayout bottomPanel;
    private TextView titleView;
    private TextView subtitleView;
    private TextView timerChip;
    private ImageView bookmarkBtn;
    private LinearLayout playerStrip;
    private TextView stripLabel;
    private TextView posLeft;
    private TextView posRight;
    private SeekBar seek;
    private ImageView playIcon;
    private View loadingView;
    private int stableTop;
    private int stableBottom;
    private boolean chromeShown;
    private boolean seeking;
    private GestureDetector taps;

    // sesli okuma
    private boolean wantSpeak;
    private boolean awaitUnit;
    private final int[] curSent = {0, 0};
    private boolean serviceStarted;

    // uyku zamanlayıcısı
    private long timerEnd;
    boolean timerAtUnitEnd;
    private final Runnable tick = this::onTimerTick;

    // konum kaydı
    private boolean posPending;
    private long lastSave;

    ReaderSheets sheets;

    // ------------------------------------------------------------------ yaşam döngüsü

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = new Prefs(this);
        pal = prefs.palette();
        uri = getIntent().getData();
        if (uri == null) {
            finish();
            return;
        }
        key = Integer.toHexString(uri.toString().hashCode());
        bookTitle = Util.cleanName(Util.displayName(this, uri));

        Window w = getWindow();
        w.setStatusBarColor(Color.TRANSPARENT);
        w.setNavigationBarColor(Color.TRANSPARENT);
        if (Build.VERSION.SDK_INT >= 28) {
            w.getAttributes().layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        applyKeepOn();
        applyBrightness();

        sheets = new ReaderSheets(this);
        buildUi();
        speaker = new Speaker(this, prefs, ui, this);
        KeepAliveService.controller = media;
        loadBook();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (pane != null) pane.saveProgress();
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (pane != null) pane.saveProgress();
    }

    @Override
    protected void onDestroy() {
        destroyed = true;
        ui.removeCallbacksAndMessages(null);
        if (speaker != null) speaker.shutdown();
        releaseService();
        if (KeepAliveService.controller == media) KeepAliveService.controller = null;
        if (pane != null) {
            pane.saveProgress();
            pane.destroy();
            pane = null;
        }
        io.shutdown();
        super.onDestroy();
    }

    @Override
    public void onConfigurationChanged(android.content.res.Configuration c) {
        super.onConfigurationChanged(c);
        if (pane != null) pane.onResized();
        root.requestApplyInsets();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && root != null) applySystemUi();
    }

    @Override
    public void onBackPressed() {
        finish();
    }

    // ------------------------------------------------------------------ Pane.Host

    @Override
    public Activity activity() {
        return this;
    }

    @Override
    public Prefs prefs() {
        return prefs;
    }

    @Override
    public Palette pal() {
        return pal;
    }

    @Override
    public Handler ui() {
        return ui;
    }

    @Override
    public void onPosition() {
        if (posPending || destroyed) return;
        posPending = true;
        ui.postDelayed(() -> {
            posPending = false;
            if (destroyed || pane == null) return;
            long now = SystemClock.elapsedRealtime();
            if (now - lastSave > 4000) {
                lastSave = now;
                pane.saveProgress();
            }
            refreshPosition();
        }, 350);
    }

    @Override
    public void onUnitLoaded() {
        if (destroyed) return;
        refreshPosition();
        if (awaitUnit) {
            awaitUnit = false;
            if (wantSpeak) startSpeech(false);
        }
    }

    @Override
    public void onUserNavigated() {
        if (wantSpeak) stopSpeech();
    }

    @Override
    public void onMessage(String msg) {
        toast(msg);
    }

    // ------------------------------------------------------------------ arayüz

    private void buildUi() {
        root = new FrameLayout(this);
        root.setBackgroundColor(pal.bg);
        holder = new FrameLayout(this);
        root.addView(holder, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        loadingView = new ProgressBar(this);
        root.addView(loadingView, new FrameLayout.LayoutParams(
                Ui.dp(this, 36), Ui.dp(this, 36), Gravity.CENTER));

        buildChrome();
        setContentView(root);

        root.setOnApplyWindowInsetsListener((v, insets) -> {
            stableTop = insets.getStableInsetTop();
            stableBottom = insets.getStableInsetBottom();
            holder.setPadding(0, stableTop, 0, stableBottom);
            topBar.setPadding(Ui.dp(this, 4), stableTop, Ui.dp(this, 6), Ui.dp(this, 6));
            bottomPanel.setPadding(Ui.dp(this, 14), Ui.dp(this, 10), Ui.dp(this, 14),
                    stableBottom + Ui.dp(this, 10));
            return insets;
        });
        applySystemUi();

        taps = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onSingleTapConfirmed(MotionEvent e) {
                onTap(e.getRawX(), e.getRawY());
                return false;
            }
        });
        root.requestApplyInsets();
    }

    /** Üst çubuk ve alt paneli (yeniden) kurar; tema değişince de çağrılır. */
    void buildChrome() {
        if (topBar != null) root.removeView(topBar);
        if (bottomPanel != null) root.removeView(bottomPanel);

        // ---- üst çubuk
        topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setBackground(Ui.rect(this, pal.surface, 0));
        topBar.setElevation(Ui.dp(this, 6));
        topBar.setPadding(Ui.dp(this, 4), stableTop, Ui.dp(this, 6), Ui.dp(this, 6));
        ImageView back = Ui.iconButton(this, pal, Icons.BACK, pal.fg, 48, 12);
        back.setOnClickListener(v -> finish());
        topBar.addView(back);
        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titleView = Ui.oneLine(Ui.serif(this, bookTitle, 16.5f, pal.fg));
        subtitleView = Ui.oneLine(Ui.text(this, "", 12f, pal.muted));
        subtitleView.setPadding(0, Ui.dp(this, 3), 0, 0);
        titles.addView(titleView);
        titles.addView(subtitleView);
        topBar.addView(titles, Ui.lpWeight(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        timerChip = Ui.bold(this, "", 12.5f, pal.accentOn);
        timerChip.setPadding(Ui.dp(this, 10), Ui.dp(this, 5), Ui.dp(this, 10), Ui.dp(this, 5));
        timerChip.setBackground(Ui.rect(this, pal.accent, 14));
        timerChip.setVisibility(View.GONE);
        timerChip.setOnClickListener(v -> sheets.showListen());
        topBar.addView(timerChip, Ui.lpMargin(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0, Ui.dp(this, 4), 0));
        bookmarkBtn = Ui.iconButton(this, pal, Icons.BOOKMARK, pal.fg, 46, 11);
        bookmarkBtn.setOnClickListener(v -> sheets.toggleBookmark());
        topBar.addView(bookmarkBtn);
        ImageView more = Ui.iconButton(this, pal, Icons.DOTS, pal.fg, 46, 11);
        more.setOnClickListener(v -> sheets.showMore());
        topBar.addView(more);

        // ---- alt panel
        bottomPanel = new LinearLayout(this);
        bottomPanel.setOrientation(LinearLayout.VERTICAL);
        bottomPanel.setBackground(Ui.rectTop(this, pal.surface, 22));
        bottomPanel.setElevation(Ui.dp(this, 10));
        bottomPanel.setPadding(Ui.dp(this, 14), Ui.dp(this, 10), Ui.dp(this, 14),
                stableBottom + Ui.dp(this, 10));

        playerStrip = new LinearLayout(this);
        playerStrip.setOrientation(LinearLayout.HORIZONTAL);
        playerStrip.setGravity(Gravity.CENTER_VERTICAL);
        playerStrip.setBackground(Ui.rect(this, pal.surfaceAlt, 16));
        playerStrip.setPadding(Ui.dp(this, 4), Ui.dp(this, 2), Ui.dp(this, 4), Ui.dp(this, 2));
        ImageView sPrev = Ui.iconButton(this, pal, Icons.PREV, pal.fg, 42, 10);
        sPrev.setOnClickListener(v -> speaker.skip(-1));
        ImageView sNext = Ui.iconButton(this, pal, Icons.NEXT, pal.fg, 42, 10);
        sNext.setOnClickListener(v -> speaker.skip(1));
        ImageView sStop = Ui.iconButton(this, pal, Icons.STOP, pal.fg, 42, 11);
        sStop.setOnClickListener(v -> stopSpeech());
        stripLabel = Ui.bold(this, "", 13.5f, pal.fg);
        stripLabel.setGravity(Gravity.CENTER);
        stripLabel.setOnClickListener(v -> sheets.showListen());
        playerStrip.addView(sPrev);
        playerStrip.addView(stripLabel, Ui.lpWeight(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        playerStrip.addView(sNext);
        playerStrip.addView(sStop);
        playerStrip.setVisibility(View.GONE);
        bottomPanel.addView(playerStrip, Ui.lpMargin(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0, 0, Ui.dp(this, 6)));

        LinearLayout pos = new LinearLayout(this);
        pos.setOrientation(LinearLayout.HORIZONTAL);
        pos.setPadding(Ui.dp(this, 6), Ui.dp(this, 2), Ui.dp(this, 6), 0);
        posLeft = Ui.oneLine(Ui.text(this, "", 12.5f, pal.muted));
        posRight = Ui.bold(this, "", 12.5f, pal.accent);
        pos.addView(posLeft, Ui.lpWeight(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        pos.addView(posRight);
        bottomPanel.addView(pos, Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        seek = Ui.seek(this, pal, 1000, 0);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                if (fromUser) posRight.setText("%" + Math.round(p / 10f));
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {
                seeking = true;
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
                seeking = false;
                if (pane != null) {
                    if (wantSpeak) stopSpeech();
                    pane.seekOverall(s.getProgress() / 1000f);
                }
            }
        });
        bottomPanel.addView(seek, Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.CENTER_VERTICAL);
        actions.addView(actionItem(Icons.LIST, "İçindekiler", v -> sheets.showContents()),
                Ui.lpWeight(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        actions.addView(actionItem(Icons.TEXT, "Yazı", v -> sheets.showAppearance()),
                Ui.lpWeight(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        FrameLayout play = new FrameLayout(this);
        play.setBackground(Ui.ripple(this, Ui.circle(pal.accent),
                Palette.withAlpha(pal.accentOn, 60), 30));
        play.setClickable(true);
        play.setElevation(Ui.dp(this, 3));
        playIcon = Ui.icon(this, Icons.PLAY, pal.accentOn, 30, 0);
        play.addView(playIcon, new FrameLayout.LayoutParams(Ui.dp(this, 30), Ui.dp(this, 30),
                Gravity.CENTER));
        play.setOnClickListener(v -> onPlayClicked());
        play.setOnLongClickListener(v -> {
            sheets.showListen();
            return true;
        });
        actions.addView(play, Ui.lpMargin(Ui.dp(this, 58), Ui.dp(this, 58),
                Ui.dp(this, 6), 0, Ui.dp(this, 6), 0));

        actions.addView(actionItem(Icons.TIMER, "Dinleme", v -> sheets.showListen()),
                Ui.lpWeight(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        actions.addView(actionItem(Icons.SEARCH, "Ara", v -> sheets.showSearch()),
                Ui.lpWeight(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        bottomPanel.addView(actions, Ui.lpMargin(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, 0, Ui.dp(this, 4), 0, 0));

        FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP);
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM);
        root.addView(topBar, tp);
        root.addView(bottomPanel, bp);
        topBar.setVisibility(chromeShown ? View.VISIBLE : View.GONE);
        bottomPanel.setVisibility(chromeShown ? View.VISIBLE : View.GONE);
        if (loadingView != null) loadingView.bringToFront();
        refreshPosition();
        updatePlayUi();
        updateBookmarkIcon();
        updateTimerChip();
    }

    private View actionItem(int icon, String label, View.OnClickListener l) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER_HORIZONTAL);
        c.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 4));
        Ui.press(c, pal, 0, 14);
        ImageView ic = Ui.icon(this, icon, pal.fg, 26, 0);
        c.addView(ic, new LinearLayout.LayoutParams(Ui.dp(this, 26), Ui.dp(this, 26)));
        TextView t = Ui.text(this, label, 10.5f, pal.muted);
        t.setPadding(0, Ui.dp(this, 4), 0, 0);
        c.addView(t);
        c.setOnClickListener(l);
        return c;
    }

    /** Tema değişince tüm arayüzü yeniden boyar. */
    void applyTheme() {
        pal = prefs.palette();
        root.setBackgroundColor(pal.bg);
        buildChrome();
        if (pane != null) pane.applyStyle();
        applySystemUi();
    }

    void applySystemUi() {
        int f = View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;
        if (pal.lightUi) {
            f |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        }
        if (!chromeShown) {
            f |= View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
        }
        getWindow().getDecorView().setSystemUiVisibility(f);
    }

    void applyKeepOn() {
        if (prefs.keepOn()) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    void applyBrightness() {
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        float b = prefs.brightness();
        lp.screenBrightness = b < 0f ? WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
                : Math.max(0.02f, Math.min(1f, b));
        getWindow().setAttributes(lp);
    }

    // ------------------------------------------------------------------ çubukları göster / gizle

    void setChrome(boolean show) {
        if (show == chromeShown) return;
        chromeShown = show;
        applySystemUi();
        if (show) {
            refreshPosition();
            topBar.setVisibility(View.VISIBLE);
            bottomPanel.setVisibility(View.VISIBLE);
            topBar.setAlpha(0f);
            bottomPanel.setAlpha(0f);
            topBar.setTranslationY(-Ui.dp(this, 40));
            bottomPanel.setTranslationY(Ui.dp(this, 60));
            topBar.animate().alpha(1f).translationY(0).setDuration(200).start();
            bottomPanel.animate().alpha(1f).translationY(0).setDuration(200).start();
        } else {
            topBar.animate().alpha(0f).translationY(-Ui.dp(this, 40)).setDuration(180)
                    .withEndAction(() -> {
                        if (!chromeShown) topBar.setVisibility(View.GONE);
                    }).start();
            bottomPanel.animate().alpha(0f).translationY(Ui.dp(this, 60)).setDuration(180)
                    .withEndAction(() -> {
                        if (!chromeShown) bottomPanel.setVisibility(View.GONE);
                    }).start();
        }
    }

    // ------------------------------------------------------------------ dokunma

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (taps != null && pane != null) taps.onTouchEvent(ev);
        if (pane != null) pane.onTouch(ev);
        return super.dispatchTouchEvent(ev);
    }

    private void onTap(float rx, float ry) {
        if (pane == null) return;
        if (chromeShown) {
            if (ry < topBar.getBottom() || ry > bottomPanel.getTop()) {
                // çubukların üstüne dokunuldu: çubuklar kendi tıklamasını işler
                if (ry < topBar.getBottom() || ry > bottomPanel.getTop() + 0) {
                    return;
                }
            }
        }
        float cx = rx / Math.max(1, root.getWidth());
        if (prefs.tapPaging() && cx < 0.22f) {
            pane.step(false);
        } else if (prefs.tapPaging() && cx > 0.78f) {
            pane.step(true);
        } else {
            setChrome(!chromeShown);
        }
    }

    // ------------------------------------------------------------------ kitap yükleme

    private void loadBook() {
        io.execute(() -> {
            try {
                File f = BookStore.ensure(this, uri.toString(), key);
                String type = BookStore.sniff(f);
                if (type == null) throw new java.io.IOException("Desteklenmeyen dosya. EPUB veya PDF seçin.");
                if ("pdf".equals(type)) {
                    ParcelFileDescriptor fd = ParcelFileDescriptor.open(f,
                            ParcelFileDescriptor.MODE_READ_ONLY);
                    final PdfRenderer r;
                    try {
                        r = new PdfRenderer(fd);
                    } catch (Exception e) {
                        try {
                            fd.close();
                        } catch (Exception ignored) {
                        }
                        throw e;
                    }
                    if (r.getPageCount() <= 0) {
                        r.close();
                        fd.close();
                        throw new java.io.IOException("PDF boş görünüyor");
                    }
                    final ParcelFileDescriptor fdf = fd;
                    ui.post(() -> {
                        if (destroyed) {
                            try {
                                r.close();
                                fdf.close();
                            } catch (Exception ignored) {
                            }
                            return;
                        }
                        showPane(new PdfPane(this, r, fdf, key), "pdf", null);
                    });
                } else {
                    final EpubBook b = EpubBook.open(f);
                    ui.post(() -> {
                        if (destroyed) {
                            try {
                                b.close();
                            } catch (Exception ignored) {
                            }
                            return;
                        }
                        showPane(new EpubPane(this, b, key), "epub", b);
                    });
                }
            } catch (final SecurityException se) {
                fail("Bu kitaba erişim izni yok. Kitaplıktan kaldırıp yeniden ekleyin.");
            } catch (final Exception e) {
                fail("Kitap açılamadı: " + e.getMessage());
            }
        });
    }

    private void fail(final String msg) {
        ui.post(() -> {
            if (destroyed) return;
            toast(msg);
            finish();
        });
    }

    private void showPane(Pane p, String type, EpubBook epub) {
        pane = p;
        try {
            getContentResolver().takePersistableUriPermission(uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) {
        }
        String name = bookTitle;
        String author = "";
        if (epub != null) {
            if (!epub.title.isEmpty()) name = epub.title;
            author = epub.author;
        }
        Prefs.Recent old = prefs.findRecent(uri.toString());
        if (old != null && !old.name.equals("Kitap")) name = old.name.isEmpty() ? name : old.name;
        prefs.addRecent(new Prefs.Recent(uri.toString(), name, type, "", author));
        if (epub != null && (old == null || old.author.isEmpty())) {
            prefs.updateMeta(uri.toString(), epub.title, epub.author);
        }
        prefs.touch(key);
        bookTitle = name;
        titleView.setText(name);
        holder.addView(p.view(), new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        p.applyStyle();
        p.open();
        loadingView.setVisibility(View.GONE);
        refreshPosition();
        if (!prefs.seenHint()) {
            prefs.setSeenHint();
            toast("Menü için ekranın ortasına, sayfa çevirmek için kenarlara dokun");
        }
    }

    // ------------------------------------------------------------------ konum göstergesi

    void refreshPosition() {
        if (pane == null || posLeft == null) return;
        subtitleView.setText(pane.unitTitle());
        posLeft.setText(pane.unitLabel());
        float o = pane.overall();
        if (!seeking) {
            seek.setProgress(Math.round(o * 1000));
            posRight.setText("%" + Math.round(o * 100));
        }
        updateBookmarkIcon();
        KeepAliveService svc = KeepAliveService.instance;
        if (svc != null) svc.setProgress(o, pane.unitTitle());
    }

    void updateBookmarkIcon() {
        if (bookmarkBtn == null || pane == null) return;
        boolean has = false;
        List<Prefs.Bookmark> list = prefs.bookmarks(key);
        for (Prefs.Bookmark b : list) {
            if (b.pos == pane.unit() && Math.abs(b.frac - pane.frac()) < 0.03f) {
                has = true;
                break;
            }
        }
        bookmarkBtn.setImageDrawable(Icons.get(has ? Icons.BOOKMARK_FILLED : Icons.BOOKMARK,
                has ? pal.accent : pal.fg));
    }

    // ------------------------------------------------------------------ sesli okuma

    private void onPlayClicked() {
        if (pane == null) return;
        if (speaker.isPlaying()) {
            speaker.pause();
        } else if (speaker.isPaused()) {
            speaker.play();
        } else {
            startSpeech(true);
        }
    }

    void startSpeech(boolean fromVisible) {
        if (pane == null) return;
        wantSpeak = true;
        requestNotificationPermission();
        pane.requestSpeech(fromVisible, (text, start) -> {
            if (destroyed || !wantSpeak) return;
            if (text.trim().isEmpty()) {
                advanceSpeechUnit();
                return;
            }
            speaker.load(text, start);
            speaker.play();
        });
    }

    /** Sonraki bölüm/sayfaya geçip okumayı sürdürür. */
    private void advanceSpeechUnit() {
        if (pane == null) return;
        if (pane.unit() + 1 < pane.unitCount()) {
            awaitUnit = true;
            pane.go(pane.unit() + 1, 0f);
        } else {
            stopSpeech();
            toast("Kitap bitti");
        }
    }

    void stopSpeech() {
        wantSpeak = false;
        awaitUnit = false;
        if (speaker != null) speaker.stop();
        if (pane != null) pane.clearHighlight();
        updatePlayUi();
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission("android.permission.POST_NOTIFICATIONS")
                != PackageManager.PERMISSION_GRANTED) {
            try {
                requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 77);
            } catch (Exception ignored) {
            }
        }
    }

    // Speaker.Cb

    @Override
    public void onSegment(int a, int b) {
        curSent[0] = a;
        curSent[1] = b;
        if (pane != null && prefs.highlight()) pane.highlight(a, b, -1, -1);
    }

    @Override
    public void onWord(int a, int b) {
        if (pane != null && prefs.highlight()) pane.highlight(curSent[0], curSent[1], a, b);
    }

    @Override
    public void onFinished() {
        if (!wantSpeak) return;
        if (timerAtUnitEnd) {
            expireTimer();
            return;
        }
        advanceSpeechUnit();
    }

    @Override
    public void onEdge(int dir) {
        if (pane == null) return;
        int u = pane.unit() + dir;
        if (u < 0 || u >= pane.unitCount()) return;
        boolean was = wantSpeak;
        speaker.stop();
        wantSpeak = was;
        awaitUnit = was;
        pane.go(u, 0f);
        if (!was) refreshPosition();
    }

    @Override
    public void onState() {
        updatePlayUi();
        if (speaker.isActive()) {
            startOrUpdateService();
        } else {
            releaseService();
        }
    }

    void updatePlayUi() {
        if (playIcon == null || speaker == null) return;
        boolean playing = speaker.isPlaying();
        playIcon.setImageDrawable(Icons.get(playing ? Icons.PAUSE : Icons.PLAY, pal.accentOn));
        boolean active = speaker.isActive();
        playerStrip.setVisibility(active ? View.VISIBLE : View.GONE);
        stripLabel.setText((playing ? "Okunuyor" : "Duraklatıldı") + " · "
                + String.format(java.util.Locale.US, "%.2g", prefs.rate()).replace("0.", "0,")
                .replace(".", ",") + "×");
    }

    // ------------------------------------------------------------------ bildirim servisi / medya tuşları

    private void startOrUpdateService() {
        try {
            if (!serviceStarted) {
                Intent i = new Intent(this, KeepAliveService.class)
                        .setAction(KeepAliveService.ACTION_START)
                        .putExtra(KeepAliveService.EXTRA_TITLE, bookTitle)
                        .putExtra(KeepAliveService.EXTRA_PLAYING, speaker.isPlaying());
                startForegroundService(i);
                serviceStarted = true;
            } else {
                KeepAliveService s = KeepAliveService.instance;
                if (s != null) {
                    s.setPlaying(speaker.isPlaying(), bookTitle);
                    if (pane != null) s.setProgress(pane.overall(), pane.unitTitle());
                }
            }
        } catch (Exception ignored) {
        }
    }

    private void releaseService() {
        if (!serviceStarted) return;
        serviceStarted = false;
        try {
            stopService(new Intent(this, KeepAliveService.class));
        } catch (Exception ignored) {
        }
    }

    private final KeepAliveService.Controller media = new KeepAliveService.Controller() {
        @Override
        public void onMediaPlay() {
            ui.post(() -> {
                if (speaker.isPaused()) speaker.play();
                else startSpeech(true);
            });
        }

        @Override
        public void onMediaPause() {
            ui.post(() -> speaker.pause());
        }

        @Override
        public void onMediaStop() {
            ui.post(ReaderActivity.this::stopSpeech);
        }

        @Override
        public void onMediaSkip(int dir) {
            ui.post(() -> speaker.skip(dir));
        }

        @Override
        public void onMediaSeek(float f) {
            ui.post(() -> {
                if (pane == null) return;
                boolean was = wantSpeak;
                if (was) stopSpeech();
                pane.seekOverall(f);
                if (was) ui.postDelayed(() -> startSpeech(false), 600);
            });
        }
    };

    // ------------------------------------------------------------------ uyku zamanlayıcısı

    boolean timerActive() {
        return timerEnd > 0 || timerAtUnitEnd;
    }

    /** minutes=0: kapat. */
    void setTimer(int minutes) {
        ui.removeCallbacks(tick);
        timerAtUnitEnd = false;
        if (speaker != null) speaker.setVolume(1f);
        if (minutes > 0) {
            timerEnd = SystemClock.elapsedRealtime() + minutes * 60_000L;
            prefs.setLastTimerMin(minutes);
            ui.post(tick);
        } else {
            timerEnd = 0;
        }
        updateTimerChip();
    }

    void setTimerAtUnitEnd(boolean on) {
        ui.removeCallbacks(tick);
        timerEnd = 0;
        timerAtUnitEnd = on;
        if (speaker != null) speaker.setVolume(1f);
        updateTimerChip();
    }

    long timerRemainingMs() {
        return timerEnd > 0 ? Math.max(0, timerEnd - SystemClock.elapsedRealtime()) : 0;
    }

    private void onTimerTick() {
        if (destroyed || timerEnd <= 0) return;
        long rem = timerRemainingMs();
        if (rem <= 0) {
            expireTimer();
            return;
        }
        if (prefs.fadeOut() && rem <= 30_000L && speaker != null) {
            speaker.setVolume(Math.max(0.12f, rem / 30_000f));
        }
        updateTimerChip();
        ui.postDelayed(tick, 1000);
    }

    private void expireTimer() {
        timerEnd = 0;
        timerAtUnitEnd = false;
        stopSpeech();
        if (pane != null) pane.saveProgress();
        toast("Uyku zamanlayıcısı doldu, uygulama kapanıyor");
        finishAffinity();
    }

    void updateTimerChip() {
        if (timerChip == null) return;
        if (timerEnd > 0) {
            long s = timerRemainingMs() / 1000;
            timerChip.setText(String.format(java.util.Locale.US, "%d:%02d", s / 60, s % 60));
            timerChip.setVisibility(View.VISIBLE);
        } else if (timerAtUnitEnd) {
            timerChip.setText("Bölüm sonu");
            timerChip.setVisibility(View.VISIBLE);
        } else {
            timerChip.setVisibility(View.GONE);
        }
    }

    void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }
}
